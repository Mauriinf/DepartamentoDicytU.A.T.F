-- DROP SEQUENCE
DROP SEQUENCE IF EXISTS becas_id_beca_seq CASCADE;
DROP SEQUENCE IF EXISTS cargo_id_cargo_seq CASCADE;
DROP SEQUENCE IF EXISTS carrera_id_carrera_seq CASCADE;
DROP SEQUENCE IF EXISTS convenios_id_convenios_seq CASCADE;
DROP SEQUENCE IF EXISTS convocatoria_id_convocatoria_seq CASCADE;
DROP SEQUENCE IF EXISTS detalle_avances_id_detalle_seq CASCADE;
DROP SEQUENCE IF EXISTS eventos_id_evento_seq CASCADE;
DROP SEQUENCE IF EXISTS fotos_noticias_id_noticias_seq CASCADE;
DROP SEQUENCE IF EXISTS fotos_publicaciones_id_foto_seq CASCADE;
DROP SEQUENCE IF EXISTS mensajes_id_mensaje_seq CASCADE;
DROP SEQUENCE IF EXISTS personal_id_personal_seq CASCADE;
DROP SEQUENCE IF EXISTS portada_id_portada_seq CASCADE;
DROP SEQUENCE IF EXISTS publicacion_id_publicacion_seq CASCADE;
DROP SEQUENCE IF EXISTS recurso_id_recurso_seq CASCADE;
DROP SEQUENCE IF EXISTS roles_id_seq CASCADE;
DROP SEQUENCE IF EXISTS tipo_convenio_id_convenio_seq CASCADE;
DROP SEQUENCE IF EXISTS tipo_convocatoria_id_tipo_convocatoria_seq CASCADE;
DROP SEQUENCE IF EXISTS tipo_investigador_id_seq CASCADE;
DROP SEQUENCE IF EXISTS tipo_publicacion_id_tipo_publi_seq CASCADE;
DROP SEQUENCE IF EXISTS trabajo_investigacion_id_investigacion_seq CASCADE;
DROP SEQUENCE IF EXISTS usuario_id_usuario_seq CASCADE;
DROP SEQUENCE IF EXISTS facultades_id_facultad_seq CASCADE;

-- DROP FOREIGN KEY
ALTER TABLE becas DROP CONSTRAINT becas_ibfk_1 CASCADE;
ALTER TABLE carrera DROP CONSTRAINT carrera_ibfk_1 CASCADE;
ALTER TABLE convenios DROP CONSTRAINT convenios_ibfk_1 CASCADE;
ALTER TABLE convocatoria DROP CONSTRAINT convocatoria_ibfk_1 CASCADE;
ALTER TABLE detalle_avances DROP CONSTRAINT detalle_avances_ibfk_1 CASCADE;
ALTER TABLE fotos_noticias DROP CONSTRAINT fotos_noticias_ibfk_1 CASCADE;
ALTER TABLE personal DROP CONSTRAINT personal_ibfk_1 CASCADE;
ALTER TABLE publicacion DROP CONSTRAINT publicacion_ibfk_1 CASCADE;
ALTER TABLE trabajo_investigacion DROP CONSTRAINT trabajo_investigacion_ibfk_2 CASCADE;
ALTER TABLE trabajo_investigacion DROP CONSTRAINT trabajo_investigacion_ibfk_3 CASCADE;
ALTER TABLE usuario DROP CONSTRAINT usuario_ibfk_1 CASCADE;


-- TABLE STRUCTURE FOR: convocatoria
DROP TABLE IF EXISTS convocatoria;
CREATE TABLE convocatoria (
	id_convocatoria integer PRIMARY KEY,
	id_tipo_convocatoria integer,
	titulo character varying,
	descripcion character varying,
	resumen character varying,
	fecha_inicio date,
	fecha_final date,
	archivo character varying,
	estado character varying
);

-- TABLE STRUCTURE FOR: eventos
DROP TABLE IF EXISTS eventos;
CREATE TABLE eventos (
	id_evento integer PRIMARY KEY,
	titulo character varying,
	fecha_inicio timestamp without time zone,
	fecha_final timestamp without time zone,
	color character varying,
	link character varying,
	color_texto character varying,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: fotos_noticias
DROP TABLE IF EXISTS fotos_noticias;
CREATE TABLE fotos_noticias (
	id_noticias integer PRIMARY KEY,
	id_publi integer,
	nombre character varying
);

-- TABLE STRUCTURE FOR: cargo
DROP TABLE IF EXISTS cargo;
CREATE TABLE cargo (
	id_cargo integer PRIMARY KEY,
	nombre_cargo character varying,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: fotos_publicaciones
DROP TABLE IF EXISTS fotos_publicaciones;
CREATE TABLE fotos_publicaciones (
	id_foto integer PRIMARY KEY,
	id_publicacion integer,
	nombre_foto character varying
);

-- TABLE STRUCTURE FOR: mensajes
DROP TABLE IF EXISTS mensajes;
CREATE TABLE mensajes (
	id_mensaje integer PRIMARY KEY,
	id_emisor integer,
	id_remitente integer,
	titulo character varying,
	mensaje TEXT,
	fecha timestamp without time zone,
	archivo character varying,
	leido smallint,
	eliminado integer,
	fecha_borrado timestamp without time zone
);

-- TABLE STRUCTURE FOR: portada
DROP TABLE IF EXISTS portada;
CREATE TABLE portada (
	id_portada integer PRIMARY KEY,
	imagen character varying,
	titulo character varying,
	descripcion character varying,
	usuario integer
);

-- TABLE STRUCTURE FOR: convenios
DROP TABLE IF EXISTS convenios;
CREATE TABLE convenios (
	id_convenios integer PRIMARY KEY,
	titulo character varying,
	fecha date,
	descripcion TEXT,
	tipo_convenio integer,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: personal
DROP TABLE IF EXISTS personal;
CREATE TABLE personal (
	id_personal integer PRIMARY KEY,
	nombre_completo character varying,
	apellido_pat character varying,
	apellido_mat character varying,
	id_cargo integer,
	correo character varying,
	imagen character varying
);

-- TABLE STRUCTURE FOR: facultades
DROP TABLE IF EXISTS facultades;
CREATE TABLE facultades (
	id_facultad integer PRIMARY KEY,
	nombre_facultad character varying,
	imagen character varying,
	imagenr character varying
);

-- TABLE STRUCTURE FOR: recurso
DROP TABLE IF EXISTS recurso;
CREATE TABLE recurso (
	id_recurso integer PRIMARY KEY,
	nombre character varying,
	objetivo character varying,
	area character varying,
	url character varying,
	imagen character varying,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: tipo_investigador
DROP TABLE IF EXISTS tipo_investigador;
CREATE TABLE tipo_investigador (
	id integer PRIMARY KEY,
	nombre_investigador character varying
);

-- TABLE STRUCTURE FOR: publicacion
DROP TABLE IF EXISTS publicacion;
CREATE TABLE publicacion (
	id_publicacion integer PRIMARY KEY,
	titulo character varying,
	fecha date,
	descripcion TEXT,
	id_tipo_publi integer,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: roles
DROP TABLE IF EXISTS roles;
CREATE TABLE roles (
	id integer PRIMARY KEY,
	nombre character varying,
	descripcion character varying
);

-- TABLE STRUCTURE FOR: trabajo_investigacion
DROP TABLE IF EXISTS trabajo_investigacion;
CREATE TABLE trabajo_investigacion (
	id_investigacion integer PRIMARY KEY,
	id_facultad integer,
	id_carrera integer,
	titulo_investigacion TEXT,
	autor integer,
	tipo_investigador integer,
	objetivo_general TEXT,
	resumen TEXT,
	conclusiones TEXT,
	fecha date,
	archivo character varying,
	nombre_autor character varying,
	gestion integer,
	visitas integer,
	tutor character varying,
	tipo_investigacion character varying
);

-- TABLE STRUCTURE FOR: becas
DROP TABLE IF EXISTS becas;
CREATE TABLE becas (
	id_beca integer PRIMARY KEY,
	titulo character varying,
	fecha date,
	descripcion TEXT,
	imagen character varying,
	id_usuario integer
);

-- TABLE STRUCTURE FOR: tipo_convenio
DROP TABLE IF EXISTS tipo_convenio;
CREATE TABLE tipo_convenio (
	id_convenio integer PRIMARY KEY,
	nombre_convenio character varying
);

-- TABLE STRUCTURE FOR: tipo_convocatoria
DROP TABLE IF EXISTS tipo_convocatoria;
CREATE TABLE tipo_convocatoria (
	id_tipo_convocatoria integer PRIMARY KEY,
	nombre_tipo character varying
);

-- TABLE STRUCTURE FOR: detalle_avances
DROP TABLE IF EXISTS detalle_avances;
CREATE TABLE detalle_avances (
	id_detalle integer PRIMARY KEY,
	id_avance integer,
	id_usuario integer,
	archivo character varying,
	fecha date,
	puntage integer,
	estado integer,
	avance character varying
);

-- TABLE STRUCTURE FOR: tipo_publicacion
DROP TABLE IF EXISTS tipo_publicacion;
CREATE TABLE tipo_publicacion (
	id_tipo_publi integer PRIMARY KEY,
	nombre_publicacion character varying
);

-- TABLE STRUCTURE FOR: carrera
DROP TABLE IF EXISTS carrera;
CREATE TABLE carrera (
	id_carrera integer PRIMARY KEY,
	id_facultad integer,
	nombre_carrera character varying,
	imagenc character varying
);

-- TABLE STRUCTURE FOR: usuario
DROP TABLE IF EXISTS usuario;
CREATE TABLE usuario (
	id_usuario integer PRIMARY KEY,
	nombre_completo character varying,
	apellido_pat character varying,
	apellido_mat character varying,
	usuario character varying,
	contrasena character varying,
	ci character varying,
	direccion character varying,
	telefono integer,
	email character varying,
	rol_id integer,
	id_facultad integer,
	id_carrera integer,
	estado integer,
	imagen character varying,
	tipo_investigador integer,
	gestion integer
);
-- CREATE SEQUENCE
CREATE SEQUENCE becas_id_beca_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE cargo_id_cargo_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE carrera_id_carrera_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE convenios_id_convenios_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE convocatoria_id_convocatoria_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE detalle_avances_id_detalle_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE eventos_id_evento_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE fotos_noticias_id_noticias_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE fotos_publicaciones_id_foto_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE mensajes_id_mensaje_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE personal_id_personal_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE portada_id_portada_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE publicacion_id_publicacion_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE recurso_id_recurso_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE roles_id_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE tipo_convenio_id_convenio_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE tipo_convocatoria_id_tipo_convocatoria_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE tipo_investigador_id_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE tipo_publicacion_id_tipo_publi_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE trabajo_investigacion_id_investigacion_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE usuario_id_usuario_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;
CREATE SEQUENCE facultades_id_facultad_seq
	START WITH 1
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807;


-- INSERT DATA convocatoria
INSERT INTO convocatoria (id_convocatoria, id_tipo_convocatoria, titulo, descripcion, resumen, fecha_inicio, fecha_final, archivo, estado) VALUES ('1', '2', 'CONVOCATORIA AUXILIARES DE INVESTIGACIÓN GESTIÓN  2018', '<p>El&nbsp;&nbsp; Vicerrectorado, la direcci&oacute;n de lnvestgacion ciemlflca y Tecnologica de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;a&quot;, convocan a un&nbsp;concurso&nbsp; meritos&nbsp;para optar&nbsp;el cargo de Auxiliar de lnvestigacl&oacute;n, correspondiente a la &nbsp;gestion&nbsp;acad&eacute;mica 2020.</p>

<p>La &nbsp;presente convocatona, tiene el alcance a todas las Carreras&nbsp;de&nbsp;la Universidad&nbsp;(Sede Central y Subsedes Universitarias), y est&aacute; sujeta&nbsp;a las siguientes condiciones formales.</p>
', '<p>Brindar a los estudiantes de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;as&quot;, que cursan los &uacute;ltimos niveles acad&eacute;micos, un apoyo econ&oacute;mico mensual para desarrollar trabajos de investigaci&oacute;n y participar en actividades inherentes a la gesti&oacute;n de la Investigaci&oacute;n Cient&iacute;fica y la Transferencia de Conocimientos.</p>
', '2017-11-01', '2018-01-25', '1ra__CONVOCATORIA_AUXILIAR_DE_INVESTIGACION_2018.pdf', '1');
INSERT INTO convocatoria (id_convocatoria, id_tipo_convocatoria, titulo, descripcion, resumen, fecha_inicio, fecha_final, archivo, estado) VALUES ('4', '2', 'CONVOCATORIA AUXILIARES DE INVESTIGACIÓN GESTIÓN 2020', '<p>El&nbsp;&nbsp; Vicerrectorado, la direcci&oacute;n de lnvestgacion ciemlflca y Tecnologica de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;a&quot;, convocan a un&nbsp;concurso&nbsp; meritos&nbsp;para optar&nbsp;el cargo de Auxiliar de lnvestigacl&oacute;n, correspondiente a la &nbsp;gestion&nbsp;acad&eacute;mica 2020.</p>

<p>La &nbsp;presente convocatona, tiene el alcance a todas las Carreras&nbsp;de&nbsp;la Universidad&nbsp;(Sede Central y Subsedes Universitarias), y est&aacute; sujeta&nbsp;a las siguientes condiciones formales.</p>
', '<p>Brindar a los estudiantes de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;as&quot;, que cursan los &uacute;ltimos niveles acad&eacute;micos, un apoyo econ&oacute;mico mensual para desarrollar trabajos de investigaci&oacute;n y participar en actividades inherentes a la gesti&oacute;n de la Investigaci&oacute;n Cient&iacute;fica y la Transferencia de Conocimientos.</p>
', '2019-12-02', '2020-02-06', 'convo_2019_12_09_20_17_41.pdf', '1');
INSERT INTO convocatoria (id_convocatoria, id_tipo_convocatoria, titulo, descripcion, resumen, fecha_inicio, fecha_final, archivo, estado) VALUES ('2', '1', 'XV FERIA CIENCIA, TECNOLOGÍA, INNOVACIÓN Y  CULTURA', '<p>La Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;as&quot; a traves de la Direcci&oacute;n de Investigaci&oacute;n Cient&iacute;fica y Tecnol&oacute;gica de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;as&quot;, convoca a la XV Feria Ciencia, Tecnolog&iacute;a, Innovaci&oacute;n.</p>
', '<p>Hacer conocer y difundir los trabajos de Investigaci&oacute;n realizados en cada una de las Facultades de la U.A.T.F., los mismos que contribuyen al desarrollo del conocimiento cient&iacute;fico, proponen soluciones a los problemas locales, regionales, racionales. de los sectores productivos, municipios. gobernaciones as&iacute; como de las naciones y pueblos ind&iacute;gena originario campesinos, acorde con el Plan de Desarrollo Institucional.</p>
', '2019-08-01', '2019-10-30', 'FERIA_DE_CIENCIA_XV.pdf', '1');
INSERT INTO convocatoria (id_convocatoria, id_tipo_convocatoria, titulo, descripcion, resumen, fecha_inicio, fecha_final, archivo, estado) VALUES ('3', '1', 'III  FERIA DEL  LIBRO', '<p>El Vicerrectorado de la Universidad Aut&oacute;noma &#39;Tom&aacute;s Fr&iacute;os&quot; a trav&eacute;s de la Direcci&oacute;n de Investigaci&oacute;n Cient&iacute;fica y Tecnol&oacute;gica de la Universidad Aut&oacute;noma &quot;Tom&aacute;s Fr&iacute;as&quot; convocan a la III Feria del Libro.</p>
', '<p>Mostrar la producci&oacute;n intelectual de la Universidad Aut&oacute;noma &#39;Tom&aacute;s Fr&iacute;as&quot;, evento que nos permitir&aacute; la presentaci&oacute;n de libros, libros con resultados de investigaci&oacute;n, textos did&aacute;cticos, gu&iacute;as did&aacute;cticas, y otros; generando la difusi&oacute;n y socializaci&oacute;n de la literatura que cuenta y que genera la Universidad.</p>
', '2019-08-01', '2019-11-10', 'FERIA_LIBRO_2019.pdf', '1');

-- INSERT DATA eventos
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('1', 'Primer Avance', '2019-06-03 10:00:00', '2019-06-17 18:00:00', '#00CCFF', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('2', 'Entrega Final', '2019-11-09 00:00:00', '2019-11-10 00:00:00', '#00CCFF', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('3', 'avance tres', '2019-07-08 00:00:00', '2019-07-11 00:00:00', '#FF0000', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('6', 'bbb', '2019-10-17 12:00:00', '2019-10-21 00:00:00', '#00CCFF', 'calendario_modal/ver/', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('7', 'Pre inscripción y confirmación 1ra Prueba de Suficiencia Académica 1/2019', '2018-10-01 00:00:00', '2018-11-13 00:00:00', '#003333', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('8', 'ACTIVIDADES ACADÉMICAS', '2019-02-08 00:00:00', '2019-12-16 00:00:00', '#003333', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('9', 'nadasos', '2019-11-09 00:00:00', '2019-11-17 00:00:00', '#FF0000', '', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('10', 'ultimo', '2019-12-05 00:00:00', '2019-12-08 00:00:00', '#FF9900', 'calendario_modal/ver/', '#FFFFFF', '1');
INSERT INTO eventos (id_evento, titulo, fecha_inicio, fecha_final, color, link, color_texto, id_usuario) VALUES ('12', 'PRIMER AVANZE', '2020-08-25 00:00:00', '2020-08-28 00:00:00', '#00CCFF', 'calendario_modal/ver/', '#FFFFFF', '1');

-- INSERT DATA fotos_noticias
INSERT INTO fotos_noticias (id_noticias, id_publi, nombre) VALUES ('1', '7', 'noticia_2019_11_28_09_33_09.jpg');
INSERT INTO fotos_noticias (id_noticias, id_publi, nombre) VALUES ('2', '8', 'noticia_2019_11_28_09_33_35.jpg');
INSERT INTO fotos_noticias (id_noticias, id_publi, nombre) VALUES ('3', '6', 'noticia_2019_11_28_09_33_54.jpg');
INSERT INTO fotos_noticias (id_noticias, id_publi, nombre) VALUES ('4', '10', 'noticia_2019_12_09_16_35_07.jpg');

-- INSERT DATA cargo
INSERT INTO cargo (id_cargo, nombre_cargo, id_usuario) VALUES ('1', 'Director de DICyT', '1');
INSERT INTO cargo (id_cargo, nombre_cargo, id_usuario) VALUES ('2', 'Coordinador DICyT', '1');
INSERT INTO cargo (id_cargo, nombre_cargo, id_usuario) VALUES ('3', 'Secretaria(o)', '1');
INSERT INTO cargo (id_cargo, nombre_cargo, id_usuario) VALUES ('4', 'Auxiliar', '1');
INSERT INTO cargo (id_cargo, nombre_cargo, id_usuario) VALUES ('7', 'portero', '1');

-- INSERT DATA fotos_publicaciones
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('1', '9', 'dicyt_revista_9_REVISTA_1_-_001.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('2', '9', 'dicyt_revista_9_REVISTA_1_-_002.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('3', '9', 'dicyt_revista_9_REVISTA_1_-_003.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('4', '9', 'dicyt_revista_9_REVISTA_1_-_004.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('5', '9', 'dicyt_revista_9_REVISTA_1_-_005.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('6', '9', 'dicyt_revista_9_REVISTA_1_-_006.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('7', '9', 'dicyt_revista_9_REVISTA_1_-_007.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('8', '9', 'dicyt_revista_9_REVISTA_1_-_008.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('9', '9', 'dicyt_revista_9_REVISTA_1_-_009.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('10', '9', 'dicyt_revista_9_REVISTA_1_-_010.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('11', '9', 'dicyt_revista_9_REVISTA_1_-_011.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('12', '9', 'dicyt_revista_9_REVISTA_1_-_012.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('13', '9', 'dicyt_revista_9_REVISTA_1_-_013.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('14', '9', 'dicyt_revista_9_REVISTA_1_-_014.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('15', '9', 'dicyt_revista_9_REVISTA_1_-_015.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('16', '9', 'dicyt_revista_9_REVISTA_1_-_016.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('17', '9', 'dicyt_revista_9_REVISTA_1_-_017.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('18', '9', 'dicyt_revista_9_REVISTA_1_-_018.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('19', '9', 'dicyt_revista_9_REVISTA_1_-_019.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('20', '9', 'dicyt_revista_9_REVISTA_1_-_020.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('21', '9', 'dicyt_revista_9_REVISTA_1_-_021.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('22', '9', 'dicyt_revista_9_REVISTA_1_-_022.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('23', '9', 'dicyt_revista_9_REVISTA_1_-_023.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('24', '9', 'dicyt_revista_9_REVISTA_1_-_024.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('25', '9', 'dicyt_revista_9_REVISTA_1_-_025.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('26', '9', 'dicyt_revista_9_REVISTA_1_-_026.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('27', '9', 'dicyt_revista_9_REVISTA_1_-_027.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('28', '9', 'dicyt_revista_9_REVISTA_1_-_028.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('29', '9', 'dicyt_revista_9_REVISTA_1_-_029.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('30', '9', 'dicyt_revista_9_REVISTA_1_-_030.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('31', '9', 'dicyt_revista_9_REVISTA_1_-_031.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('32', '9', 'dicyt_revista_9_REVISTA_1_-_032.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('33', '9', 'dicyt_revista_9_REVISTA_1_-_033.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('34', '9', 'dicyt_revista_9_REVISTA_1_-_034.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('35', '9', 'dicyt_revista_9_REVISTA_1_-_035.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('36', '9', 'dicyt_revista_9_REVISTA_1_-_036.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('37', '9', 'dicyt_revista_9_REVISTA_1_-_037.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('38', '9', 'dicyt_revista_9_REVISTA_1_-_038.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('39', '9', 'dicyt_revista_9_REVISTA_1_-_039.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('40', '9', 'dicyt_revista_9_REVISTA_1_-_040.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('41', '9', 'dicyt_revista_9_REVISTA_1_-_041.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('42', '9', 'dicyt_revista_9_REVISTA_1_-_042.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('43', '9', 'dicyt_revista_9_REVISTA_1_-_043.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('44', '9', 'dicyt_revista_9_REVISTA_1_-_044.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('45', '9', 'dicyt_revista_9_REVISTA_1_-_045.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('46', '9', 'dicyt_revista_9_REVISTA_1_-_046.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('47', '9', 'dicyt_revista_9_REVISTA_1_-_047.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('48', '9', 'dicyt_revista_9_REVISTA_1_-_048.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('49', '9', 'dicyt_revista_9_REVISTA_1_-_049.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('50', '9', 'dicyt_revista_9_REVISTA_1_-_050.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('51', '9', 'dicyt_revista_9_REVISTA_1_-_051.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('52', '9', 'dicyt_revista_9_REVISTA_1_-_052.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('53', '9', 'dicyt_revista_9_REVISTA_1_-_053.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('54', '9', 'dicyt_revista_9_REVISTA_1_-_054.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('55', '9', 'dicyt_revista_9_REVISTA_1_-_055.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('56', '9', 'dicyt_revista_9_REVISTA_1_-_056.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('57', '9', 'dicyt_revista_9_REVISTA_1_-_057.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('58', '9', 'dicyt_revista_9_REVISTA_1_-_058.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('59', '9', 'dicyt_revista_9_REVISTA_1_-_059.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('60', '9', 'dicyt_revista_9_REVISTA_1_-_060.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('61', '9', 'dicyt_revista_9_REVISTA_1_-_061.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('62', '9', 'dicyt_revista_9_REVISTA_1_-_062.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('63', '9', 'dicyt_revista_9_REVISTA_1_-_063.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('64', '9', 'dicyt_revista_9_REVISTA_1_-_064.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('65', '9', 'dicyt_revista_9_REVISTA_1_-_065.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('66', '9', 'dicyt_revista_9_REVISTA_1_-_066.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('67', '9', 'dicyt_revista_9_REVISTA_1_-_067.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('68', '9', 'dicyt_revista_9_REVISTA_1_-_068.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('69', '9', 'dicyt_revista_9_REVISTA_1_-_069.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('70', '9', 'dicyt_revista_9_REVISTA_1_-_070.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('71', '9', 'dicyt_revista_9_REVISTA_1_-_071.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('72', '9', 'dicyt_revista_9_REVISTA_1_-_072.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('73', '9', 'dicyt_revista_9_REVISTA_1_-_073.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('74', '9', 'dicyt_revista_9_REVISTA_1_-_074.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('75', '9', 'dicyt_revista_9_REVISTA_1_-_075.jpg');
INSERT INTO fotos_publicaciones (id_foto, id_publicacion, nombre_foto) VALUES ('76', '9', 'dicyt_revista_9_REVISTA_1_-_076.jpg');

-- INSERT DATA mensajes
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('2', '1', '7', 'kldjfksjfl',  E'<p>vestia</p>\\r\\n', '2019-10-28 15:58:06', '', '1', '0', '2019-01-12 00:00:00');
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('3', '1', '8', 'ldkjvlkdjflk',  E'<p>otra prueba</p>\\r\\n', '2019-10-28 15:58:37', '', '1', '0', '2019-01-12 00:00:00');
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('4', '5', '1', 'askjdhajkdh', '<p>des director</p>', '2019-10-28 16:04:13', '', '1', '0', '2019-01-12 00:00:00');
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('5', '8', '1', 'ljlkjkjklj', '<p>lkjklj</p>', '2019-10-28 16:34:06', '', '0', '0', '2019-01-12 00:00:00');
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('6', '7', '1', 'lkjlkj', '<p>lkjlkjklj</p>', '2019-10-28 16:37:37', '', '0', '0', '2019-01-12 00:00:00');
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('1', '1', '5', 'kjsdhfkjshf',  E'<p>vestia</p>\\r\\n', '2019-10-28 15:55:15', 'ckeditor_4_13_0_full.zip', '1', '0', NULL);
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('7', '1', '7', 'bbb', '<p>bbbb</p>
', '2020-04-24 14:27:08', NULL, '0', '0', NULL);
INSERT INTO mensajes (id_mensaje, id_emisor, id_remitente, titulo, mensaje, fecha, archivo, leido, eliminado, fecha_borrado) VALUES ('8', '1', '18', 'hola', '<p>hola como estas</p>
', '2020-08-25 11:59:43', NULL, '1', '0', NULL);

-- INSERT DATA portada
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('4', '2.jpg', 'UNA VISIÓN HACIA EL FUTURO', 'Disfruta de la tecnológia', '1');
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('6', '3.jpg', 'BIOTECNOLOGÍA ', 'Mejora la salud con métodos tecnológicos', '1');
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('7', '4.jpg', 'MICRO-TECNOLOGÍA', 'Para desarrollos espectaculares ', '1');
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('9', '5.jpg', 'LA TECNOLOGíA AVANZA', 'la tecnología es algo que no estaba cuando usted nació', '1');
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('10', 'd7e1725b3801fb6cdeb212884c893f79.jpg', 'DIRECCIÓN DE INVESTIGACIÓN CIENTÍFICA Y TECNOLÓGICA', 'Te da la Bienvenida a nuestro portal de actividades y proyectos', '1');
INSERT INTO portada (id_portada, imagen, titulo, descripcion, usuario) VALUES ('3', '1.jpg', 'TECNOLOGÍA EN TUS MANOS', 'Para un buen Futuro de la Humanidad', '1');

-- INSERT DATA convenios
INSERT INTO convenios (id_convenios, titulo, fecha, descripcion, tipo_convenio, id_usuario) VALUES ('2', 'CONVENIOS REGIONALES', '2019-05-13', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL REGIONAL.- La suscripción de convenios interinstitucionales responde a los lineamientos planteados en la política de vinculación con nuestro medio y responsabilidad social de la Universidad Técnica de Oruro.', '3', '1');
INSERT INTO convenios (id_convenios, titulo, fecha, descripcion, tipo_convenio, id_usuario) VALUES ('3', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL INTERNACIONAL GESTION 2015', '2019-04-23', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL INTERNACIONAL GESTION 2015 Se establecieron alianzas de cooperación con instituciones para el desarrollo de actividades conjuntas que promueven, canalizan, distintas posibilidades para realizar intercambios cooperación y modalidades de graduación e investigación Docente-Estudiantil.', '1', '1');

-- INSERT DATA personal
INSERT INTO personal (id_personal, nombre_completo, apellido_pat, apellido_mat, id_cargo, correo, imagen) VALUES ('1', 'Ing. César Luis', 'Viscarra', 'Pinto', '1', 'ganimedes1200@hotmail.com', '21232013_264985600678652_4847179112510477865_n.jpg');
INSERT INTO personal (id_personal, nombre_completo, apellido_pat, apellido_mat, id_cargo, correo, imagen) VALUES ('2', 'Dr. Lic. Marco Antonio ', 'Soza', 'Claros', '2', 'foxsozaclaros@hotmail.com', '51989158_2258941544150410_6014629066961846272_n.jpg');
INSERT INTO personal (id_personal, nombre_completo, apellido_pat, apellido_mat, id_cargo, correo, imagen) VALUES ('3', 'Blanca', 'Echeverria', '', '3', '', 'secre.jpg');
INSERT INTO personal (id_personal, nombre_completo, apellido_pat, apellido_mat, id_cargo, correo, imagen) VALUES ('4', 'Jacinto', 'Guzmán ', '', '4', '', '302333_241206436000283_2011292686_n.jpg');

-- INSERT DATA facultades
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('1', 'Ciencias Puras', 'puras.png', 'ciencias puras.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('2', 'Ciencias de la Salud', 'enfermeria.png', 'enfermeria.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('5', 'Ingeniería Minera', 'minera.png', 'minas.jpeg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('7', 'Ciencias Sociales y Humanisticas', 'humanisticas.png', 'humanisticas.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('8', 'Ciencias Agrícolas y Pecuarias', 'agronomia.png', 'agro.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('12', 'Ingeniería', 'ingenieria.png', 'ingenieria.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('13', 'Ciencias Económicas Financieras y Administrativas', 'economia.png', 'Economia.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('15', 'Ingeniería Geológica', 'geologia.png', 'geologia.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('16', 'Derecho', 'derecho.png', 'derecho.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('17', 'Medicina', 'medicina.png', 'medicina.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('18', 'Ingeniería Tecnológica', 'tecnica.png', 'tecnologica.jpg');
INSERT INTO facultades (id_facultad, nombre_facultad, imagen, imagenr) VALUES ('14', 'Artes', 'artes.png', 'artes.jpg');

-- INSERT DATA recurso
INSERT INTO recurso (id_recurso, nombre, objetivo, area, url, imagen, id_usuario) VALUES ('5', 'American Society of Agricultural  & Biological Engineers (ASABE)', '<p>Contiene 3 publicaciones peri&oacute;dicas en las &oacute;reas de Ingenier&iacute;ria agr&iacute;cola, Salud y seguridad agr&iacute;cola, Energ&iacute;a y maquinaria, Tierra y agua, Alimentos e ingenier&amp;oicute;a de procesos, Estructuras y medio ambiente, Tecnolog&iacute;as de informaci&oacute; y electricidad, Ingenier&iacute;a biol&oacute;gica, Ingenier&iacute;a forestal.</p>
', 'Todas las áreas de conocimiento', 'https://elibrary.asabe.org/', 'asabe_logo.jpg', '1');
INSERT INTO recurso (id_recurso, nombre, objetivo, area, url, imagen, id_usuario) VALUES ('6', 'Archivos de Medicina', '<p>Revista de acceso abierto en Espa&ntilde;ol, dedicada a todas las &aacute;reas de la medicina.</p>
', 'Ciencias de la Salud', 'http://www.archivosdemedicina.com/', 'arch-med.gif', '1');
INSERT INTO recurso (id_recurso, nombre, objetivo, area, url, imagen, id_usuario) VALUES ('7', 'Arquitectura Sacra', '<p>Revistas del Instituto de Arquitectura Sacra editadas por Duncan Stroik, profesor de arquitectura de la Universidad de Notre Dame.</p>
', 'Arquitectura y Ciencias del Habitat', 'http://www.sacredarchitecture.org/', 'sacra.bmp', '1');
INSERT INTO recurso (id_recurso, nombre, objetivo, area, url, imagen, id_usuario) VALUES ('8', 'ASIA Journals	', '<p>Portal de revistas cient&iacute;fcas publicadas en Nepal, Filipinas, Vietnam, Sri Lanka e Indonesia.</p>
', 'Diferentes áreas de Conocimiento', 'http://asiajol.info/', 'asia.bmp', '1');
INSERT INTO recurso (id_recurso, nombre, objetivo, area, url, imagen, id_usuario) VALUES ('9', 'Asociación de Bibliotecas de Investigación de Colorado, USA', '<p>Posibilita el acceso a repositorios de informaci&oacute;n de las bibliotecas miembro de la asociaci&oacute;n.</p>
', 'Todas las áreas de conocimiento', 'http://adrresources.coalliance.org/', 'coal.png', '1');

-- INSERT DATA tipo_investigador
INSERT INTO tipo_investigador (id, nombre_investigador) VALUES ('1', 'Trabajo Docente');
INSERT INTO tipo_investigador (id, nombre_investigador) VALUES ('2', 'Trabajo Estudiante');
INSERT INTO tipo_investigador (id, nombre_investigador) VALUES ('3', 'Proyecto de Investigación');

-- INSERT DATA publicacion
INSERT INTO publicacion (id_publicacion, titulo, fecha, descripcion, id_tipo_publi, id_usuario) VALUES ('10', 'Dirección de Investigación Científica y Tecnológica', '2019-12-09', '<p>La DICyT en pocos dias contara con su propia pagina Web http//uatf.edu.bo/uatf_dicyt/</p>
', '4', '1');
INSERT INTO publicacion (id_publicacion, titulo, fecha, descripcion, id_tipo_publi, id_usuario) VALUES ('7', 'Plazo para recibir formularios de preinscripción a la UATF es hasta el 13 de diciembre', '2019-11-22', '<p>La Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as fij&oacute; para el 13 de diciembre la fecha para recibir los formularios de preinscripci&oacute;n y confirmar su postulaci&oacute;n a una determinada carrera.</p>

<p>El director de Servicios Acad&eacute;micos de la UATF, Alex Michel, inform&oacute; que el proceso de admisi&oacute;n para la gesti&oacute;n 2020 se ten&iacute;a previsto para que se desarrolle en octubre, noviembre y parte de diciembre, pero por los conflictos sociales estos plazos no pudieron ser cumplidos.</p>

<p>&nbsp;&ldquo;Ya hemos hecho el reajuste. Esta semana ya ha empezado la recepci&oacute;n de los formularios de preinscripci&oacute;n para que puedan tomar la prueba de suficiencia acad&eacute;mica. Estamos cortos de tiempo, esto va a ser hasta el viernes 13 de diciembre&rdquo;, dijo.</p>

<p>El examen, inicialmente y sujeto a confirmaci&oacute;n, est&aacute; previsto para su aplicaci&oacute;n el 18 diciembre. &ldquo;Esto est&aacute; sujeto todav&iacute;a a aprobaci&oacute;n en el consejo acad&eacute;mico, va a variar quiz&aacute;s con un d&iacute;a o dos, la idea es salir antes del receso que va a empezar el 20 de diciembre&rdquo;, agreg&oacute;.</p>

<p>Hasta antes del receso debe estar aplicada la prueba de suficiencia acad&eacute;mica o examen de ingreso.</p>

<p>Sin embargo, la recepci&oacute;n de formularios de preinscripci&oacute;n tambi&eacute;n se ampliar&iacute;a en funci&oacute;n de la fecha de la prueba de suficiencia acad&eacute;mica.</p>

<p>&ldquo;Si el examen fuera el mi&eacute;rcoles, el lunes y martes (previos) se va a recibir todav&iacute;a las inscripciones, siempre se recibe hasta un d&iacute;a antes del examen&rdquo;, complement&oacute;.</p>

<p>Michel aclar&oacute; que los formularios no tienen fecha de caducidad y una vez impresos pueden ser entregados hasta el 13 de diciembre.</p>

<p>&ldquo;El formulario, si lo tienen lo pueden llenar el d&iacute;a de hoy (y tienen) hasta un d&iacute;a antes del examen para llevarlo a la ventanilla del departamento de admisiones y registros. No tiene l&iacute;mite. Algunos indicaban en la fila de que solamente tienen un d&iacute;a para confirmar este formulario, pero la realidad es que es abierto, pueden traerlo hasta un d&iacute;a antes del examen a la ventanilla con los documentos&rdquo;, agreg&oacute;.</p>

<p>Los funcionarios explicaron a los postulantes y padres de familia.</p>

<p>&ldquo;Les explicamos que la capacidad de atenci&oacute;n es en la ma&ntilde;ana de alrededor de 170 a 180 postulantes, y en la tarde en la misma cantidad&rdquo;, dijo.</p>

<p>Agreg&oacute; que los interesados expresaron su temor porque si bien habr&iacute;an llenado el formulario hace dos d&iacute;as atr&aacute;s, temen que no se les reciba, lo que fue descartado.</p>

<p>La entrega de formulario debe realizarse en la oficina de Admisiones y Registros en la Ciudadela Universitaria.</p>

<p>&ldquo;Una vez llenado el formulario en la p&aacute;gina</p>
', '4', '1');
INSERT INTO publicacion (id_publicacion, titulo, fecha, descripcion, id_tipo_publi, id_usuario) VALUES ('8', 'Buscan encaminar la finalización de la gestión académica en la UATF', '2019-11-19', '<p>El rector de la Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as, Roberto Boh&oacute;rquez, afirm&oacute; que se realizar&aacute;n reuniones para encaminar la conclusi&oacute;n de la gesti&oacute;n acad&eacute;mica que acat&oacute; el paro del comit&eacute; C&iacute;vico Potosinista (Comcipo).</p>

<p>&ldquo;Lo que a nosotros nos preocupa es culminar bien la gesti&oacute;n. Nos preocupa cumplir con esta labor que a&uacute;n nos queda de casi un mes de labor, si es que el calendario se hubiera cumplido&rdquo;, dijo.</p>

<p>Destac&oacute; que, pese a la paralizaci&oacute;n de actividades, se logr&oacute; los objetivos trazados por la comunidad universitaria.</p>

<p>Agreg&oacute; que se reunir&aacute;n con el vicerrectorado a fin de tomar las definiciones para culminar la gesti&oacute;n acad&eacute;mica.</p>

<p>Record&oacute; las gestiones coordinadas con los dirigentes c&iacute;vicos, docentes y estudiantes que participaron de las movilizaciones por la democracia.</p>

<p>&ldquo;Lo importante hoy es que tenemos que tener otro punto de vista y otra caracter&iacute;stica, no utilizar eso como banderas para otros intereses que no me parece. Somos universidad y en la universidad se respetan diferencias y pluralidades ideol&oacute;gicas, pero tambi&eacute;n hoy, en una unidad, tenemos que luchar de otra manera en lo que significa la nueva historia que debemos hacer&rdquo;, agreg&oacute;.</p>

<p>Sobre el pedido de renuncia de la Federaci&oacute;n Universitaria de Docentes, mediante una carta, dijo que se manejan en cogobierno.</p>

<p>&ldquo;Respeto, pero nosotros nos manejamos como cogobierno y una asamblea tampoco puede desestabilizar las cosas&rdquo;, dijo el rector.</p>
', '4', '1');
INSERT INTO publicacion (id_publicacion, titulo, fecha, descripcion, id_tipo_publi, id_usuario) VALUES ('6', 'UATF APERTURA PROGRAMA DE COMUNICACIÓN SOCIAL EN POTOSÍ', '2019-07-18', '<p>Tras varios a&ntilde;os de gesti&oacute;n de diferentes organizaciones vinculadas al periodismo y profesionales del &aacute;rea, la Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as (UATF), lanz&oacute; oficialmente las inscripciones para la carrera de ciencias de la Comunicaci&oacute;n Social, como un programa en primera instancia, m&aacute;s adelante se prev&eacute; la consolidaci&oacute;n de esta carrera universitaria.</p>

<p>El rector de la UATF, Dr. Roberto Bohorquez, manifest&oacute; que este proyecto anhelado por trabajadores de la prensa y estudiantes bachilleres, es una muestra de que Potos&iacute; puede sacar profesionales en el &aacute;rea de la comunicaci&oacute;n para el servicio a la poblaci&oacute;n.</p>

<p>La apertura de este programa busca mitigar la migraci&oacute;n de estudiantes que recurr&iacute;an a otras universidades del pa&iacute;s, para profesionalizarse en comunicaci&oacute;n social.</p>

<p>&ldquo;Estamos oficialmente lanzando el programa de comunicaci&oacute;n social. Estamos cumpliendo en la medida de las posibilidades en el contexto econ&oacute;mico que vive el sistema universitario boliviano, m&aacute;s all&aacute; de eso con el esp&iacute;ritu acad&eacute;mico de generar nuevos profesionales y evitar migraci&oacute;n de nuestros estudiantes a otros departamentos&rdquo;, dijo la autoridad universitaria.</p>

<p>Anunci&oacute; que la UATF est&aacute; invirtiendo en espacios para las pr&aacute;cticas de comunicaci&oacute;n tanto en radio como en televisi&oacute;n.</p>

<p>Las inscripciones se habilitar&aacute;n para la prueba de suficiencia acad&eacute;mica que regir&aacute; el ingreso y admisi&oacute;n de nuevos estudiantes. Para los interesados en registrarse, los requisitos ser&aacute;n los mismos que para otra carrera.</p>
', '4', '1');
INSERT INTO publicacion (id_publicacion, titulo, fecha, descripcion, id_tipo_publi, id_usuario) VALUES ('9', 'Memoria de la VII feria ciencia, tecnología e innovación ', '2019-11-25', '<p>La Direcci&oacute;n de Investigaci&oacute;n Cient&iacute;fica y Tecnolog&iacute;a (DICYT) Gracias al importante apoyo financiero de FAUTAPO, como responsable de la gesti&oacute;n de la actividad Cient&iacute;fica de la Tom&aacute;s Fr&iacute;as en el mes de noviembre del 2010 llevo a cabo la VII FERIA NACIONAL CIENT&Iacute;FICA DE CIENCIA Y TECNOLOG&Iacute;A, luego de m&aacute;s de 5 a&ntilde;os que no se realizaron este tipo de eventos y como un homenaje al BICENTENARIO DE POTOS&Iacute;, se logr&oacute; hacer realidad el mismo, compartiendo esfuerzos con el Gerente regional de FAUTAPO.</p>

<p>Consideramos que la publicaci&oacute;n de este evento que cont&oacute; con la participaci&oacute;n de todas las unidades acad&eacute;micas de la Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as y de instituciones invitadas para tal efecto y habiendo constatado que se presentaron diferentes tem&aacute;ticas que fortalecen la actividad investigativa de docentes y estudiantes como una l&iacute;nea de acci&oacute;n que nos permita promover, incentivar y conducir la investigaci&oacute;n Cient&iacute;fica y tecnol&oacute;gica en un alto grado.</p>
', '5', '1');

-- INSERT DATA roles
INSERT INTO roles (id, nombre, descripcion) VALUES ('1', 'admin', 'control total');
INSERT INTO roles (id, nombre, descripcion) VALUES ('2', 'director', 'control total');
INSERT INTO roles (id, nombre, descripcion) VALUES ('3', 'usuario', 'ciertos modulos');
INSERT INTO roles (id, nombre, descripcion) VALUES ('4', 'coordinador', 'control medio');

-- INSERT DATA trabajo_investigacion
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('5', '18', '42', 'AUTOMATIZACIÓN Y MONITOREO DEL INVERNADERO DE LA LOCALIDAD DE CHAQUI', '1', '2', '<p>Implementar un sistema para automatizar y monitorear un invernadero el cual nos permita ajustar las variables de temperatura, humedad y realice el riego autom&aacute;tico, los cuales se controlen por PID mediante un PLC y se supervisen mediante un sistema SCADA para el Invernadero de la localidad de Chaqui.</p>
',  E'<p>El proyecto consiste en realizar la automatizaci&oacute;n y monitoreo de un invernadero localizado en Chaqui, dentro de un invernadero es posible obtener condiciones artificiales de microclima, y con ello cultivar plantas fuera de estaci&oacute;n en condiciones &oacute;ptimas, al no estar expuesto a los cambios dr&aacute;sticos de clima y a las causas naturales, los cultivos que est&eacute;n dentro del invernadero estar&aacute;n totalmente protegidos, as&iacute; tambi&eacute;n lo estar&aacute;n de las posibles plagas o bacterias. El cultivo bajo invernadero siempre ha permitido obtener producciones de primera calidad y mayores rendimientos, en cualquier &eacute;poca del a&ntilde;o.</p>

<p>Se pretende realizar una investigaci&oacute;n para el desarrollo de la automatizaci&oacute;n y monitorizaci&oacute;n; Para la automatizaci&oacute;n se requieren sensores de humedad, de viento y de<br />
\\r\\ntemperatura y actuadores los cuales trabajaran con variables de temperatura, humedad y viento, realizando un control PID mediante un PLC se pretende establecer las condiciones de forma ideal para el cultivo, permitiendo ingresar un punto de ajuste para cada variable, accionando el riego autom&aacute;tico por goteo, abriendo dos ventanas cenitales y accionando el sistema de ventilaci&oacute;n si la temperatura es alta, o accionando un sistema de calefacci&oacute;n si la temperatura es baja, de esta forma todas estas variables ser&aacute;n monitoreadas por el PLC y llevado a una computadora para su visualizaci&oacute;n mediante un sistema SCADA que facilite la interacci&oacute;n, y supervisi&oacute;n.</p>
', '<ul>
	<li>Los c&aacute;lculos obtenidos nos permiten seleccionar de manera ideal los sensores y/o actuadores requeridos.</li>
	<li>El prototipo funciona de manera ideal accionando los actuadores mediante la lectura de los sensores, aun cuando no fue posible implementar el sistema PID.</li>
	<li>Se obtiene una lectura precisa tanto en el Display como en el sistema Scada realizado en Labview.</li>
	<li>Se pretende tener un impacto econ&oacute;mico al transferir la tecnolog&iacute;a del dise&ntilde;o y desarrollo de invernaderos para mejorar las pr&aacute;cticas agr&iacute;colas.</li>
	<li>Al tener condiciones ambientales controladas en el cultivo bajo invernadero, se garantiza la producci&oacute;n aun con condiciones clim&aacute;ticas adversas como heladas, granizadas, sequ&iacute;as y hasta plagas derivadas de estas condiciones.</li>
	<li>La parte ambiental se ve favorecida, al contar con un riego controlado, se mejorar&aacute; el aprovechamiento del agua, pues solo se usar&aacute; la m&iacute;nima necesaria, de manera que los mantos fri&aacute;ticos no se afectar&iacute;an.</li>
	<li>El sistema de riego automatizado puede ser replicado con componentes accesibles en mercado local e implementado por agricultores.</li>
	<li>En raz&oacute;n que el sistema de riego del invernadero es aut&oacute;nomo, el agricultor puede dedicarse a m&aacute;s labores productivas.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_18_38.pdf', 'UNIV. CRISTIAN GADIEL ALARCON CHOQUE', '2018', '0', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('3', '8', '14', 'USO DE FILTROS BIOLÓGICOS (BIO-FILTROS) PARA LA REMOCIóN DE NUTRIENTES EN AGUAS GRISES, CON ESPECIES FORRAJERAS; GRAMíNEAS Y LEGUMINOSAS ADAPTADAS AL MUNICIPIO DE VILLAZON', '1', '2', '<p>Usar Filtros biol&oacute;gicos (bio-filtros) para la remoci&oacute;n de nutrientes en aguas grises, con especies forrajeras; gram&iacute;neas y leguminosas adaptadas al municipio de villazon.</p>
', '<p>En la calle chichas 10 entre mojo a 50 metros del rio internacional se llev&oacute; a cabo el Uso Filtros biol&oacute;gicos (bio-filtros) para la remoci&oacute;n de nutrientes en aguas grises, con especies forrajeras; gram&iacute;neas y leguminosas adaptadas al municipio de villazon.</p>

<p>Disminuir el grado de contaminaci&oacute;n por aguas servidas con la utilizaci&oacute;n de biofiltros.</p>

<p>Adaptabilidad de las especies forrajeras.</p>

<p>Adaptabilidad de este m&eacute;todo bajo estas condiciones climatol&oacute;gicas dado q el m&eacute;todo usado es muy frecuente en la zona centroamericana.</p>

<p>An&aacute;lisis de aguas al inicio y al final del proceso.</p>

<p>Es un trabajo que determina la importancia de tratar aguas residuales con el fin de cuidar y preservar el medio ambiente, este trabajo de investigaci&oacute;n dio como resultado que los biofiltros empleados para tratar las aguas grises son los siguientes.</p>

<ul>
	<li>El uso de bio filtros con leguminosas resulta m&aacute;s efectivo para la remoci&oacute;n de nutrientes en aguas grises</li>
	<li>El desperdicio total de agua gris o sucia fue de 4363,075 litros de agua en los meses de agosto, septiembre, octubre, noviembre y diciembre.</li>
	<li>Se redujo de 2790 milibares a un 576,10 milibares con las leguminosas teniendo un 79,35% con relaci&oacute;n al agua gris y un 11,58 % con relaci&oacute;n al agua potable y su acercamiento a la neutralidad esto en las leguminosas.</li>
	<li>Se redujo de 2790 milibares a un 666,30 milibares con las gram&iacute;neas teniendo un 76,12 % con relaci&oacute;n al agua gris y un 30,80 % con relaci&oacute;n al agua potable y su acercamiento a la neutralidad esto en las gram&iacute;neas.</li>
	<li>Se redujo en buen tama&ntilde;o el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,20 de pH neutro ligero con relaci&oacute;n al patr&oacute;n de referencia 7 en leguminosas.</li>
	<li>Se redujo en buen tama&ntilde;o el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,36 de pH neutro ligero con relaci&oacute;n al patr&oacute;n de referencia 7 en gram&iacute;neas.</li>
	<li>El uso de filtros biol&oacute;gicos confirma la efectividad y la necesidad de implantar filtros biol&oacute;gicos en domicilios cercanos a r&iacute;os, vertientes, lagunas, lagos, etc. Con el fin de reducir el impacto ambiental</li>
	<li>Los filtros biol&oacute;gicos pueden funcionar como jardines para especies florales en el caso de las leguminosas.</li>
</ul>
', '<p>De acuerdo a los objetivos planteados y resultados obtenidos, en el presente trabajo de investigaci&oacute;n, se lleg&oacute; a las siguientes conclusiones:</p>

<ul>
	<li>El uso de bio filtros con leguminosas resulta m&aacute;s efectivo para la remoci&oacute;n de nutrientes en aguas grises.</li>
	<li>El desperdicio total de agua gris o sucia fue de 4363,075 litros de agua en los meses de agosto, septiembre, octubre, noviembre y diciembre.</li>
	<li>Se redujo de 2790 milibares a un 576,10 milibares con las leguminosas teniendo un 79,35% con relaci&oacute;n al agua gris y un 11,58 % con relaci&oacute;n al agua potable y su acercamiento a la neutralidad esto en las leguminosas.</li>
	<li>Se redujo de 2790 milibares a un 666,30 milibares con las gram&iacute;neas teniendo un 76,12 % con relaci&oacute;n al agua gris y un 30,80 % con relaci&oacute;n al agua potable y su acercamiento a la neutralidad esto en las gram&iacute;neas.</li>
	<li>Se redujo en buen tama&ntilde;o el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,20 de pH neutro ligero con relaci&oacute;n al patr&oacute;n de referencia 7 en leguminosas.</li>
	<li>Se redujo en buen tama&ntilde;o el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,36 de pH neutro ligero con relaci&oacute;n al patr&oacute;n de referencia 7 en gram&iacute;neas.</li>
	<li>El uso de filtros biol&oacute;gicos confirma la efectividad y la necesidad de implantar filtros biol&oacute;gicos en domicilios cercanos a r&iacute;os, vertientes, lagunas, lagos, etc. Con el fin de reducir el impacto ambiental.</li>
	<li>Los filtros biol&oacute;gicos pueden funcionar como jardines para especies florales en el caso de las leguminosas.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_32_56.pdf', 'UNIV. ALFONSO YVER GÓMEZ ARACA', '2018', '1', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('1', '7', '11', 'LA ENSEÑANZA DE LA LENGUA QUECHUA EN EL SISTEMA EDUCATIVO DE LA ESCUELA SAN CRISTOBAL DE LA CIUDAD DE POTOSÍ', '1', '2', '<p>&ldquo;Elaborar un plan nacional para la implementaci&oacute;n de la ense&ntilde;anza de la lengua quechua, desde primero a sexto de primaria, en la unidad educativa San Crist&oacute;bal de la ciudad de potos&iacute;&rdquo;</p>
', '<p>En el presente trabajo de investigaci&oacute;n, se analizara todos los factores que influyen negativamente en el proceso de aprendizaje del idioma quechua en estudiantes de la unidad educativa &ldquo;San Crist&oacute;bal de la ciudad de Potos&iacute;&rdquo;.</p>

<p>Para ello, en primer lugar, se analizaran las diferentes t&eacute;cnicas, estrategias metodol&oacute;gicas y did&aacute;cticas de los docentes del idioma quechua como as&iacute; mismo aspectos que tienen que ver con el rol y entorno del estudiante, ya que las aptitudes del estudiante dentro de lo que es la adquisici&oacute;n u aprendizaje de una determina idioma, depende en gran parte de la subjetividad del estudiante. Al respecto, se presenta la siguiente hip&oacute;tesis Con la aplicaci&oacute;n de m&eacute;todos y t&eacute;cnicas m&aacute;s din&aacute;micos en la ense&ntilde;anza de una segunda lengua como el quechua, mejorara el nivel acad&eacute;mico y manejo de la segunda lengua en los estudiantes de la menci&oacute;n quechua. Teniendo presente esta situaci&oacute;n, se busca establecer cu&aacute;les son las mejores t&eacute;cnicas, m&eacute;todos, estrategias, que deben ser utilizados por los docentes a momento de proceder a ense&ntilde;ar el idioma quechua y dentro de que circunstancias o contexto deben ser empleadas.</p>
', '<p>En el presente capitulo se presentan las conclusiones y propuestas que tienen como prop&oacute;sito eficientizar el proceso de ense&ntilde;anza-aprendizaje en las distintas clases de ingl&eacute;s en sus diferentes modalidades, mediante el uso del material autentico.</p>

<p>Respecto a la percepci&oacute;n de los alumnos acerca de la planeaci&oacute;n del trabajo docente, se puede constatar que efectivamente la planificaci&oacute;n de la clase de ingl&eacute;s regularmente se lleva a cabo, no obstante se deja entrever de que es una actividad que requiere consolidar su funci&oacute;n.</p>

<p>As&iacute; mismo se puede observar que por lo general el profesor realiza una planeaci&oacute;n escrita de sus clases, sin embargo es necesario reforzar esta tarea ya que no se refleja en su totalidad en el aula. Por otra parte se aprecia que el profesorado opina que efectivamente, la planificaci&oacute;n de la clase de ingl&eacute;s se lleva a cabo en su totalidad. De igual manera, seg&uacute;n su apreciaci&oacute;n se puede concluir que en el mayor de los casos, el docente lleva a cabo la definici&oacute;n de estrategias que llevara a cabo durante la clase, no obstante, existe casi una quinta parte de los profesores que opina que solo algunas veces efect&uacute;an esta tarea. Los profesores de ingl&eacute;s refieren que, en dicha planeaci&oacute;n definen los materiales que usan en el desarrollo de la clase, lo cual les permite tener un mejor control sobre los apoyos que utiliza en el aula.</p>
', '2019-07-19', 'dicyt_2019_07_19_20_18_13.pdf', 'UNIV. OMAR CONDORI MENACHO', '2018', '3', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('9', '13', '35', 'DISEÑO DE UN SISTEMA DE CONTROL DE INVENTARIOS PARA LA EMPRESA CONSTRUCTORA ', '1', '2',  E'<p>Dise&ntilde;ar un sistema de control de inventarios para la Empresa Constructora &ldquo;ECO RAL&rdquo; S.R.L. El cual permitir&aacute; optimizar sus recursos y establecer un control confiable y adecuado a sus necesidades.</p>\\r\\n',  E'<p>El presente Trabajo de Investigaci&oacute;n corresponde a un Dise&ntilde;o de un Sistema de Control de Inventarios para la Empresa Constructora &ldquo;ECO RAL&rdquo; S.R.L., el inter&eacute;s<br />\\r\\nen el desarrollo de este trabajo radica en el estudio de esta Empresa Constructora y espec&iacute;ficamente en el control de sus inventarios que es la esencia de su giro.</p>\\r\\n\\r\\n<p>Con la evoluci&oacute;n tecnol&oacute;gica, la Empresa se ha visto en la necesidad de prestar mayor atenci&oacute;n a la planificaci&oacute;n y control de sus inventarios ya que estos constituyen la principal fuente de sus ingresos, de all&iacute; que un buen control de los inventarios y su eficiente aplicaci&oacute;n garantizar&aacute; la continuaci&oacute;n de la empresa.</p>\\r\\n\\r\\n<p>La situaci&oacute;n antes expuesta hace necesario establecer lineamientos que permitan a la empresa un mejor y eficaz control de sus inventarios, es por ello la realizaci&oacute;n<br />\\r\\ndel presente trabajo de investigaci&oacute;n, la cual estar&aacute; orientada al Dise&ntilde;o de un Sistema de Control de Inventarios para la Empresa Constructora &ldquo;ECO RAL&rdquo;<br />\\r\\nS.R.L.</p>\\r\\n\\r\\n<p>El objetivo que se plantea es: Dise&ntilde;ar un Sistema de Control de Inventarios para la Empresa Constructora &ldquo;ECO RAL&rdquo; S.R.L. El cual permitir&aacute; optimizar sus<br />\\r\\nrecursos y establecer un control confiable y adecuado a sus necesidades.</p>\\r\\n',  E'<p>El dise&ntilde;o de un sistema de control de inventarios en cuanto al manejo de existencias y materiales de la empresa constructora permitir&aacute;, visualizar la trayectoria correcta de la informaci&oacute;n sobre las compras realizadas, evitando trastornos, en la entrega, recepci&oacute;n, almacenamiento, pago y utilizaci&oacute;n de materiales en la producci&oacute;n o el posible desv&iacute;o en el uso de los materiales.</p>\\r\\n\\r\\n<p>Con la ejecuci&oacute;n del nuevo sistema se lograr&aacute; llenar las expectativas, los requerimientos y las exigencias por parte de la Empresa, lo cual es indispensable para el desarrollo del sistema y permitir&aacute; obtener mejores resultados que se reflejen en los estados financieros, donde se podr&aacute; analizar las cuentas y as&iacute; determinar con firmeza y seguridad cuales deben ser las proyecciones y acciones correctivas que se deben realizar en la empresa.</p>\\r\\n\\r\\n<p>Este Dise&ntilde;o del Sistema de Inventario le garantizara a la empresa una disminuci&oacute;n de las fallas, que se presentan dentro del almac&eacute;n y as&iacute; llevar una eficiente y exitosa administraci&oacute;n de los recursos existentes.</p>\\r\\n\\r\\n<p>Por la importancia que representa los inventarios para la Empresa objeto de estudio, es necesario manejarlos de forma eficiente por medio de sistemas y procedimientos, los cuales permitan obtener el m&aacute;ximo rendimiento de los mismos.</p>\\r\\n\\r\\n<p>La empresa cuenta con medidas emp&iacute;ricas del manejo de los inventarios que no est&aacute;n dentro de un sistema. Lo cual, genera inconvenientes detectados y resumidos en la hoja de hallazgos. En base a este argumento se menciona que es necesario implementar el Dise&ntilde;o de Sistema de Control de Inventarios propuesto con la finalidad de optimizar recursos, evitar robos y fraudes.</p>\\r\\n\\r\\n<p>En la actualidad el flujo de informaci&oacute;n de sus inventarios es incierto e incorrecto. Por lo que se ha dise&ntilde;ado formatos para cada tipo de movimiento de mercader&iacute;a esto ayudara a llevar un adecuado control del movimiento de los inventarios.</p>\\r\\n\\r\\n<p>Si no se dise&ntilde;an procedimientos adecuados y l&oacute;gicos para el desarrollo de las actividades en el &aacute;rea de Inventarios, se corre el riesgo de que exista duplicidad de tareas, demora en la prestaci&oacute;n del servicio a otras &aacute;reas, personal innecesario y emisi&oacute;n de informaci&oacute;n incorrecta, etc.</p>\\r\\n\\r\\n<p>La empresa no cuenta con un encargado de almacenes para el manejo y control de los inventarios. Por lo cual se ha dise&ntilde;ado un manual de funciones detallando las responsabilidades y obligaciones, con el objetivo del manejo correcto de la existencias y materiales.</p>\\r\\n\\r\\n<p>La constante revisi&oacute;n, control y mejoramiento de las normas y procedimientos relacionados con los inventarios de la Empresa de Construcci&oacute;n, mejora la eficiencia de sus operaciones, reduce el riesgo de malversaciones y se obtiene informaci&oacute;n oportuna y confiable.</p>\\r\\n', '2019-07-19', 'dicyt_2019_07_19_22_31_33.pdf', 'UNIV. REINA REBECA RIVERA HERRERA', '2018', '0', 'LIC. RAUL CADENA TERAN', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('6', '1', '26', 'SISTEMA DE GESTIÓN BAJO PLATAFORMA WEB PARA UNA MEJOR ADMINISTRACION DE LA INFORMACIÓN EN EL CENTRO DE ESTUDIANTES DE LA CARRERA INGENIERÍA DE SISTEMAS', '1', '2', '<p>NO DISPONIBLE</p>
', '<p>El centro de estudiantes, es el &oacute;rgano natural de representaci&oacute;n, participaci&oacute;n, discusi&oacute;n y organizaci&oacute;n del estamento estudiantil de la carrera de ingenier&iacute;a de sistemas para la defensa y protecci&oacute;n de sus derechos.</p>

<p>Sin embargo la falta de un sistema que permita procesar y organizar la informaci&oacute;n que se genera de una forma m&aacute;s &aacute;gil y eficaz, dificulta cumplir tal objetivo.</p>

<p>Debido a lo anteriormente mencionado, surge la necesidad de desarrollar un sistema que logre mejorar y agilizar los procesos implicados en el manejo de informaci&oacute;n del centro de estudiantes de la carrera de ingenier&iacute;a de sistemas.</p>

<p>Para la elaboraci&oacute;n del sistema y el cumplimiento de los objetivos trazados se utiliz&oacute; la metodolog&iacute;a Scrum. Adem&aacute;s durante la fase de desarrollo se usaron diversas herramientas de las que resaltan el lenguaje de programaci&oacute;n PHP bajo el framework Laravel y el sistema manejador de base de datos MySQL.</p>

<p>Una vez finalizada la fase de desarrollo y corregidos los errores encontrados durante la fase de pruebas, se procedi&oacute; a la implementaci&oacute;n y capacitaci&oacute;n del personal, concluy&eacute;ndose de esta manera que el proyecto mejora el procesamiento de informaci&oacute;n de estudiantes y por tanto es de utilidad en el logro de los objetivos impuestos.</p>
', '<p>El desarrollo de presente trabajo, permiti&oacute; cumplir las tareas inicialmente planteadas y de esta forma cumplir con el objetivo general trazado, como resultado se obtienen las siguientes conclusiones:</p>

<ul>
	<li>El marco te&oacute;rico sustenta la presente investigaci&oacute;n, realizado mediante la investigaci&oacute;n, an&aacute;lisis y s&iacute;ntesis de una serie de postulados bibliogr&aacute;ficos de manera que permitan fundamentar las diferentes herramientas utilizadas para el desarrollo del presente proyecto.</li>
	<li>Mediante el diagn&oacute;stico de los procesos de control y seguimiento de la informaci&oacute;n y los m&eacute;todos actuales usados en la realizaci&oacute;n de tareas que componen tales procesos, se pudo determinar que la realizaci&oacute;n de tales procesos se realiza de forma manual, lo cual pod&iacute;a producir informaci&oacute;n poco oportuna y susceptible a fallos.</li>
	<li>La metodolog&iacute;a Scrum, permiti&oacute; la planificaci&oacute;n del presente proyecto, usando para ello las historias de usuario para conformar la pila del producto y de esta formar fijar los requerimientos y posterior inicio de los sprints.</li>
	<li>Se efectu&oacute; la implementaci&oacute;n del sistema propuesto usando el lenguaje de programaci&oacute;n PHP, el framework Laravel 5.5 bajo el patr&oacute;n Modelo-Vista-Controlador y MySQL como gestor de bases de datos, debido a su f&aacute;cil integraci&oacute;n con el resto de las herramientas escogidas.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_20_14.pdf', 'UNIV. HERALD CHOQUE VARGAS', '2018', '1', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('8', '8', '14', 'FORMULACION DE TRES RACIONES ALIMENTICIAS PARA LA GANANCIA DE PESO EN CUYES ( CAVIA PORCELLUS ) EN EL MUNICIPIO DE VILLAZON DE LA PROVINCIA MODESTO OMISTE', '1', '2', '<p>Formular tres raciones alimenticias y observar cual tiene el mejor efecto en la ganancia de peso en cuyes (Cavia porcellus) en crecimiento.</p>
', '<p>no disponible</p>
', '<ul>
	<li>El consumo de alimento de acuerdo a los datos obtenidos indica que la raci&oacute;n alfalfa + balanceado presenta el mayor dato con 4251 gr. seguida de la raci&oacute;n germinado + balanceado con 4081 gr. Y la raci&oacute;n chala + balanceado presenta un dato inferior con 4074, en cuanto al cuadro ANVA se demostr&oacute; estad&iacute;sticamente que no existen diferencias significativas.</li>
	<li>En cuanto a ganancia de peso se observa que la raci&oacute;n alfalfa + balanceado presenta mayor dato con 582 gr. seguida de la raci&oacute;n germinado + balanceado con 529,50 gr. Y por &uacute;ltimo la raci&oacute;n chala + balanceado con 528,50 gr, el cuadro ANVA presenta diferencias significativas entre repeticiones, en la prueba de Duncan se observa la formaci&oacute;n de tres grupos significativamente diferentes entre raciones.</li>
	<li>En la conversi&oacute;n alimenticia indica que la raci&oacute;n alfalfa + balanceado obtuvo un dato de 7.5, seguido de la raci&oacute;n germinado + balanceado con 7,6 y por &uacute;ltimo la raci&oacute;n chala + balanceado con 7,7, en el cuadro ANVA indica existen diferencias significativas entre repeticiones, en la prueba Dunkan se observa la formaci&oacute;n de tres grupos significativamente diferentes entre las variedades.</li>
	<li>En el rendimiento a la carcaza se observa que la racion alfalfa + balanceado tiene un dato de 62% seguido de las raciones germinado + balanceado y chala + balanceado con un dato de 61%, el cuadro ANVA indica que no existen diferencias significativas.</li>
	<li>En la relaci&oacute;n Beneficio/Costo tomando en cuenta solo en cuenta los gastos de alimentaci&oacute;n de los cuyes se tiene un dato de 1.03 Bs lo que nos indica que la actividad de crianza es rentable.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_33_56.pdf', 'UNIV. JUAN LEONEL LOPEZ TITO', '2018', '2', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('10', '5', '38', 'COMPARACIÓN TÉCNICO ECONÓMICA ENTRE EL TRATAMIENTO ACTIVO CON CAL Y EL SISTEMA PASIVO RAPS EN MINA COLQUECHAQUITA PARA MINIMIZAR LOS CONTAMINANTES DEL DAM', '1', '2', '<p>Comparaci&oacute;n t&eacute;cnico econ&oacute;mico entre el tratamiento activo con cal y el sistema pasivo RAPS en la Mina Colquechaquita para minimizar el DAM.</p>
', '<p>Los drenajes de aguas &aacute;cidas de minas y los metales asociados a ellas son un problema ambiental y ecol&oacute;gico, por lo que existe la necesidad de aplicar tecnolog&iacute;as basadas en sistemas de tratamiento pasivo.</p>

<p>El objeto de estudio son las aguas acidas de mina Colquechaquita que se encuentra ubicada a 4600 m.s.n.m. al sud este de la ciudad de Potos&iacute;.</p>

<p>El trabajo de investigaci&oacute;n:<strong> &ldquo;COMPARACION TECNICO ECONOMICA ENTRE EL TRATAMIENTO ACTIVO CON CAL Y EL SISTEMA PASIVO RAPS EN MINA COLQUECHAQUITA PARA MINIMIZAR LOS CONTAMINANTES DEL DAM&rdquo;</strong> el objetivo es realizar un tratamiento pasivo anaer&oacute;bico a muestras de agua &aacute;cida tomada de la mina Colquechaquita, utilizando caliza y esti&eacute;rcol bovino a nivel de laboratorio para evaluar el comportamiento del pH en este tratamiento.</p>

<p>Los materiales de relleno propuesto son agentes reductores activos, como la materia org&aacute;nica esti&eacute;rcol de bovino y la caliza como agente neutralizador de la acidez.</p>

<p>La caliza (CaCO3) es un mineral carbonatado abundante en la zona que consume &aacute;cido a trav&eacute;s de la formaci&oacute;n de bicarbonato (HCO3) o &aacute;cido carb&oacute;nico (H2CO3) y podemos afirmar que tiende a neutralizar las soluciones llev&aacute;ndolas hasta un pH neutro.</p>

<p>Para el estudio se dise&ntilde;a un tanque a escala de laboratorio cuyo volumen es de veinte litros, en la parte inferior se rellena con graba de caliza y en la parte superior se complementa con esti&eacute;rcol de bovino, y hace discurrir un flujo de agua &aacute;cida en forma descendente por la parte inferior se toma la muestra para analizar el par&aacute;metro pH.</p>

<p>Los resultados obtenidos de esta investigaci&oacute;n nos llevaran a la comparaci&oacute;n t&eacute;cnico econ&oacute;mica entre el sistema actual que realizan que es el de tratamiento activo con cal.</p>
', '<ul>
	<li>Dentro de las pruebas realizadas en laboratorio (sistema de reducci&oacute;n de alcalinidad escala laboratorio), se concluye que el uso de estas servir&aacute; para tomarlo encuentra como un tratamiento primario, en cuanto se refiere a un tratamiento pasivo de RAPS de la mina Colquechaquita se ha logrado elevar el ph de 2-3 inicial a ph de 5-6 en promedio total.</li>
	<li>Dentro de los factores que influyen en el sistema de tratamiento son el caudal, tama&ntilde;o de grano, en funci&oacute;n a estas se tendr&aacute;n resultados y logrando una mejor reacci&oacute;n qu&iacute;mica.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_17_36.docx', 'UNIV. RENE VILLCA CRUZ', '2018', '1', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('15', '13', '31', 'EFECTOS DE LA PRODUCCIÓN DEL SECTOR MINERO SOBRE LA CONTAMINACIÓN AMBIENTAL DEL MUNICIPIO DE UNCÍA', '1', '2', '<p>Determinar el efecto que tiene la producci&oacute;n en el sector minero sobre la contaminaci&oacute;n ambiental en el municipio de Unc&iacute;a.</p>
', '<p>El presente trabajo de investigaci&oacute;n se bas&oacute; en el an&aacute;lisis del efecto de la producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a durante periodo de a&ntilde;os 2000 &ndash; 2017 tomando en cuenta a la poblaci&oacute;n en general.</p>

<p>Al tomar en cuenta las causas y s&iacute;ntomas en la investigaci&oacute;n se lleg&oacute; a plantear el siguiente problema de investigaci&oacute;n &iquest;Cu&aacute;l es el efecto que tiene la producci&oacute;n del sector minero en la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a?.</p>

<p>Soluci&oacute;n: se tom&oacute; como principal objetivo el determinar el efecto que tiene la producci&oacute;n en el sector minero sobre la contaminaci&oacute;n ambiental en el municipio de Unc&iacute;a.</p>

<p>Para lo cual se hizo una estructura en el presente trabajo de investigaci&oacute;n que lleva una introducci&oacute;n, tres cap&iacute;tulos conclusiones y recomendaciones.</p>

<p>En el cap&iacute;tulo I se refleja el an&aacute;lisis de los fundamentos te&oacute;ricos relacionados con la producci&oacute;n minera y la contaminaci&oacute;n ambiental, en el cap&iacute;tulo II diagn&oacute;stico de las caracter&iacute;sticas de la situaci&oacute;n actual de la producci&oacute;n mineral y la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a, en el cap&iacute;tulo III se pudo establecer la estimaci&oacute;n del efecto de la producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a mediante un modelo econom&eacute;trico as&iacute; llegando a comprobar la hip&oacute;tesis planteada. Finalmente se obtuvo las conclusiones m&aacute;s significativas sobre el trabajo de investigaci&oacute;n procediendo a realizar las respectivas recomendaciones.</p>

<p>Todo el proceso de investigaci&oacute;n se llev&oacute; a cabo con la ayuda de bibliograf&iacute;a existente aportes te&oacute;ricos, la colaboraci&oacute;n de las autoridades y poblaci&oacute;n del municipio de Unc&iacute;a.</p>
', '<p>El objetivo del presente trabajo era poder analizar el efecto de la Producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a, con los hechos relevantes expuestos en los cap&iacute;tulos I, II y III, en los que se examin&oacute; tanto la parte te&oacute;rica y los indicadores cuantitativos, as&iacute; estableciendo de esta manera las siguientes conclusiones de acuerdo a los objetivos espec&iacute;ficos:</p>

<ul>
	<li>De acuerdo a las teor&iacute;as revisadas y analizadas, partiendo desde la teor&iacute;a neocl&aacute;sica con Pigou y Coase, la misma est&aacute; enfocada a la valoraci&oacute;n monetaria de los beneficios y costos ambientales. la teor&iacute;a , hasta llegar al an&aacute;lisis de Pearce y Turner,. Todas estas teor&iacute;as muestran el fuerte nexo que tiene la producci&oacute;n minera en la contaminaci&oacute;n ambiental pero la teor&iacute;a que m&aacute;s se acerca explicar el presente trabajo es la teor&iacute;a de Arthur Cecil Pigou indica varias alternativas para luchar contra la contaminaci&oacute;n ambiental entre las mas importantes es el impuesto Pigouviano la cual establece que todo individuo que haga uso del medio ambiente deber&aacute; retribuir un aporte econ&oacute;mico en benefio al medio ambiente pero en la investigaci&oacute;n se demuestra que, si existe una contaminaci&oacute;n ambiental y no existen pol&iacute;ticas ambientales asi como plantea la teor&iacute;a.</li>
	<li>En el periodo de estudio se evidencio fluctuaciones en la producci&oacute;n minera ya sea por los precios de los minerales y variaci&oacute;n en los socios a trav&eacute;s de los a&ntilde;os, se pudo observar que tuvo efecto en el incremento de la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a ya sea directa e indirectamente.</li>
	<li>En el presente trabajo fue muy importante la utilizaci&oacute;n de la econometr&iacute;a por medio de los modelos econom&eacute;tricos que reflejan que existe puntos significativos, coincidentes y consistentes en el efecto de la Producci&oacute;n minera y el incremento en la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_19_43.pdf', 'UNIV. VICTOR HUGO DELGADO CAERO', '2018', '1', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('14', '17', '3', 'VALORACIÓN DE LA MONITORIZACIÓN ELECTRÓNICA FETAL, EN EL RIESGO DE PÉRDIDA DE BIEN ESTAR FETAL, EN EL SERVICIO DE GINECOOBSTETRICIA DEL HOSPITAL OBRERO Nº 5 DE LA CIUDAD DE POTOSÍ EN LOS MESES DE  MARZO ', '1', '2', '<p>Conocer la valoraci&oacute;n de la monitorizaci&oacute;n electr&oacute;nica fetal, en el riesgo de p&eacute;rdida de bien estar fetal, en pacientes atendidas en el SERVICIO DE GINECOOBSTETRICIA DEL HOSPITAL OBRERO N&ordm; 5 de la ciudad de Potos&iacute; en los meses de marzo-agosto de 2018.</p>
', '<p>El presente trabajo de investigaci&oacute;n tiene como objetivo &ldquo;Determinar la valoraci&oacute;n de la monitorizaci&oacute;n electr&oacute;nica fetal, en el riesgo de la p&eacute;rdida del bienestar fetal, en el servicio de ginecolog&iacute;a y obstetricia&nbsp; del Hospital Obrero de N&ordm; 5 de la ciudad de Potos&iacute;, entre los meses de Marzo a Agosto del a&ntilde;o 2018&rdquo;. Se realiz&oacute; una investigaci&oacute;n de tipo descriptivo, prospectivo y de corte transversal; La muestra estuvo constituida por 68 usuarias a las que se les realiz&oacute; el monitoreo fetal electr&oacute;nico durante el periodo intraparto. Las t&eacute;cnica utilizadas para la obtenci&oacute;n de la informaci&oacute;n fueron mediante la revisi&oacute;n documental de historias cl&iacute;nicas, para obtener un soporte te&oacute;rico, tambi&eacute;n se utiliz&oacute; el test de Dexeus; el procesamiento se expres&oacute; en tablas estad&iacute;sticas y gr&aacute;ficos, de discusi&oacute;n y s&iacute;ntesis, comparando de acuerdo a las variables para buscar los objetivos trazados.</p>

<p>Los datos obtenidos indican que de 68 pacientes que se les realiz&oacute; el Test de Dexeus, 71% es reactivo y &nbsp;el 29% no es reactivo.&nbsp; De las 68 pacientes el 46 % tiene un resultado normal, el 31% tiene un resultado Pre patol&oacute;gico y el 23% tiene un resultado patol&oacute;gico.</p>

<p>El estudio ha permitido observar que dicho monitoreo, ciertamente es una prueba que permite una mejor detecci&oacute;n del curso normal o anormal de la condici&oacute;n fetal, sin embargo no es definitorio con respecto a la condici&oacute;n del reci&eacute;n nacido.</p>
', '<ul>
	<li>EL Monitoreo Fetal Electr&oacute;nico es una prueba de bienestar utilizada con mucha frecuencia a nivel hospitalario de atenci&oacute;n obst&eacute;trica ya sea en pacientes con embarazos de riesgo o en aquellas que no presenten riesgo.</li>
	<li>La realizaci&oacute;n de monitor&eacute;os continuos en pacientes en gestaci&oacute;n nos permite determinar si existe una alteraci&oacute;n el bienestar.</li>
	<li>La realizaci&oacute;n de monitor&eacute;os a mujeres durante el trabajo de parto han reducido la incidencia de reci&eacute;n nacidos con Apgar bajo al nacimiento.</li>
	<li>La inadecuada interpretaci&oacute;n del monitoreo fetal electr&oacute;nica aumentan el riesgo de complicaciones en el reci&eacute;n nacido.</li>
	<li>La monitorizaci&oacute;n fetal realizada en gestantes en labor de parto, es de gran utilidad para la valoraci&oacute;n uterina y del estado fetal pues ayuda a tomar una decisi&oacute;n ante cualquier signo de alarma para culminar con el embarazo.</li>
	<li>El patr&oacute;n alterado de frecuencia cardiaca fetal nos orienta a terminaci&oacute;n del embarazo, pero no determina el da&ntilde;o real al cual nos podemos enfrentar posterior al nacimiento, a un latido cardiaco normal.</li>
	<li>En la mayor&iacute;a de las veces el trazado de la cardiotocograf&iacute;a esta alterado por la frecuencia cardiaca fetal y por desaceleraciones variables o tard&iacute;as, la observaci&oacute;n de desaceleraciones nos suministra informaci&oacute;n sobre la interacci&oacute;n del estado fetal y la actividad uterina.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_22_25.docx', 'UNIV. LILIAN GRISSEL GUTIERREZ ROJAS', '2018', '0', 'DR. JOSÉ RICALDI PINTO', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('11', '13', '35', 'INFLUENCIA DEL ESTRÉS EN EL RENDIMIENTO ACADÉMICO EN LOS ESTUDIANTES DE LA UNIVERSIDAD AUTÓNOMA ', '1', '2', '<p>Determinar la influencia del .estr&eacute;s en el rendimiento acad&eacute;mico en los estudiantes de la Universidad Aut&oacute;noma &ldquo;Tom&aacute;s Fr&iacute;as&rdquo; Carrera de Auditoria - Contadur&iacute;a P&uacute;blica Sede Tupiza.</p>
', '<p>El presente trabajo de investigaci&oacute;n trata sobre la influencia que tiene el estr&eacute;s en el rendimiento acad&eacute;mico, lo cual es una reacci&oacute;n cada vez m&aacute;s extendida entre los universitarios por las situaciones estresantes que identificamos en el presente trabajo.</p>

<p>El estr&eacute;s en los estudiantes no recibe la suficiente atenci&oacute;n , porque los factores estresantes son d&iacute;a a d&iacute;a , como lo son la salud f&iacute;sica y mental, imprevistos, pruebas objetivas, trabajos investigativos relaciones interpersonales inadecuadas a los que todo joven o persona enfrenta de diversas maneras afectando sin duda su desempe&ntilde;o acad&eacute;mico al no saber de qu&eacute; manera actuar ante m&uacute;ltiples est&iacute;mulos como ser el cansancio, agotamiento alta presi&oacute;n laboral, excesiva competitividad, entre otros.</p>

<p>El alcance de la investigaci&oacute;n fue de tipo descriptivo a estudiantes la UNIVERSIDAD AUT&Oacute;NOMA &ldquo;TOM&Aacute;S FR&Iacute;AS&rdquo; CARRERA DE AUDITOR&Iacute;A - CONTADUR&Iacute;A P&Uacute;BLICA SEDE TUPIZA, lo cual se aplic&oacute; encuestas y entrevistas para llegar a resultados que muestran que el estr&eacute;s si influye en el rendimiento acad&eacute;mico, en el &aacute;mbito general no significativamente; Pero siempre est&aacute; en cada una de las personas no siempre en los estudiantes no se puede eliminar pero si se puede controlar con actitud positiva lo cual guiar&aacute; al &eacute;xito y si se lo toma con actitud negativa esto lo llevara al fracaso.</p>
', '<p>El resultado de la investigaci&oacute;n que es sobre la influencia del estr&eacute;s en el rendimiento acad&eacute;mico, se concluye que los estudiantes de la Universidad Aut&oacute;noma &ldquo;Tomas Fr&iacute;as&rdquo; Carrera de Auditoria - Contadur&iacute;a P&uacute;blica Sede Tupiza, presentan estr&eacute;s que influye mucho sobre su rendimiento acad&eacute;mico ya que se identific&oacute; situaciones estresantes que afecta emocionalmente a la personalidad de cada universitario.</p>

<p>Las factores estresantes de los estudiantes si no son controlados puede ser el factores de un bajo rendimiento acad&eacute;mico lo cual significa el cansancio excesivo, que se presentan a veces con problemas digestivos y alteraciones de sue&ntilde;o provocando dolores de cabeza o migra&ntilde;a esto impide la concentraci&oacute;n en clases induciendo a bajas calificaciones y esto puede afectar su estado emocional de los estudiantes pero en este trabajo de investigaci&oacute;n no hubo caso extremo de estr&eacute;s cr&oacute;nica lo que significa que existe un nivel controlado de estr&eacute;s y un rendimiento acad&eacute;mico regular.</p>

<p>Por otra parte, el estar en un entorno desfavorecedor, con una mala alimentaci&oacute;n, y aumentando problemas familiares, econ&oacute;micos o acad&eacute;micos, provocan la que los estudiantes mujeres y varones entren en un estado de nerviosismo p&aacute;nico y preocupaci&oacute;n, la diferencia del nivel de estr&eacute;s mujeres son representado en mayor porcentaje del 64% y varones en 36%, esto no significa que solamente las mujeres padecen de preocupaci&oacute;n y nerviosismo: de acuerdo a la investigaci&oacute;n.</p>

<p>Sobre el an&aacute;lisis referido al estr&eacute;s y los resultados obtuvimos se puede concluir que el estr&eacute;s influye en ambos g&eacute;neros y en maneras diferentes, cabe mencionar que la diferencia vista en los niveles de estr&eacute;s que tienen los universitarios es por la existencia de m&aacute;s estudiantes mujeres que varones que son matriculados en la gesti&oacute;n 2018.</p>

<p>El estr&eacute;s acad&eacute;micos porque es como un fen&oacute;meno que tiene como finalidad poder adaptar al organismo ante algunos hechos que suceden durante la vida acad&eacute;mica, los cuales influyen en los estudiantes de forma positiva o negativa.</p>

<p>De manera positiva: permite realizar una actividad con mayor expectativa y de mejor forma, ayudando a tener un rendimiento regular bueno dentro de la facultad, no permitiendo cansar con facilidad y dando mayor capacidad de concentraci&oacute;n. Y de manera Negativa: algunas veces afecta a la realizaci&oacute;n de cualquier actividad.</p>

<p>Finalmente se puede decir que el estr&eacute;s influye siempre en la vida diaria de cada persona sean ni&ntilde;os, adultos, universitarios etc. de acuerdo a la investigaci&oacute;n hace conocer que el estr&eacute;s no puede ser eliminado totalmente, porque siempre existe de alguna manera en porcentaje m&iacute;nima. Por esta raz&oacute;n los estudiantes aprenden a vivir con esa inquietud, cabe decir que el estr&eacute;s, no a gran extremo; puede ser beneficioso para obtener resultados favorables ayuda afrontar los retos y aumentar la autoestima de los estudiantes de la universidad, sabiendo que son capaces de lograr sus objetivos y sentirse satisfecho en el futuro.</p>
', '2019-07-19', 'dicyt_2019_07_19_22_32_12.pdf', 'UNIV. RUTH MARLENY CASTRO PUMA', '2018', '1', 'LIC. JOSÉ LUÍS SARDINAS M.', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('17', '1', '2', 'OBTENCION DEL CLORURO DE MAGNESIO ANHIDRO POR CRISTALIZACIÓN FRACCIONADA A PARTIR DE LAS SALMUERAS DE SALAR DE UYUNI', '1', '2',  E'<ul>\\n	<li>Obtener cloruro de magnesio anhidro por cristalizaci&oacute;n fraccionada a partir de la salmuera de zona Rio Grande&nbsp; del salar de Uyuni en el laboratorio de la carrera de Qu&iacute;mica&nbsp; de la UATF.</li>\\n</ul>\\n',  E'<p>El Salar Uyuni es una de las riquezas m&aacute;s grandes del departamento de Potos&iacute; y del Mundo, Este recurso contiene cantidades considerables de iones de Litio, Potasio, Magnesio y Cloruros que al ser aprovechados presentan una gran cantidad, dado un beneficio&nbsp; socioecon&oacute;mico para la regi&oacute;n.</p>\\r\\n\\r\\n<p>Adem&aacute;s, el cloruro de magnesio tiene la capacidad de retener la humedad absorbida por un tiempo prolongado, el cual depende de las condiciones clim&aacute;ticas prevalecientes. La cantidad de agua absorbida es proporcional a la superficie expuesta de la sal, a la humedad relativa del aire y a la concentraci&oacute;n de MgCl2 en soluci&oacute;n.</p>\\r\\n\\r\\n<p>En la Carrera de Qu&iacute;mica dependiente de la Facultad de Ciencias Puras de la Universidad&nbsp; Aut&oacute;noma &quot; Tomas Fr&iacute;as&quot;&nbsp; se desarroll&oacute; el presente trabajo de investigaci&oacute;n, que consiste en la obtenci&oacute;n &nbsp;de Cloruro de Magnesio por el m&eacute;todo de cristalizaci&oacute;n fraccionada, para ello se escogi&oacute; variables, con el prop&oacute;sito de identificar los factores de influencia en el proceso, estableci&eacute;ndose las siguientes variables: porcentaje de evaporaci&oacute;n, velocidad agitaci&oacute;n, temperatura de enfriamiento.</p>\\r\\n\\r\\n<p>Estas condiciones permitieron obtener resultados aceptables con una pureza 77.5534 y 79.8508 %P MgCl2 y un rendimiento 60.4036 y 60,0420%R MgCl2 Para el control y seguimiento&nbsp; de los componentes&nbsp; importantes magnesio y cloruros se realizaron los an&aacute;lisis qu&iacute;micos por los m&eacute;todos tradicionales volum&eacute;tricos y f&iacute;sico qu&iacute;micos (instrumentales).</p>\\r\\n',  E'<p>A continuaci&oacute;n se presenta las principales conclusiones alcanzadas despu&eacute;s de realizar el an&aacute;lisis e interpretaci&oacute;n de los resultados.</p>\\n\\n<ul>\\n	<li>Los cristales formados durante el proceso de cristalizaci&oacute;n fraccionada en la primera prueba, son cristales de cloruros y complejos de sodio, potasio, las cuales son intervinientes para la obtenci&oacute;n de cloruro de magnesio y necesariamente necesita ser eliminados de la salmuera.</li>\\n	<li>Seg&uacute;n los resultados obtenidos los variables escogidos: El volumen de evaporaci&oacute;n, la temperatura de enfriamiento &nbsp;en el proceso de obtenci&oacute;n de cloruro de magnesio, influye&nbsp; no significativamente .</li>\\n</ul>\\n\\n<ul>\\n	<li>El m&eacute;todo de cristalizaci&oacute;n fraccionada de la salmuera permiti&oacute; la obtenci&oacute;n del cloruro de magnesio, con equipos simples de menor costo y no requiere de otros reactivos, y da mejores resultados en porcentaje de cloruro de magnesio.</li>\\n	<li>Se puede reconocer la existencia de cloruro de magnesio por los cristales peque&ntilde;os en forma de agujas o romboides que tiene.</li>\\n	<li>Los resultados&nbsp; alcanzados muestran que el m&eacute;todo propuesto, proceso de cristalizaci&oacute;n fraccionada, es ventajoso&nbsp; tomando en cuenta la no utilizaci&oacute;n de reactivos costosos que contaminan el medio ambiente.</li>\\n</ul>\\n', '2019-11-04', 'dicyt_2019_11_04_09_49_35.docx', 'UNIV. DAISY  NOHEMY UMIRI GARCíA', '2018', '0', 'LIC. ELENA GARCíA', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('18', '1', '1', 'CONSTRUCCIóN DE CERRADURAS  ELECTRóNICAS UTILIZANDO LA TECNOLOGíA DIGITACIóN POR TECLADO Y PROGRAMACIóN ASOCIADA EN LA CIUDAD  DE POTOSí', '1', '2',  E'<ul>\\r\\n	<li>Construir un sistema de &ldquo;Cerradura Electr&oacute;nica&rdquo;, utilizando el PIC16F877A con el cual, pueda realizarse cerradura autom&aacute;tica, con el fin de obtener seguridad m&aacute;xima, en un tiempo m&iacute;nimo posible que la de forma tradicional.</li>\\r\\n</ul>\\r\\n',  E'<p>NO DISPONIBLE</p>\\r\\n',  E'<p>El proyecto propuesto en este perfil pretende impulsar la fabricaci&oacute;n de cerraduras electr&oacute;nicas en Potos&iacute;&nbsp; mediante un conjunto de acciones de promoci&oacute;n,&nbsp; cursos de actualizaci&oacute;n e inversi&oacute;n.</p>\\r\\n\\r\\n<p>La meta,&nbsp; del proyecto es de llegar en 10 a&ntilde;os&nbsp; a una fabricaci&oacute;n mayor de cerraduras electr&oacute;nicas&nbsp; que produce en la actualidad, estableciendo la base de difusi&oacute;n y crecimiento en los a&ntilde;os posteriores.</p>\\r\\n\\r\\n<p>El proyecto tiene la gran ventaja de contar con proveedores de componentes en todo el tiempo del proyecto.</p>\\r\\n\\r\\n<p>La seguridad en la actualidad es un tema importante, por lo que se dise&ntilde;an cada d&iacute;a mejores equipos como el presentado en este proyecto, donde el acceso a oficinas, casas, almacenes, etc. es primordial.</p>\\r\\n\\r\\n<p>Este equipo est&aacute; enfocado en el campo de accesos de seguridad, consta como elementos fundamentales del LCD 2x16 caracteres y un teclado matricial. El teclado nos ayuda a manipular los datos que ingresamos, mientras que con la pantalla LCD visualizamos la informaci&oacute;n que se requiere y que ingresa por el teclado.</p>\\r\\n\\r\\n<p>El equipo para la protecci&oacute;n cuenta con fusible, que lo protege contra sobre voltajes.</p>\\r\\n\\r\\n<p>En la construcci&oacute;n de un equipo se deben tomar en cuenta muchos factores, como forma f&iacute;sica, interconexi&oacute;n de los distintos elementos, disposici&oacute;n de los elementos, para poder culminar con &eacute;xito un proyecto.</p>\\r\\n\\r\\n<p>El equipo est&aacute; dentro de una caja pl&aacute;stica que lo protege de las inclemencias del clima y protege los elementos electr&oacute;nicos.</p>\\r\\n\\r\\n<p>El proyecto ser&aacute; rentable porque contara con un Valor Actual Neto y tendr&aacute; una relaci&oacute;n Beneficio &ndash; Costo. Por lo tanto, se recomienda&nbsp; buscar financiamiento para su respectiva implementaci&oacute;n.</p>\\r\\n', '2019-11-04', 'dicyt_2019_11_04_09_57_42.docx', 'UNIV. DELFíN MENCHACA YUCRA', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('19', '1', '2', 'OBTENER SULFATO DE POTASIO, DE CALIDAD COMERCIAL PARA EL USO DE FERTILIZANTES A PARTIR DE LA SALMUERA PROCEDENTE DEL SALAR DE UYUNI', '1', '2', '<p>Obtener sulfato de potasio, de calidad comercial para el uso de fertilizantes a partir de la salmuera procedente del salar de Uyuni.</p>
', '<p>El departamento de potos&iacute; cuenta con una riqueza muy grande como es el salar de Uyuni, ya que en las salmueras existen muchos iones disueltos que tienen gran utilidad en cualquier rama industrial, las cuales pueden dar un beneficio econ&oacute;mico para este Departamento por tanto en el presente trabajo de investigaci&oacute;n se dieron a conocer uno de los tantos derivados de potasio que puede ser obtenido.</p>

<p>Para la obtenci&oacute;n del sulfato de potasio (K2SO4) primeramente fue necesario acondicionar la muestra de salmuera haciendo precipitar consecutivamente, esto con el fin de eliminar al m&aacute;ximo los dem&aacute;s interferentes, una vez obtenido los cristales en forma de cloruro de potasio (KCl), se realiz&oacute; una cristalizaci&oacute;n con el fin de que el ion potasio sobrepase el limite m&aacute;xima de su solubilidad y al agregar el sulfato de calcio catalizado con amonio, las mejores condiciones de trabajo para la obtenci&oacute;n del sulfato de potasio (K2SO4), una agitaci&oacute;n de 300 rpm y a una temperatura de 5 &deg;C y 15 &deg;C durante todo el proceso, y una vez que se realiz&oacute; una rigorosa control de los factores mencionados permite alcanzar los siguientes resultados, 68.89% y 66.56%.</p>
', '<p>A continuaci&oacute;n se presenta las conclusiones arribadas una vez efectuado el presente trabajo de investigaci&oacute;n.</p>

<ul>
	<li>Los pilares fundamentales de la investigaci&oacute;n para alcanzar el objeto final son los consiguientes estudios documentales de las solubilidades de cloruro de potasio, cloruro de sodio, sulfato de amonio, sulfato de calcio sulfato de potasio, cloruro de amonio, seguidamente el proceso de concentraci&oacute;n de los iones potasio en la soluci&oacute;n mediante la eliminaci&oacute;n de interferentes y finalmente las mejores condiciones de reacci&oacute;n entre el cloruro de potasio con sulfato de calcio catalizado con am&oacute;nico para la obtenci&oacute;n de sulfato de potasio.</li>
	<li>El tratamiento que se realiza a la muestra de salmuera proveniente del salar de Uyuni, juega un papel muy importante, debido a que cuando se elimina los dem&aacute;s iones que est&aacute;n disueltos en las muestras considerados interferentes y al eliminar las mismas, las sales de silvinita es rica en iones K+ y Na+ las cuales se asemejan a las concentraciones requeridas de 73.358 g/kg de Na+, 125.936 g/kg de K+ 356.246 de Cl- para la obtenci&oacute;n del sulfato de potasio.</li>
	<li>Las concentraciones del ion potasio en la sal de cloruro de potasio tienen las siguientes concentraciones 680.505 g/kg K+, 791.54 g/kg Cl- que fue obtenida de las sales de silvinita para la obtenci&oacute;n del sulfato de potasio, es un factor muy importante las concentraciones del cloruro de potasio, que se debe tener muy en cuenta para la obtenci&oacute;n del sulfato de potasio.</li>
	<li>Se demuestra que los variables influencia en la obtenci&oacute;n de sulfato de potasio son: La temperatura de reacci&oacute;n y filtraci&oacute;n a (5&deg;C y 15&deg;C) la concentraci&oacute;n del Amonio (20 % y 30%) y la agitaci&oacute;n de (400rpm).</li>
	<li>El m&eacute;todo de reacci&oacute;n y cristalizaci&oacute;n empleado para obtener el sulfato de potasio permite alcanzar los siguientes resultados, 68.89% y 66.56%.</li>
</ul>
', '2019-11-04', 'dicyt_2019_11_04_10_04_14.pdf', 'UNIV. EULALIA CHOQUE ACCHURA', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('20', '15', '28', 'PROPONER LA IMPLEMENTACIóN DE LA AUDITORíA AMBIENTAL PARA SU APLICACIóN EN LA EMPRESA DISTRIBUIDORA Y COMERCIALIZADORA DE MINERALES KZ MINERALS S.A.', '1', '2', '<p>Se tiene como Objetivo General de la investigaci&oacute;n el proponer la implementaci&oacute;n de la Auditor&iacute;a Ambiental para su aplicaci&oacute;n en la empresa Distribuidora y Comercializadora de minerales KZ Minerals S.A.</p>
', '<p>La presente investigaci&oacute;n aborda un tema de inter&eacute;s actual; &rdquo;LaAuditor&iacute;aAmbiental&rdquo;, en la que pretendo establecer fundamentos b&aacute;sicos para su aplicaci&oacute;n, as&iacute;como una metodolog&iacute;a, reglas y regulaciones t&eacute;cnicas profesionales para su ejecuci&oacute;n,desarrollo y aplicaci&oacute;n en empresas dedicadas al rubro de distribuci&oacute;n ycomercializaci&oacute;n de minerales; por ello el rol de los contadores p&uacute;blicos es afrontar los nuevos retos del siglo XXI, las nuevas existencias de la globalizaci&oacute;n en la econom&iacute;a, laeducaci&oacute;n y la gesti&oacute;n de los conocimientos por tratarse a&uacute;n m&aacute;s que el presente tema,en Bolivia es de reciente divulgaci&oacute;n y de inter&eacute;s para los distintos profesionales, estudiosos e investigadores; en la perspectiva de que el resultadoconstituya un aporte concreto a las ciencias contables y financieras; una acci&oacute;nefectiva y complementaria, orientada a la protecci&oacute;n del medio ambiente, esta l&iacute;nea depreocupaci&oacute;n por la preservaci&oacute;n y conservaci&oacute;n del medio ambiente ha despertadointer&eacute;s en las autoridades as&iacute; como del p&uacute;blico en general.</p>

<p>El problema que se investiga es referido a las pr&aacute;cticas, actividades y procedimientos relacionados con el medio ambiente de este tipo de empresas.</p>

<p>Lo que se quiere es implementar un modelo de Auditor&iacute;a Ambiental el cual sedesarrolla por parte de un equipo auditor interno o externo de la empresa,dispuestosa brindar el servicio en base a las normas legales nacionales y normas internacionalesde gesti&oacute;n ambiental.</p>

<p>Para recoger los datos se aplic&oacute; la t&eacute;cnica de observaci&oacute;n y la encuesta estructuradapara recabar los datos necesarios con el fin de probar que la no aplicaci&oacute;n de laAuditor&iacute;a Ambiental, tienen incidencias marcadas en la contaminaci&oacute;n ambiental y procesamiento de datos ambientales, producida por este tipo de empresas.</p>

<p>Con resultado aproximado del 70%que existe un desconocimiento y la no pr&aacute;ctica degesti&oacute;n ambiental y manejo de informaci&oacute;n ambiental, pero con un 100% que es en sutotalidad est&aacute;n dispuestos a implementar dicha Auditoria.</p>
', '<ul>
	<li>A ra&iacute;z de la investigaci&oacute;n desarrollada a la empresa KZ Minerals se ha detectado el desconocimiento y la no aplicaci&oacute;n de las normatividades ambientales, de acuerdo a escasez de pol&iacute;ticas ambientales empresariales, lo cual implica la necesidad de una implantaci&oacute;n de Auditor&iacute;a Ambiental como instrumento a desarrollar.</li>
	<li>Constan de la escasez de los beneficios de la Auditor&iacute;a Ambiental ya que este proporciona orden y coherencia a los esfuerzos de la empresa por considerar las preocupaciones ambientales, mediante la asignaci&oacute;n de recursos, asignaci&oacute;n de responsabilidades, la evaluaci&oacute;n continua de pr&aacute;cticas, procedimientos y procesos.</li>
	<li>Mediante las encuestas realizadas al &aacute;rea comercial y administrativa contable, m&aacute;s del 60% de los trabajadores no est&aacute;n capacitados frente a posibles impactos ambientales en la empresa KZ Minerals pudiendo ocurrir da&ntilde;os a la comunidad, contaminaci&oacute;n del medio ambiente, contaminaci&oacute;n del producto, contaminaci&oacute;n del aire y datos err&oacute;neos seg&uacute;n responsabilidad ambiental empresarial; de acuerdo a los m&eacute;todos de evaluaci&oacute;n ambiental de manera descriptiva y la t&eacute;cnica de observaci&oacute;n, se considera que la empresa a KZ Minerals, no cuentan con procedimientos a seguir de evaluaci&oacute;n ambiental, tomando como base los criterios de las normas internacionales ISO, NIC y revisi&oacute;n de la normativa ambiental vigente.</li>
</ul>
', '2019-11-04', 'dicyt_2019_11_04_10_10_48.pdf', 'UNIV. KATHERINE TORREZ INCLAN', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('25', '15', '28', 'DETERMINAR UNA BASE DE DATOS EÓLICOS EN LA ZONA DE LAS PAMPAS DE CHIQUILLA REALIZANDO UNA TRIANGULACIÓN CON LAS ESTACIONES METEOROLÓGICAS PARA UN ESTUDIO DE ENERGÍA EÓLICA', '1', '2', '<p>Determinas una base datos e&oacute;licos de las pampas de Chaquilla mediante una triangulaci&oacute;n de estaciones meteorol&oacute;gicas SIG para un estudio de energ&iacute;a e&oacute;lica.</p>
', '<p>El requerimiento de las servicios b&aacute;sicos entre ellos uno de los mas b&aacute;sicos, la energ&iacute;a el&eacute;ctrica y su demanda va en constante crecimiento adem&aacute;s que la demanda de otros recursos naturales y la dependencia de ellos como tambi&eacute;n a las fuentes de energ&iacute;a como los combustibles f&oacute;siles las mismas que su utilizaci&oacute;n provoca gases de efecto invernadero y gases contaminantes que son perjudiciales para la salud.</p>

<p>En estos tiempos se puso de moda la utilizaci&oacute;n aplicaci&oacute;n y emprendimiento de energ&iacute;as limpias y que cuiden el planeta como energ&iacute;a generada por hidroel&eacute;ctricas, biog&aacute;s, paneles solares fotovoltaicas y energ&iacute;a e&oacute;lica, es por eso que se decidi&oacute; realizar un estudio del viento y sus caracter&iacute;sticas m&aacute;s importantes el cual ser&iacute;a una base muy importante para un trabajo m&aacute;s detallado y minucioso sobre el potencial energ&eacute;tico e&oacute;lico en la zona de las pampas de Chaquilla.</p>

<p>De esta manera se empleara un SIG para la elaboraci&oacute;n&nbsp; de una triangulaci&oacute;n entre estaciones meteorol&oacute;gicas m&aacute;s cercanas a la zona de estudio.</p>

<p>&nbsp;</p>
', '<ul>
	<li>Se realizo la delimitaci&oacute;n de la zona de estudio contemplando las estaciones meteorol&oacute;gicas m&aacute;s cercanas y se obtuvo un &aacute;rea de estudio mayor que el que se contemplo en los an&aacute;lisis previos, lo cual nos da una mayor ventaja porque expandimos el &aacute;rea de estudio y podemos realizar otro estudio de energ&iacute;a e&oacute;lica m&aacute;s amplio en cuanto a la zona.</li>
	<li>Como base principal se contaba con la colaboraci&oacute;n de tres estaciones meteorol&oacute;gicas y sus datos pero se analizo y se pudo recabar m&aacute;s informaci&oacute;n y se realizo la triangulaci&oacute;n de estaciones meteorol&oacute;gicas de las provincias del departamento de Potos&iacute;, un trabajo m&aacute;s amplio y una buena base para dem&aacute;s estudio e&oacute;licos.</li>
	<li>Se tiene los datos en un mapa el cual nos informa que la velocidad del viento esta en un rango de 2.947 metros/segundos alto y bajo de 2.791 m/s., realizando una conversi&oacute;n nos otorgara<strong> 10.6109 k/h el dato m&aacute;s alto y el dato m&aacute;s bajo de 10.5505 k/h</strong> el cual seg&uacute;n estudio de requerimiento de aerogeneradores est&aacute; entre el rango necesario para un rendimiento optimo el cual es de <strong>5 k/h como m&iacute;nimo y como m&aacute;ximo 15k/h</strong>.</li>
	<li>Se tiene que tomar en cuenta que la triangulaci&oacute;n de las estaciones meteorol&oacute;gicas&nbsp; est&aacute; dada entre provincias una distancia aproximada de 200 a mas kil&oacute;metros entre cada estaci&oacute;n, esto hace un estudio de una mayor &aacute;rea y a la vez un estudio mayor al &aacute;rea propuesta&nbsp; con una efectividad mayor a 80% y con la ayuda de estaciones y equipos port&aacute;tiles anem&oacute;metros podemos validar y completar a un 100 5 de eficiencia en el estudio.</li>
</ul>
', '2019-11-04', 'dicyt_2019_11_04_10_50_06.docx', 'UNIV. MISAEL DILSON PRADO MORA - UNIV. ARIEL PABLO SOTO ', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('22', '1', '2', 'OBTENCIÓN DE FOSFATO ACIDO DE AMONIO A PARTIR DE ROCA FOSFÓRICA DE BUEY-TAMBO (PAMPAS DE LEQUEZANA), POR EL PROCESO DE ACIDULACION Y POSTERIOR NEUTRALIZACIÓN CON AMONIACO', '1', '2', '<p>Obtener fosfato acido de amonio de calidad comercial a partir de roca fosf&oacute;rica de Buey-tambo (pampas del Lequezana), por acidulacion y neutralizaci&oacute;n con amoniaco.</p>
', '<p>El fosforo es un elemento indispensable para el rendimiento de buenos cultivos, que es necesario la aplicaci&oacute;n de fertilizantes fosforados sean naturales o sint&eacute;tico. El presente trabajo de investigaci&oacute;n, estuvo dirigido a obtener fosfato acido de amonio a partir de la roca fosf&oacute;rica, muestra obtenida de la localidad de Buey-Tambo, provincia Cornelio Saavedra.</p>

<p>Se pudo determinar que a trav&eacute;s de an&aacute;lisis fisicoqu&iacute;mico existe una considerable cantidad de pentaoxido de fosforo en la roca fosf&oacute;rica con un valor de 23.77 %.</p>

<p>Para el proceso de obtenci&oacute;n de &aacute;cido fosf&oacute;rico por acidulacion, se aplicado el dise&ntilde;o experimental donde las variables influyentes son: temperatura, tiempo de agitaci&oacute;n y concentraci&oacute;n del &aacute;cido. Dando lugar a un mayor rendimiento. Y obteniendo un pH de 1-2.</p>

<p>A partir del &aacute;cido fosf&oacute;rico, por neutralizaci&oacute;n con amoniaco y cristalizaci&oacute;n se llega a obtener fosfato acido de amonio.</p>

<p>En la obtenci&oacute;n de fosfato acido de amonio la generaci&oacute;n de amoniaco gaseoso se realiza por un tiempo de 5 a 10 minutos a una temperatura menos a -5 0C y un tiempo de cristalizaci&oacute;n a temperatura ambiente 20 d&iacute;as.</p>
', '<p>El objetivo principal del presente trabajo de investigaci&oacute;n es la obtenci&oacute;n de fosfato acido de amonio a partir de la roca fosf&oacute;rica de Buey Tambo provincia Cornelio Saavedra del departamento de Potos&iacute; para la utilizaci&oacute;n como reactivo y a la vez pueda resultar una alternativa econ&oacute;mica.</p>

<p>la informaci&oacute;n empleada para este estudio es resultado de an&aacute;lisis qu&iacute;micos tanto de la materia prima como del producto, tambi&eacute;n de una revisi&oacute;n bibliogr&aacute;fica que ayudan a obtener buenos resultados y a la vez compararlos.</p>

<ul>
	<li>De acuerdo a las caracter&iacute;sticas qu&iacute;mica de la roca fosf&oacute;rica de Buey Tambo se ha podido observa que se puede obtener fosfato acido de amonio empleando tratamientos adecuados en la materia prima.</li>
	<li>En la realizaci&oacute;n del an&aacute;lisis qu&iacute;mico del fosforo se ha utilizado el m&eacute;todo colorim&eacute;trico del amarillo molibdovanadato por presentar mayor precisi&oacute;n y un rango menor de interferencia.</li>
	<li>En el an&aacute;lisis qu&iacute;mico de nitr&oacute;geno en el producto obtenido fosfato acido de amonio se utiliz&oacute; el procedimiento de an&aacute;lisis del ion amonio por colorimetr&iacute;a, el cual consiste en agregar hidr&oacute;xido de sodio y reactivos Nessler.</li>
	<li>El contenido de P2O5 existente en la materia prima es de 23.77 %.</li>
	<li>La materia prima (roca fosf&oacute;rica) de Buey Tambo contiene minerales de fluorapatita y cuarzo principalmente</li>
	<li>En la obtenci&oacute;n de &aacute;cido fosf&oacute;rico se determina que las mejores condiciones son a una temperatura de 80&ordm;C con un tiempo de agitaci&oacute;n de 30 minutos y una concentraci&oacute;n de &aacute;cido sulf&uacute;rico de 0.5 N. obteniendo un porcentaje de pureza de 73.46 %.</li>
	<li>Se obtuvo fosfato acido de amonio con un porcentaje de rendimiento de 25.10%.</li>
	<li>La obtenci&oacute;n del fosfato acido de amonio se ha efectuado mediante la reacci&oacute;n entre el &aacute;cido fosf&oacute;rico (obtenido a partir de la roca fosf&oacute;rica) y amoniaco generado a partir del hidr&oacute;xido de amonio.</li>
</ul>
', '2019-11-04', 'dicyt_2019_11_04_10_26_45.docx', 'UNIV. MARCO ANTONIO RIBERA PINTO', '2018', '0', 'LIC. GUSTAVO NILO MERCADO', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('21', '17', '3', 'HABILIDAD COGNITIVA DE ESTUDIANTES DE SEXTO DE SECUNTARIA, CON EL TEST DE COEFICIENTE INTELECTUAL EN LA PROVINCIA TOMAS FRÍAS, POTOSI, 2017', '1', '2', '<p>Determinar<strong> </strong>la habilidad cognitiva general en la que se diferencian los estudiantes de sexto de secundaria de los diferentes colegios, con el test de coeficiente intelectual en la provincia Tomas Fr&iacute;as, potos&iacute;, 2017.</p>
', '<p>Se observa la importancia que tiene la valoraci&oacute;n del alumnado para la identificaci&oacute;n de un alumno o alumna con altas o bajas capacidades intelectuales y poder observar que sexo tiene una habilidad cognitiva es m&aacute;s alta.</p>

<p>Se hiso el c&aacute;lculo del coeficiente intelectual en estudiantes de 7 diferentes colegios para observar cual es el estado de la inteligencia de cada estudiante.&nbsp; Y se&nbsp; observ&oacute; que presentan un coeficiente intelectual por debajo de la media, que son 542 estudiantes y en esto se observa&nbsp; que el rendimiento acad&eacute;mico est&aacute; bajo. Puesto que tambi&eacute;n hubo estudiantes que presentaron por encima de la media,&nbsp; que son 84 estudiantes y 11 estudiantes presentaron el promedio normal.</p>

<p>Y se compar&oacute; la puntuaci&oacute;n de cada colegio, mostrando&nbsp; que sus alumnos&nbsp; del colegio Don Bosco tienen una habilidad cognitiva m&aacute;s alta que el resto de los 6 colegios&nbsp; que fueron evaluados con el test de coeficiente intelectual.</p>

<p>Tambi&eacute;n se vio los resultados del coeficiente intelectual por edades sacando su media de cada edad a acepci&oacute;n de los estudiantes de 15 y 20 a&ntilde;os. Demostrando con la muestra obtenida que los estudiantes de 17 a&ntilde;os tienen una habilidad cognitiva m&aacute;s alta que la de las otras edades.</p>
', '<p>Pues con los resultados obtenidos se observa una gran diferencia de rangos de coeficiente intelectual de los 7 diferentes colegios y una gran diferencia te coeficiente intelectual por el sexo y edades.</p>

<p>Con los resultados se demuestra que las mujeres tienen un poco m&aacute;s conocimiento que los hombres (gr&aacute;fico N&ordm;3)</p>

<p>Y tambi&eacute;n una gran diferencia de coeficiente intelectual por las edades que tienen puesto que los de 17 a&ntilde;os tienen mayor coeficiente intelectual (gr&aacute;fico N&ordm;4)&nbsp;</p>

<p>No obstante que en los resultados se obtuvo una gran cantidad de estudiantes por debajo del rango de 100 que est&aacute;n debajo del rango y esto hace referencia junto con la teor&iacute;a que los estudiantes no constan de muchos conocimientos b&aacute;sicos de las materias b&aacute;sicas que se lleva en el colegio. Puesto que tambi&eacute;n se observa que una cantidad moderada tiene por encima del rango normal viendo su puntuaci&oacute;n que estos poseen un conocimiento m&aacute;s amplio que los dem&aacute;s y en m&iacute;nima cantidad estudiantes normales (gr&aacute;fico N&ordm;5)</p>

<p>Esto hace denotar que a le falta inter&eacute;s y empe&ntilde;o al estudiante o le falta m&aacute;s empe&ntilde;o e inter&eacute;s al profesor.</p>

<p>Haciendo una exploraci&oacute;n en &aacute;mbito social y estudiantil pues con estos resultados se muestra que cuando el colegial entra a la universidad el estudiante no tiene los conocimientos generales que necesita. Puesto que esto es muy necesario en todo &aacute;mbito laboral tanto como &aacute;mbito del estudio. Y se ve claramente en el ambiente de las universidades que los estudiantes que no tienen conocimientos generales est&aacute;n m&aacute;s perdidos que los que s&iacute; tienen una habilidad cognitiva alta. Tambi&eacute;n se incluyen a los estudiantes que no tienen inter&eacute;s en los estudios puesto que se vio al evaluar a los estudiantes, demostrar no tener inter&eacute;s como se dijo en an&aacute;lisis.&nbsp; Y solo hacer las cosas por obligaci&oacute;n o simplemente para sacar lo que el necesita, por ejemplo, notas de sus materias. Que hoy en d&iacute;a es m&aacute;s importante para el alumno que adquirir conocimientos en el estudio. Y esto no es visto solo por nosotros que realizamos el test de coeficiente intelectual. Si no tambi&eacute;n que es observado por algunos docentes de las universidades</p>

<p>Claro esto no abarca a todos los estudiantes solo es menci&oacute;n de los que sacaron por debajo de la media del cociente intelectual establecido CI 100. Puesto que los que est&aacute;n por encima son los que dan rendimientos en las universidades y colegios. Pues esta afirmaci&oacute;n no es del todo concreta ya que los estudiantes del colegio tienen una habilidad cognitiva buena. Pues estos se dejan llevar por la pereza y no rinden en el colegio. Pero al salir se ha visto que estudiantes del colegio con bajas notas son los que rinden en la universidad.</p>
', '2019-11-04', 'dicyt_2019_11_04_10_22_14.docx', 'UNIV. LIMBERT FLORES CRUZ - UNIV. JHOSELIN DANIELA CKACKA MAMANI - UNIV. YOMARA MORELIA FUERTES HUALLPA - UNIV. ELIAS GUEVARA VITORIO - UNIV. LIMON RENTERIA MAURICIO', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('26', '15', '27', 'TELEDETECCIÓN APLICADA EN LA IDENTIFICACIÓN DE DESLIZAMIENTOS DE LADERAS DEL VOLCÁN OLLAGUE EN EL SECTOR BOLIVIANO', '1', '2',  E'<ul>\\r\\n	<li>Aplicar la teledetecci&oacute;n para la identificaci&oacute;n de deslizamientos de laderas del Volc&aacute;n Ollague en el sector boliviano.</li>\\r\\n</ul>\\r\\n',  E'<p>Los deslizamientos por laderas constituyen un riesgo natural geol&oacute;gico producto de la geodin&aacute;mica externa de la superficie terrestre; este fen&oacute;meno generalmente se manifiesta en zonas monta&ntilde;osas donde existe una pendiente relativamente inclinada del terreno. El estudio del mismo corresponde a las ciencias geol&oacute;gicas, espec&iacute;ficamente es la geomorfolog&iacute;a la que se encarga de analizar y evaluar las causas y consecuencias de su ocurrencia.</p>\\r\\n\\r\\n<p>La detecci&oacute;n de este fen&oacute;meno geol&oacute;gico mediante el uso de im&aacute;genes satelitales proporciona informaci&oacute;n fidedigna y veraz, el procesamiento del mismo se basa en la combinaci&oacute;n de las bandas espectrales que proporciona el sensor del sat&eacute;lite LANDSAT, y de acuerdo a las caracter&iacute;sticas radiom&eacute;tricas de los materiales removidos (rocas, suelos) se podr&aacute; hacer una evaluaci&oacute;n y comparaci&oacute;n de los mismos respecto a los materiales adyacentes fijos, considerando su evoluci&oacute;n temporal y espacial.</p>\\r\\n\\r\\n<p>El Volc&aacute;n Ollague corresponde a una estructura de relieve positivo, la cual, entre varios factores a estudiarse, presenta deslizamientos de materiales a trav&eacute;s de sus laderas. La ubicaci&oacute;n geogr&aacute;fica del mismo se halla al sudoeste del departamento de Potos&iacute;, situado en plena frontera Bolivia &ndash; Chile, en una zona accidentada, alejada y de dif&iacute;cil acceso, situaci&oacute;n que dificulta su estudio.</p>\\r\\n\\r\\n<p>Por la raz&oacute;n expuesta, la aplicaci&oacute;n de im&aacute;genes de sat&eacute;lite a la identificaci&oacute;n de deslizamientos de laderas del Volc&aacute;n Ollague se convierte en una t&eacute;cnica relevante y complementaria a una visita de campo donde se verificar&aacute; los datos referidos a movimiento de materiales en sus laderas, que ser&aacute;n previamente delimitados en el an&aacute;lisis visual de las im&aacute;genes.</p>\\r\\n\\r\\n<p>La identificaci&oacute;n de este fen&oacute;meno geol&oacute;gico podr&aacute; evidenciar la evoluci&oacute;n del mismo en un rango de tiempo de 15 a&ntilde;os, determinar la constituci&oacute;n del material removido, la velocidad de movimiento, y las causas que lo originan, entre otros factores, se considerara el efecto de la microsismicidad del volc&aacute;n que se considera como un volc&aacute;n activo.</p>\\r\\n\\r\\n<p>En s&iacute;ntesis, la teledetecci&oacute;n contribuye a analizar, alertar y evaluar el riesgo geol&oacute;gico generado por deslizamientos de laderas del Volc&aacute;n Ollague en el sector boliviano.</p>\\r\\n',  E'<ul>\\r\\n	<li>Se concret&oacute; la identificaci&oacute;n de deslizamientos de laderas en el volc&aacute;n Ollague, a trav&eacute;s de la utilizaci&oacute;n de la t&eacute;cnica de teledetecci&oacute;n que corresponde a una metodolog&iacute;a de trabajo a distancia o percepci&oacute;n remota.</li>\\r\\n	<li>Se determin&oacute; que en un &aacute;rea total de 218,25 km2, en la escena correspondiente al 2018, se identifica que el &aacute;rea afectada por deslizamientos es de 7,6 km2, representando el 3,48 % del &aacute;rea total. En la escena del a&ntilde;o 2003, el &aacute;rea afectada por deslizamientos es de 5,3 km2 representando el 2,42% de un &aacute;rea total de 218,25 km2. Esta situaci&oacute;n demuestra que el &aacute;rea afectada por deslizamientos aumento en un 1,06%, representado un &aacute;rea de 2,3 km2, de aumento, referido al &aacute;rea que ocupan los deslizamientos de ladera, para un intervalo de tiempo de 15 a&ntilde;os.</li>\\r\\n	<li>El &aacute;rea de trabajo correspondiente al an&aacute;lisis de deslizamientos de ladera, en el volc&aacute;n Ollague, corresponde a una extensi&oacute;n de &ldquo;218 km2&rdquo;, ocupando un 47% del total del cono volc&aacute;nico, lugar correspondiente al sector este, lado boliviano.</li>\\r\\n	<li>El material removido por deslizamientos de ladera en el volc&aacute;n Ollague, est&aacute; compuesto por material volc&aacute;nico no consolidado, flujos de detritos intercalados con bloques, cantos, till.</li>\\r\\n	<li>La magnitud de &aacute;rea determinada para los deslizamientos identificados en las laderas del volc&aacute;n Ollague, no representa un peligro real para una poblaci&oacute;n determinada de seres vivos, ni alg&uacute;n ecosistema, considerando que la poblaci&oacute;n humana m&aacute;s cercana se encuentra a 4 km. hacia el noreste, muy alejada para que los deslizamientos tengan alg&uacute;n efecto sobre esta.</li>\\r\\n	<li>La identificaci&oacute;n de deslizamientos de laderas en el volc&aacute;n Ollague, corresponde a &aacute;reas extensas, su an&aacute;lisis se realiza en tiempo relativamente corto, esto es posible solamente utilizando im&aacute;genes satelitales espectrales.</li>\\r\\n	<li>La aplicaci&oacute;n de la teledetecci&oacute;n como t&eacute;cnica de identificaci&oacute;n de deslizamientos de laderas representa una metodolog&iacute;a novedosa, su utilizaci&oacute;n ofrece ventajas referidas a la posibilidad de acceder a &aacute;reas topogr&aacute;ficamente inaccesibles, asi mismo aminora los costos econ&oacute;micos producidos por el trabajo tradicional de campo.</li>\\r\\n	<li>La utilizaci&oacute;n de la imagen del sat&eacute;lite LANDSAT 8 se debe a la buena resoluci&oacute;n espacial que ofrece (30 m.) este valor es empleado con existo en el estudio y an&aacute;lisis de &aacute;reas extensas, tal es el caso de las laderas del volc&aacute;n Ollague.</li>\\r\\n	<li>Para la diferenciaci&oacute;n de las coberturas terrestres, en base a su clase espectral, se aplic&oacute; la t&eacute;cnica &ldquo;CLASIFICACI&Oacute;N SUPERVISADA&rdquo;, debido a que el conocimiento del &aacute;rea del trabajo &ldquo;in situ&rdquo; es aceptable, la gran extensi&oacute;n del mismo y la inaccesibilidad topogr&aacute;fica no permiti&oacute; ingresar a toda el &aacute;rea de estudio.</li>\\r\\n	<li>La teledetecci&oacute;n corresponde a una herramienta de gran utilidad para realizar trabajos a escala espacial y/o temporal amplia, En el caso particular de Landsat TM, la buena resoluci&oacute;n espectral (7 bandas) y espacial (30 m &times; 30 m) de las im&aacute;genes, sumadas a la cobertura espacial (180 Km &times; 180 Km) de cada escena y a su cobertura temporal (desde 1982 hasta 2018), permiten identificar alteraciones ambientales relativamente peque&ntilde;as, evaluar sus efectos a escala regional y determinar tasas de cambio durante la &uacute;ltima d&eacute;cada</li>\\r\\n	<li>Los resultados obtenidos muestran que es posible diferenciar con buena precisi&oacute;n deslizamientos de ladera dentro de la matriz de la ladera del volc&aacute;n Ollague y determinar el &aacute;rea afectada por este tipo de disturbios, mediante un an&aacute;lisis multitemporal de las im&aacute;genes satelitales.</li>\\r\\n</ul>\\r\\n', '2019-11-04', 'dicyt_2019_11_04_10_56_19.pdf', 'UNIV. VLADIMIR MICHEL MAMANI', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('29', '17', '3', 'PREVALENCIA DE PACIENTES CON VÓLVULO SIGMOIDES EN EL  HOSPITAL DANIEL BRACAMONTE DE NOVIEMBRE 2017 A JULIO 2018 EN CIUDAD DE POTOSI', '1', '2', '<p>Determinar la prevalencia de v&oacute;lvulo sigmoides agudo en el Hospital Daniel Bracamonte desde noviembre de 2017 a julio de 2018 en la ciudad de Potos&iacute;.</p>
', '<p>El v&oacute;lvulo sigmoides es la torsi&oacute;n de su segmento alrededor de su mesenterio originando una obstrucci&oacute;n que causa la oclusi&oacute;n de la luz intestinal (obstrucci&oacute;n en asa cerrada) y de la irrigaci&oacute;n sangu&iacute;nea (isquemia-gangrena). El objetivo general fue prevalencia de pacientes con v&oacute;lvulo sigmoides en el hospital Daniel bracamonte de noviembre 2017 a julio 2018 en la ciudad de Potos&iacute;. Trat&aacute;ndose de un estudio retrospectivo de tipo cuantitativo, no experimental y de tipo transversal, para lo cual nuestro universo corresponde a los setecientos treinta pacientes internados, centr&aacute;ndonos en nuestra muestra que son ciento diecis&eacute;is&nbsp; pacientes diagnosticados con v&oacute;lvulo sigmoides; utilizando &nbsp;el tipo de muestreo no probabil&iacute;stico por conveniencia debido a seleccionar la muestra siguiendo criterios diagn&oacute;sticos de v&oacute;lvulo sigmoides, a partir de pacientes internados en el hospital Daniel Bracamonte correspondiente a nuestro universo.</p>

<p>Se observ&oacute; que los pacientes diagnosticados con esta patolog&iacute;a provienen del &aacute;rea rural con 53%, seguido del &aacute;rea urbana con 47%, se observ&oacute; que el tratamiento m&aacute;s frecuente es por v&iacute;a quir&uacute;rgica con 84%, seguido del cl&iacute;nico con el 16% y por &uacute;ltimo, los pacientes sin problemas postoperatorios con 87%, precedido del 13% de los pacientes que tuvieron problemas postoperatorios</p>

<p>Recomendamos hacer campa&ntilde;as para hacer conocer la enfermedad y las causas que lo provocan, estar pendiente de nuestra salud y m&aacute;s a&uacute;n en el &aacute;rea rural, considerando que nuestros estudios proponen que esta patolog&iacute;a se produce con m&aacute;s frecuencia en la misma.</p>

<p>Palabras clave: V&oacute;lvulo sigmoides, obstrucci&oacute;n intestinal, prevalencia, sigmoides, postquir&uacute;rgico, tratamiento, cirug&iacute;a.</p>
', '<p>Durante el presente trabajo de investigaci&oacute;n, los resultados nos muestran que los 736 pacientes internados en el servicio de cirug&iacute;a del Hospital Daniel Bracamonte 116 pacientes fueron diagnosticados con v&oacute;lvulo de sigmoides.</p>

<p>Se observ&oacute; que los varones presentan m&aacute;s complicaciones respecto a v&oacute;lvulo de sigmoides en un 66% (71 pacientes) y las mujeres un 44%(45 pacientes).</p>

<p>Se observ&oacute; que la edad m&aacute;s frecuente es de 61 a 80 a&ntilde;os en un 56% (65 pacientes) en el servicio de cirug&iacute;a del Hospital Daniel Bracamonte.</p>

<p>Se pudo observar que los pacientes con v&oacute;lvulo de sigmoides provienen con m&aacute;s frecuencia del &aacute;rea rural en un 53% (61 pacientes) y los del &aacute;rea urbana en un 47% (55 pacientes).</p>

<p>Tambi&eacute;n se observ&oacute; que un 25% (29 pacientes) de un 100% (116 pacientes) diagnosticados con v&oacute;lvulo de&nbsp; sigmoides pidieron alta solicitada, los&nbsp; que representan en un 100% (29 pacientes), un 17% (5 pacientes) volvieron al Hospital Daniel Bracamonte.</p>

<p>Se pudo observar que el tratamiento m&aacute;s frecuente es el quir&uacute;rgico en un 84% (77 pacientes) y el tratamiento cl&iacute;nico en un 16% (15 pacientes).</p>

<p>Se observ&oacute; que hubo problemas post operatorios en un 13% (10 pacientes) y que no hubo problemas post operatorios en un 87% (67 pacientes) de un 87% (77 pacientes) con tratamiento quir&uacute;rgico de v&oacute;lvulo de sigmoides.</p>
', '2019-11-06', 'dicyt_2019_11_06_19_14_38.docx', 'UNIV. MENDEZ MENDEZ OSVALDO EDGAR - UNIV. MENDOZA GARCIA MELISA JERUSALEN - UNIV. MITA GARECA ALVARO - UNIV. OLGUIN CATATA KATHERINE KARINA - UNIV. PARI FERNANDEZ SUMAYA', '2018', '0', 'DR. JOSÉ H. RICALDI PINTO - DR. OSVALDO MENDEZ CUIZA - DR. ERICK CUIZA NOGUERA ', 'No Disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('28', '17', '3', 'DETERMINACIóN DE LA EXISTENCIA DE BROMATO DE POTASIO EN LA ELABORACIóN DEL PAN INDUSTRIAL EN LAS PANADERíAS DE LA CIUDAD POTOSí, DURANTE LA GESTIóN 2018.', '1', '2', '<p>Determinar la existencia de bromato de potasio en la elaboraci&oacute;n del pan industrial en las panader&iacute;as de la ciudad Potos&iacute;, durante la gesti&oacute;n 2018.</p>
', '<p>El presente trabajo de investigaci&oacute;n titulado &ldquo;Determinaci&oacute;n&nbsp; de la existencia del Bromato de Potasio en la elaboraci&oacute;n del pan industrial en las panificadoras de la ciudad de Potos&iacute; de la gesti&oacute;n 2018&rdquo;, cuyo objetivo fue buscar el Bromato de Potasio en el pan que se consume a diario en la ciudad Potos&iacute; mediante los an&aacute;lisis bromatol&oacute;gicos con la Norma Mundial, ya que el Bromato de Potasio es un aditivo genot&oacute;xico el cual por el consumo&nbsp; permanente inadvertido causa c&aacute;ncer. El dise&ntilde;o de investigaci&oacute;n fue anal&iacute;tico, prospectivo y transversal, determin&aacute;ndose una muestra de 9 panes de diferentes panader&iacute;as tomando en cuenta el n&uacute;mero de establecimientos Por zonas de nuestra ciudad. El instrumento que se utiliz&oacute; fueron las sustancias qu&iacute;micas que se utilizaron para el an&aacute;lisis bromatol&oacute;gico, y as&iacute; detectar la presencia de Bromato de Potasio en el Pan, Los resultados obtenidos tras los an&aacute;lisis realizado indican que no exist&iacute;a el Bromato de Potasio en la elaboraci&oacute;n del Pan en la ciudad de Potos&iacute; con el 100% de las muestras analizadas saliendo negativas en la presencia de Bromato de Potasio.&nbsp; Las Conclusiones: Seg&uacute;n el monitoreo y los an&aacute;lisis efectuados las diferentes panader&iacute;as de la ciudad de Potos&iacute; si cumplen con las normativas de la Ordenanza Municipal 077/2004 en el uso de este aditivo.</p>

<p>PALABRAS CLAVE: Bromato, Potos&iacute;, potasio, ciudad, pan y aditivo.</p>
', '<p>Seg&uacute;n el monitoreo efectuado, el 100% de las panificadoras incluidas en el estudio &nbsp;cumple con las exigencias de calidad descritas en la ordenanza municipal &nbsp;077/2004, los resultados obtenidos en este trabajo pueden interpretarse como una herramienta de soporte para las entidades de salud encargadas de velar por la seguridad alimentaria, cuyos esfuerzos se centran en erradicar este tipo de pan da&ntilde;ino para la salud.</p>
', '2019-11-06', 'dicyt_2019_11_06_19_08_59.docx', 'UNIV. AYALA ARROYO FERNANDO DANIEL - UNIV. CARBASUYO ORCKO ARMANDO CRISTIAN - UNIV. CHOQUE VARGAS ERICK BRAYAN - UNIV. COPA APAZA SAMUEL', '2018', '0', 'DR. JOSé HUMBERTO RICALDI PINTO - AUX. UNIV. RASHEL RICALDI FUERTES', 'No Disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('27', '17', '3', 'HABITOS ALIMENTICIOS QUE AFECTAN O BENEFICIAN EN EL RENDIMIENTO ACADÉMICO DE ESTUDIANTES DE LA CIUDAD DE POTOSÍ 2018', '1', '2', '<p>Determinar los alimentos que afectan y benefician en el rendimiento acad&eacute;mico de los estudiantes de nuestra ciudad.</p>
', '<p>La alimentaci&oacute;n es crucial en el desarrollo de las personas la cual implica m&uacute;ltiples cambios fisiol&oacute;gico y psicol&oacute;gicos, el estado nutricional es un indicador del estado de salud puesto que la actualidad se observa que ambos padres trabajan dejando a los estudiantes en descuido de su alimentaci&oacute;n y su rendimiento acad&eacute;mico.</p>

<p><strong>El tipo de investigaci&oacute;n fue:</strong> Cuali-cuantitativo, el tipo de estudio a seguir fue de tipo transversal, prospectivo. Tambi&eacute;n m&eacute;todos te&oacute;ricos: inductivo deductivo.</p>

<p>Nos proponemos como <strong>objetivo general</strong> determinar los alimentos que afectan o benefician en el rendimiento acad&eacute;mico. La muestra se conform&oacute; por 2021 estudiantes utilizando una encuesta que incluye cuadros de consumo obteniendo los siguientes resultados: El 17,81% de los estudiantes tienen una buena alimentaci&oacute;n y 82,19% tienen una mala alimentaci&oacute;n. Influye mucho la Familia con quien vive, la televisi&oacute;n, los horarios de las clases, las horas que estos dedican a su estudio. Se observa en los resultados que una mayor&iacute;a posee un tipo de alimentaci&oacute;n mala con un rendimiento acad&eacute;mico regular.</p>

<p>Despu&eacute;s de haber analizado los resultados obtenidos se observa que en la alimentaci&oacute;n y el rendimiento acad&eacute;mico de los adolescentes existe diferencias en la calidad nutricional de los alimentos que consumen, con respecto a lo recomendado.</p>

<p><strong>Palabras clave: Alimentaci&oacute;n, Rendimiento, Salud, Familia, Adolescentes, recomendado.</strong></p>
', '<p>A trav&eacute;s de los resultados obtenidos en el trabajo de investigaci&oacute;n se observ&oacute; que de los 2021 estudiantes encuestados un 17,81% tiene una BUENA ALIMENTACI&Oacute;N de donde 3,12% tienen un buen rendimiento acad&eacute;mico, pero si observamos hacia la MALA ALIMENTACION vemos que el 82,19% de donde un 65,81% tiene un RENDIMIENTO REGULAR, podemos concluir que una buena alimentaci&oacute;n, con todos los nutrientes necesarios es vital para un buen rendimiento acad&eacute;mico, pues ayudara a prestar m&aacute;s atenci&oacute;n a las clases, como tambi&eacute;n a que nuestros estudiantes de los diferentes colegios est&eacute;n en todo aspecto &ldquo;SANOS&rdquo;. Tambi&eacute;n se puede rescatar que el 42,55% de los estudiantes encuestados observan la televisi&oacute;n mientras se alimentan, lo cual perjudicara en su aprendizaje, pues no lograran concentrarse adem&aacute;s de ser perjudicial para la digesti&oacute;n de sus alimentos.</p>

<p>La dieta de la poblaci&oacute;n de estudiantes es de baja calidad por lo que se va necesitando <strong>&ldquo;cambios hacia un patr&oacute;n alimentario m&aacute;s saludable</strong>&rdquo;. Como aspectos positivos destacamos unos h&aacute;bitos alimentarios respecto a la distribuci&oacute;n y n&uacute;mero las comidas bastante adecuadas. Se conoce los h&aacute;bitos alimenticios en los estudiantes por medio de las encuestas realizadas. Los resultados conducen a la necesidad de llevar a cabo un estudio en una poblaci&oacute;n de estudiantes m&aacute;s numerosa con el fin de identificar de forma m&aacute;s clara los factores que influyen en la baja calidad de la dieta de los estudiantes y poder establecer medidas correctoras precisas.</p>
', '2019-11-06', 'dicyt_2019_11_06_19_01_03.docx', 'UNIV. CRUZ ROMERO ROSA ANELISSE - UNIV. QUISPE LLALLI LIZETH - UNIV. RUIZ ANIBARRO AIRTON MARVIN - UNIV. VILLCA VASQUEZ JHONNY LEONCIO', '2018', '3', 'ING. LUIS ALBERTO ZEGARRA MAMANI', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('38', '5', '38', 'IMPLEMENTACIÓN DE LA MINA PILOTO EXPERIMENTAL SAN INOCENCIO EN EL CERRO RICO DE POTOSÍ', '1', '1', '<p>El&nbsp; objetivo&nbsp; del&nbsp; proyecto<strong><em>&nbsp; </em></strong>de la investigaci&oacute;n propuesta comprende, el&nbsp; estudio de implementaci&oacute;n de la Mina Piloto San Inocencio.</p>
', '<p>Toda formaci&oacute;n t&eacute;cnica se encuentra cimentada sobre un sistema de ense&ntilde;anza fundamentada en dos aspectos; la teor&iacute;a y la pr&aacute;ctica que permiten competencias de acuerdo a las exigencias de la industria en general.&nbsp; La disponibilidad de una mina completamente implementada para la ense&ntilde;anza, se constituye en el complemento pr&aacute;ctico de la teor&iacute;a, as&iacute; c&oacute;mo &nbsp;en el laboratorio para investigaciones mineras.</p>

<p>El presente estudio contempla la situaci&oacute;n en la que se encuentra la mina San Inocencio, desde la ubicaci&oacute;n, las condiciones de las labores existentes, hasta el dise&ntilde;o de la rehabilitaci&oacute;n, presenta tambi&eacute;n el costo de los requerimientos para la realizaci&oacute;n del presente Proyecto en su fase inicial, estableciendo par&aacute;metros reales para su respectiva consideraci&oacute;n, satisfaciendo de esta manera el objetivo del proyecto con el estudio de la implementaci&oacute;n.</p>

<p>Sin embargo, la implementaci&oacute;n, para su continuidad, requiere de &nbsp;otro presupuesto asegurado, antes de la iniciaci&oacute;n de la presente fase, cuya continuidad consolidar&aacute; el sue&ntilde;o anhelado de la Carrera de&nbsp; Ingenier&iacute;a de Minas.&nbsp; En consecuencia, con el presente estudio y luego de un an&aacute;lisis de los detalles, corresponder&aacute;&nbsp; a la instancia respectiva la definici&oacute;n del Proyecto de Implementaci&oacute;n, principalmente considerando la sostenibilidad del proyecto en el tiempo.</p>
', '<p>Se concluye el presente trabajo considerando dos aspectos muy importantes para la ejecuci&oacute;n del Proyecto: la primera; si bien es cierto que la administraci&oacute;n y la disponibilidad de una mina experimental piloto, con la infraestructura y el equipamiento necesarios para la realizaci&oacute;n de pr&aacute;cticas y/o de investigaci&oacute;n, traer&iacute;a consigo m&uacute;ltiples beneficios para docentes, estudiantes y porque no&nbsp; de extencionistas que se pueden capacitar en mandos medios.&nbsp; Para los docentes, la programaci&oacute;n de pr&aacute;cticas significar&iacute;a una segura continuidad de las mismas con la mayor libertad de mejorar par&aacute;metros de control, adem&aacute;s de la disponibilidad de materiales y herramientas conforme a las necesidades de una determinada pr&aacute;ctica.&nbsp; Para los estudiantes, con la mayor permanencia en un centro propio de pr&aacute;cticas y de investigaci&oacute;n significar&iacute;a un beneficio de vivencia y ambientamiento para un futuro desempe&ntilde;o en la industria minera, adem&aacute;s de la continuidad de sus pr&aacute;cticas.</p>

<p>El segundo aspecto; El presente&nbsp; emprendimiento, si bien es cierto traer&iacute;a grandes beneficios (despu&eacute;s de una segunda y talvez tercera fase) en lo acad&eacute;mico &ndash; pr&aacute;ctico, sin embargo&nbsp; requiere de una&nbsp; seria consideraci&oacute;n sobre todo de inversi&oacute;n econ&oacute;mica para la continuidad del Proyecto, tomando muy en cuenta las condiciones y las caracter&iacute;sticas con las que cuenta&nbsp; el medio en el que ubica la Mina San Inocencio.</p>

<p>Con los dos aspectos considerados, las conclusiones a las que se arriban en el estudio de la implementaci&oacute;n de la Mina San Inocencio podemos indicar:</p>

<ul>
	<li>Dadas las circunstancias y las condiciones en la que se encuentra la Mina San Inocencio, y por el resultado del estudio, sobre la base de la topograf&iacute;a, la mensura subterr&aacute;nea efectuada y&nbsp; el dise&ntilde;o del proyecto (consecuencia de los trabajos anteriores), requiere&nbsp; de un an&aacute;lisis&nbsp; que permita no solo aprobar&nbsp; el presente trabajo, sino proyectar la continuidad&nbsp; de la fase siguiente.</li>
	<li>Es evidente en el presente proyecto considerar la inversi&oacute;n hasta una tercera fase&nbsp; para una mayor implementaci&oacute;n de la mina, cuyo resultado significar&iacute;a la disponibilidad de un laboratorio para encontrar soluciones&nbsp; a innumerables problemas y desaf&iacute;os de la industria minera.</li>
	<li>La consideraci&oacute;n de la implementaci&oacute;n y la continuidad de la misma, debe tomar muy en cuenta labores existentes&nbsp; en las cabeceras, en el mismo nivel como en el piso, ya que por las caracter&iacute;sticas de explotaci&oacute;n en los socavones del Cerro Rico, las labores se realizan&nbsp; sin el menor reparo de seguridad y respeto en &aacute;reas de trabajo.</li>
	<li>La inversi&oacute;n de esta fase de acuerdo a la asignaci&oacute;n&nbsp; por concepto de IDH (1606 92,00&nbsp; Bs.), por el dise&ntilde;o del proyecto, s&oacute;lo permitir&aacute; la rehabilitaci&oacute;n&nbsp; de 50 metros&nbsp; subterr&aacute;neos, que permitir&aacute;n objetivos como los indicados en el numeral (2,5) respectivo, sin embargo los metros lineales&nbsp; rehabilitados no permitir&aacute;n&nbsp; sobre todo la preparaci&oacute;n de labores de explotaci&oacute;n tales c&oacute;mo la preparaci&oacute;n de rajos, por la proximidad&nbsp; a las labores existentes muy pr&oacute;ximos a la superficie.</li>
	<li>En el presente trabajo se ha detallado los requerimientos de una manera pr&aacute;ctica, sin embargo por las caracter&iacute;sticas propias del laboreo minero existentes riesgos de imprevistos ya sean de equipos, materiales como tambi&eacute;n humanos, &nbsp;que por la forma de administraci&oacute;n de recursos del IDH (previa aprobaci&oacute;n del mismo por el Departamento de Planificaci&oacute;n y Presupuestos de la U.A.T.F)&nbsp; no permitir&aacute; la inmediata&nbsp; soluci&oacute;n del imprevisto que se presentara.</li>
	<li>La conclusi&oacute;n de &eacute;sta primera fase (tal cual se encuentra&nbsp; programada con relaci&oacute;n al personal que se toma en cuenta) pone de manifiesto la necesidad de la contrataci&oacute;n del siguiente personal: 2 serenos (para turnos de 12 hrs), 2 trabajadores (perforista y ayudante) para trabajos de preparaci&oacute;n de pr&aacute;cticas y permanente mantenimiento de la mina, personal cuya dependencia debe ser de la Universidad con car&aacute;cter permanente dada la permanencia de equipo y materiales&nbsp; en la mina.</li>
	<li>La adquisici&oacute;n de explosivos debe ser bajo convenio con la sucursal de&nbsp; la f&aacute;brica FANEXA, para la utilizaci&oacute;n conforme a requerimiento del personal de voladura, como de las pr&aacute;cticas que as&iacute; lo requier.</li>
</ul>
', '2019-11-25', 'dicyt_2019_11_25_18_16_54.pdf', 'ING. RENé QUISPE LóPEZ', '2008', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('36', '1', '25', 'EL ATRACTOR DE UN SISTEMA DE FUNCIONES ITERADAS EN EL ESPACIO MÉTRICO DE HAUSDOFF', '1', '1', '<p>Sistematizar la teor&iacute;a acerca de las &nbsp;funciones contractivas de un sistema de funciones iteradas en el espacio m&eacute;trico completo de Hausdorff para generar un atractor.</p>
', '<p>En el presente trabajo de investigaci&oacute;n se estudia conjuntos cuya dimensi&oacute;n es un n&uacute;mero real menor o igual a la dimensi&oacute;n topol&oacute;gica del espacio que los contiene los cuales son llamados &ldquo;fractales&rdquo;</p>

<p>La definici&oacute;n de la topolog&iacute;a m&eacute;trica tiene una enorme importancia ya que se hace una extrapolaci&oacute;n de estas definiciones a otro espacio m&eacute;trico llamado el espacio de los fractales, y su posterior estudio proporciona las bases necesarias para definir el espacio donde yacen los fractales.</p>

<p>Se&nbsp; empieza por definir todos los elementos necesarios de la topolog&iacute;a m&eacute;trica, algunas propiedades de conjuntos, conjuntos compactos, abiertos y conexos, para despu&eacute;s definir&nbsp; el espacio m&eacute;trico de los fractales&nbsp; que se llama el espacio m&eacute;trico de Hausdorff o &ldquo;el lugar donde viven&rdquo;, la definici&oacute;n de completes resulta ser importante cuando su espacio base lo es por lo tanto los fractales pueden ser encontrados</p>

<p>Se da algunos modelos&nbsp; de fractales&nbsp; para la creaci&oacute;n de im&aacute;genes como ser&nbsp; una hoja, teniendo en cuenta la implementaci&oacute;n de un software adecuado para la creaci&oacute;n y construcci&oacute;n de fractales: definiendo sistemas de funciones contractivas de un sistema de funciones iteradas: que es el punto fijo del mismo que se denomina &ldquo;el atractor&rdquo; luego se estudia un algoritmo para crear estos atractores.</p>
', '<p>En este trabajo de investigaci&oacute;n cient&iacute;fica se ha podido dar soluci&oacute;n al problema planteado ya que se sistematiz&oacute; todos los elementos de las funciones contractivas en sistema de funciones iteradas, adem&aacute;s se observa la cualidad de autosemejanza de los atractores Se deja abierta algunos conceptos tales como dimensi&oacute;n fractal, la autosimilaridad y algunos instrumentos matem&aacute;ticos, tambi&eacute;n se toma en cuanta algunos algoritmos para la graficaci&oacute;n de dichos atractores quedando establecido que punto fijo de de una funci&oacute;n contractiva y atractor son una misma cosa.</p>

<p>En el desarrollo de los diferentes cap&iacute;tulos se logr&oacute; sistematizar toda la teor&iacute;a necesaria para, construir el atractor de un Sistema de Funciones Iteradas (SFI), cumpliendo as&iacute; el objetivo planteado. Para lo cual se desarroll&oacute; y determin&oacute; el fundamento te&oacute;rico referencial sobre un atractor de un SFI, dando as&iacute; respuesta al planteamiento del problema. Dejando abiertas ciertas hip&oacute;tesis para la aplicaci&oacute;n de los fractales en la creaci&oacute;n de im&aacute;genes reales y su posterior animaci&oacute;n</p>
', '2019-11-25', 'dicyt_2019_11_25_17_57_00.doc', 'LIC. JANET V. FLORES DELGADO            ', '2008', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('35', '13', '32', 'ANÁLISIS DE LA SITUACIÓN ACTUAL QUE ENFRENTAN LOS MICRO Y PEQUEÑOS EMPRESARIOS RESPECTO AL ACCESO AL FINANCIAMIENTO EN LA CIUDAD DE POTOSÍ', '1', '1', '<ul>
	<li>&ldquo;Identificar las barreras que enfrentan los micro y peque&ntilde;os empresarios en el acceso al financiamiento en el sistema financiero en la ciudad de Potos&iacute;, que le permitan financiar sus proyectos de inversi&oacute;n&rdquo;.</li>
	<li>&ldquo;Proponer estrategias para que los micro y peque&ntilde;as empresas de la ciudad de Potos&iacute; recurran al sistema financiero, para financiar sus proyectos de inversi&oacute;n&rdquo;.</li>
</ul>
', '<p>El presente trabajo de investigaci&oacute;n describe, caracteriza, y establece el estado actual que enfrentan los Micro y Peque&ntilde;os empresarios de la ciudad de Potos&iacute;, respecto al financiamiento; inicialmente se indica que el 43% de los encuestados tienen un profesi&oacute;n acad&eacute;mica, mientras los restantes 57% son comerciante y artesanos que realizan diferentes actividades en la ciudad de Potos&iacute;.</p>

<p>Las micro empresas se destacan en su conformaci&oacute;n por ser emprendedores de car&aacute;cter familiar, la mayor parte de los empleados son parientes cercanos que fluct&uacute;an de 1 a 10 empleados, que generalmente el propietario de la micro empresa no cumple con las normas legales de contrataci&oacute;n de personal. Mientras en t&eacute;rminos reducidos las peque&ntilde;as empresas se destacan por tener personal entre 10 a 20&nbsp; trabajadores, generalmente esta clase de empresas ya poseen tecnolog&iacute;a moderna de producci&oacute;n, ya dan cumplimiento a las normas establecidas sujeto al C&oacute;digo de Comercio, asimismo ya cumplen los tributos municipales.</p>

<p>Respecto al acceso al financiamiento, los micro y peque&ntilde;os empresarios que m&aacute;s han obtenido los pr&eacute;stamos son las empresas dedicadas al comercio seguido por las actividades de servicio y finalmente los fabricantes de bienes; los intereses para diferentes actividades ofrecidas por las entidades financieras son muy elevadas, por lo que se les hace muy dif&iacute;cil cumplir sus obligaciones por parte de los propietarios de las MYPEs.</p>

<p>Las entidades financieras otorgaron los cr&eacute;ditos a&nbsp; los MYPEs, en mayor proporci&oacute;n para incrementar el inventario, para la adquisici&oacute;n de maquinaria y herramientas, en algunos casos para ampliar la producci&oacute;n de la empresa y finalmente en menor proporci&oacute;n para construir el inmueble de la empresa. En cambio los ONGs otorgaron cr&eacute;ditos a reducidos tasas de inter&eacute;s a micro y peque&ntilde;os emprendedores de actividades comerciales y artesanales.</p>

<p>Los micro y peque&ntilde;os empresarios en su generalidad no tienen conocimiento de las actividades desarrolladas en el Mercado de Valores, simplemente en un porcentaje reducido conocen algunos instrumentos financieros como ser: acciones, bonos, dep&oacute;sitos a plazo fijo y otros; pero, los propietarios est&aacute;n dispuestos y motivados de ser part&iacute;cipes con el prop&oacute;sito siempre de buscar financiamiento que les posibilite incrementar el valor de sus empresas, de esta manera generar m&aacute;s fuentes de trabajo para la sociedad.</p>

<p>En el presente trabajo se destaca tambi&eacute;n las propuestas financieras para la obtenci&oacute;n de financiamiento mediante instrumentos financieros que se pueden emitir en el Mercado de Valores como ser: bonos de empresas, acciones, etc. As&iacute; mismo se pueden utilizar el instrumento como el leasing para arrendarse maquinaria y equipo; por otra parte se pueden realizar un contrato de factoring para no tener problemas en la liquidez de la empresa.</p>
', '<ul>
	<li>En la ciudad de Potos&iacute; se han encuestado a 104 micro y peque&ntilde;as empresa productoras, de las cuales el 50% se dedican a las actividades de servicios; 29% se dedican a las actividades comerciales; en tanto las actividades industriales es de poca escala que llegan solamente al 17%. Respecto a los trabajadores, se han identificado en 78 micro y peque&ntilde;as empresas que trabajan de 1 a 4 trabajadores, mientras en 18 empresas trabajan de 5 a 10 personas, en tanto de 11 a 20 personas trabajan en 8 peque&ntilde;as empresas. Los ingresos mensuales que perciben producto de las actividades comerciales en 70 microempresas es de 1000 a 5000Bs, mientras en 26 empresa el ingreso est&aacute;n entre 5001 20000 y finalmente en los restantes 8 empresas sus ingresos mensuales est&aacute;n entre 20001 a 50000.</li>
	<li>En cuanto a la obtenci&oacute;n de cr&eacute;ditos el 60% de los propietarios de las MYPEs, no obtuvieron los pr&eacute;stamos, por las elevadas tasas de inter&eacute;s ofrecidas por las entidades financieras, asimismo por los exagerados requisitos que son: garant&iacute;a personal, garant&iacute;a hipotecaria, boletas de sueldos, facturas de luz y agua y otras. Aunque el 75% de los due&ntilde;os de las micro y peque&ntilde;as empresas tienen deseos de obtener recursos para ampliar la producci&oacute;n y servicios. En cuanto al conocimiento del Mercado de Valores, el 72% de los propietarios de las MYPEs no conocen del funcionamiento del Mercado de Valores, solo algunos encuestados manifestaron conocer los instrumentos financieros como: acciones, bonos, dep&oacute;sitos a plazo fijo y certificados de Dep&oacute;sito del BCB.</li>
	<li>Seg&uacute;n datos obtenidos de las entidades financieras, la poblaci&oacute;n de clientela que poseen estas entidades, caracterizan a la mayor proporci&oacute;n a los MYPEs entre el 40% y 80%, siendo los microempresarios de las diferentes actividades que sostienen a las entidades financieras.</li>
</ul>
', '2019-11-25', 'dicyt_2019_11_25_17_53_26.pdf', 'LIC. OSCAR BUEZO MAYORA', '2009', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('37', '1', '5', 'VARIACIÓN DE LA PRESIÓN EN LA CÁMARA HIPERBÁRICA MONOPLAZA', '1', '1', '<p>Determinar la variaci&oacute;n de la presi&oacute;n en c&aacute;mara hiperb&aacute;rica monoplaza; que contribuir&aacute; en controlar el flujo de aire regulable (presurizaci&oacute;n y despresurizaci&oacute;n) para cada paciente con desadaptaci&oacute;n aguda a la altura; y bajar al paciente en forma ficticia en minutos de los 4.000&middot;m a 2.000msnm dentro la c&aacute;mara hiperb&aacute;rica.</p>
', '<p>La construcci&oacute;n de la c&aacute;mara, fue realizada por el t&eacute;cnico (Don Camillo Maman&iacute;). La c&aacute;mara tiene: camilla m&oacute;vil, porta aud&iacute;fono, compuerta, ventanas de vidrio, ruedas (4), tablero de mando, dos entradas de presi&oacute;n de aire, y una salida (circulaci&oacute;n) para evacuaci&oacute;n del CO2. Pintado internamente y externamente, de color azul y veis.<br />
Las pruebas preliminares se hicieron en Facultad de Medicina (Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as), para calibrar los man&oacute;metros mec&aacute;nicos; para medir la presi&oacute;n y la altura (profundidad) dentro la c&aacute;mara, porque los equipos que se compraron; no marcaron la presi&oacute;n deseada o calculada, como se pueden apreciar en las tablas. Colocamos los man&oacute;metros (anal&oacute;gicos (dos) primero en serie y luego en paralelo con sus respectivas conexiones. Por ese motivo se construyo un man&oacute;metro en U de mercurio en la carrera de F&iacute;sica por el licenciado Rub&eacute;n Huallpa; se comparo con un man&oacute;metro de mercurio del Dr. Rene V&aacute;squez; y otros que compramos y que nos prestaron; la presi&oacute;n en los diferentes equipos no registraron la misma medida; pero el equipo electr&oacute;nico construido por el Licenciado Eduardo Choque, es m&aacute;s preciso.</p>

<p>Todo el trabajo de calibraci&oacute;n, lo realizamos los Licenciados: Eduardo Choque Mamani, Gregorio Mu&ntilde;oz Chavez y Rub&eacute;n Huallpa Santos.</p>
', '<p>Valorar el cumplimiento de los objetivos espec&iacute;ficos, la contestaci&oacute;n de la hip&oacute;tesis y la reducci&oacute;n del problema. Las observaciones experimentales y los resultados obtenidos en la presente investigaci&oacute;n permiten concluir: Como epilogo del presente proyecto se indica:</p>

<ul>
	<li>Las variables m&aacute;s importantes que intervienen en el proceso son: la presi&oacute;n, temperatura y densidad del aire, y los mecanismos (man&oacute;metros: anal&oacute;gicos (dos) y digital (uno)).</li>
	<li>La densidad es tambi&eacute;n inversamente proporcional a la temperatura. A mayor temperatura menor densidad.</li>
	<li>Concluido el proyecto las autoridades tendr&aacute;n que buscar una empresa, para certificar la calidad de la construcci&oacute;n de la c&aacute;mara hiperb&aacute;tica, para dar sus servicios a los pacientes en general.</li>
	<li>Todo el trabajo fue realizado en cumplimiento de normas internaciones, asegur&aacute;ndose de esta forma la seguridad del personal y el equipo derivando en el &oacute;ptimo desempe&ntilde;o, una vez puesta en marcha. La soldadura en recipientes, se trabajo bajo el c&oacute;digo A.S.M.E.</li>
	<li>El tablero de distribuci&oacute;n como los man&oacute;metros anal&oacute;gicos (dos) y digital son especificados en base a los estudios de flujos, garantiz&aacute;ndose de esta forma el &oacute;ptimo desempe&ntilde;o de este tablero en las condiciones trabajo.</li>
	<li>Capacitaci&oacute;n del personal: Una vez construido la c&aacute;mara hiperb&aacute;rica mono-plaza, se realizar&aacute; actividades de entrenamiento a personal medico e interesados. En el uso y manejo del equipo de medicina hiperb&aacute;rica.</li>
</ul>

<p>Sumario: Las caracter&iacute;sticas b&aacute;sicas del aire como fluido son: presi&oacute;n, temperatura y densidad.</p>

<p>(Densidad del aire es la cantidad de masa del mismo por unidad de volumen, Presi&oacute;n, temperatura y densidad son inversamente proporcionales a la altura.A mayor altura, menor presi&oacute;n, menor temperatura y menor densidad.</p>
', '2019-11-25', 'dicyt_2019_11_25_18_05_13.pdf', 'LIC. GREGORIO MUÑOZ CHAVEZ', '2009', '3', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('39', '5', '38', 'ESTUDIO, APLICACIÓN Y CAPACITACIÓN DE SOFTWARE MINEROS ESPECIALIZADOS', '1', '1', '<p>El <strong><em>objetivo del proyecto</em></strong>; el estudio, aplicaci&oacute;n y capacitaci&oacute;n de software minero especializado.</p>
', '<p>De las diferentes revoluciones que ha sufrido la miner&iacute;a en el presente siglo (implantaci&oacute;n de m&aacute;quinas con capacidades y rendimientos mayores, desarrollo de la econom&iacute;a en escala, etc.) una de las m&aacute;s importantes y de mayor trascendencia ha sido sin lugar a dudas, la transformaci&oacute;n a principios de los a&ntilde;os 80 por el desarrollo de los softwares mineros de manera paralela a la llegada de los ordenadores personales.</p>

<p>Estas innovaciones tecnol&oacute;gicas,&nbsp; ha permitido a la industria minera, mejorar los rendimientos de producci&oacute;n y al mismo tiempo disminuir el riesgo econ&oacute;mico de las operaciones.</p>

<p>El trabajo, presenta un resumen de la existencia en el mercado especializado minero de estas herramientas cibern&eacute;ticas, para contribuir al conocimiento general, de la gran variedad de programas inform&aacute;ticos, particularmente&nbsp; a nivel mundial.&nbsp; El estudio realizado incluye en el Cap&iacute;tulo II, &nbsp;la caracterizaci&oacute;n del <em>Programa Sherpa,</em> cuyo anexo de referencia muestra la salida de resultados que realiza el programa.&nbsp; Finalmente se recomienda la adquisici&oacute;n de uno de los programas indicados en el estudio, para beneficio de la Carrera de Ingenier&iacute;a de Minas y de la competitividad en la industria miner&iacute;a.</p>

<p>Se adjunta en medio magn&eacute;tico, tutoriales y manuales que permitir&aacute;n conocer mayores detalles de algunos programas inform&aacute;ticos.</p>
', '<p>A la conclusi&oacute;n del presente informe, correspondiente al per&iacute;odo&nbsp; Marzo &ndash; Julio (I/2009) de la presente Gesti&oacute;n acad&eacute;mica, es importante realizar las conclusiones por el trabajo realizado y porque adem&aacute;s&nbsp; a trav&eacute;s del mismo se logr&oacute; determinar aspectos puntuales que permitir&aacute;n la continuidad de la innegable responsabilidad de conocer para transmitir &ndash; capacitar, el conocimiento de programas&nbsp; computacionales tan requeridos en la gran miner&iacute;a actual. Por estos motivos indicamos lo siguiente:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>

<ul>
	<li>La variedad de programas inform&aacute;ticos&nbsp; nombrados en el presente trabajo, no representa a la totalidad de los mismos, existen otros que por diversas causas no fueron mencionados, sin embargo, las referencias que se presentan servir&aacute;n como informaci&oacute;n para una posible adquisici&oacute;n.</li>
	<li>En todo el proceso del conjunto de una operaci&oacute;n desde la etapa de exploraci&oacute;n, la preparaci&oacute;n y la respectiva producci&oacute;n &uacute; explotaci&oacute;n, demanda un sin fin de operaciones&nbsp; y en consecuencia una aplicaci&oacute;n o utilizaci&oacute;n de varios softwares, as&iacute; como de programas integrados que facilitan por lo tanto varias ventajas, que repercuten indudablemente en el costo de adquisici&oacute;n de estos paquetes integrados.</li>
	<li>La propuesta de aplicaci&oacute;n y capacitaci&oacute;n presentada, fue elaborada para&nbsp; la culminaci&oacute;n del trabajo de investigaci&oacute;n, sin embargo&nbsp; considero oportuno efectuar una revisi&oacute;n y consecuentemente un enriquecimiento o complementaci&oacute;n para&nbsp; efectuar cursos de capacitaci&oacute;n en el tema abordado en el presente trabajo.</li>
	<li>La presentaci&oacute;n descriptiva del programa SHERPA, se realiza para mostrar como ejemplo de las caracter&iacute;sticas del input de datos para obtener los output del programa (presentado en Anexos). El software es un programa realmente &uacute;til para la planificaci&oacute;n y evaluaci&oacute;n previa de la explotaci&oacute;n de una mina, en cierta manera es menos amplio que otros&nbsp; programas inform&aacute;ticos, ya que se restringe a la operaci&oacute;n minera propiamente dicha y no entra en estudios de rentabilidad por falta de informaci&oacute;n.</li>
	<li>Sin embargo, el costo de la operaci&oacute;n minera lo estudia con toda profundidad, constituyendo una herramienta de indudable utilidad para el ingeniero que planifica o dise&ntilde;a una mina.</li>
	<li>El principio de un conocimiento en el apasionante mundo de softwares mineros, se encuentra en una Licencia, que deber&aacute; ser obtenida de manera directa y por la respectiva compra de un fabricante o representante oficial.</li>
	<li>Es importante la interrelaci&oacute;n con la Gran industria minera, para la coordinaci&oacute;n de pr&aacute;cticas de aplicaci&oacute;n de software, siendo necesaria la disponibilidad de medios como datos para hacer &ldquo;<em>correr&rdquo;</em> cualquier software minero.</li>
	<li>La inversi&oacute;n&nbsp; en la adquisici&oacute;n de software, significar&aacute; una modernizaci&oacute;n del conocimiento en el campo inform&aacute;tico, para aplicaciones sobre todo en la gran miner&iacute;a, que de un tiempo a esta parte se vienen desarrollando&nbsp; en nuestro Pa&iacute;s y&nbsp; de manera m&aacute;s adelantada en los pa&iacute;ses vecinos como; Chile, Per&uacute;&nbsp; y tambi&eacute;n Argentina.&nbsp; En el contexto mundial la aplicaci&oacute;n de programas inform&aacute;ticos es mucha m&aacute;s generalizada, motivo&nbsp; por el cual se viene dando&nbsp; frecuentes innovaciones,&nbsp; producto de la abierta competencia entre las diferentes empresas dedicadas exclusivamente&nbsp; a la creaci&oacute;n e innovaci&oacute;n de soluciones cibern&eacute;ticas.</li>
	<li>Tambi&eacute;n se adjunta en el mismo medio&nbsp; manuales y tutoriales de algunos programas obtenidos durante la b&uacute;squeda de informaci&oacute;n para realizar el trabajo de investigaci&oacute;n llevado a las instancias actuales.</li>
	<li>Una conclusi&oacute;n final y muy importante, es qu&eacute;,&nbsp; definitivamente debemos incursionar en el conocimiento, manejo y aplicaci&oacute;n de programas, como vienen&nbsp; realizando pa&iacute;ses vecinos con ambiciosos planes de formaci&oacute;n y capacitaci&oacute;n en sus unidades facultativas como sucede en la Rep&uacute;blica Argentina, (Universidad Nacional de San Lu&iacute;s) que viene implementando su laboratorio con Surpac Vision (Australia), un software Geol&oacute;gico &ndash; Minero de &uacute;ltima generaci&oacute;n usado en muchas empresas alrededor del mundo.</li>
</ul>
', '2019-11-25', 'dicyt_2019_11_25_18_24_52.pdf', 'ING. RENé QUISPE LóPEZ', '2009', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('41', '18', '40', 'DISEÑO DE UN SISTEMA DE TRANSMISIÓN INALÁMBRICA DE ENERGÍA ELÉCTRICA POR ACOPLAMIENTO INDUCTIVO RESONANTE', '1', '2', '<p>El objetivo general de la presente investigaci&oacute;n es el de<strong> &ldquo;D</strong><strong>ise&ntilde;ar el sistema &oacute;ptimo de transmisi&oacute;n de energ&iacute;a el&eacute;ctrica para potencias medias </strong><strong>que contemple la eficiencia del sistema&rdquo;.</strong></p>
', '<p>El objetivo de este proyecto es el dise&ntilde;o y elaboraci&oacute;n transmisi&oacute;n inal&aacute;mbrica de energ&iacute;a dentro del campo del electromagnetismo.</p>

<p>Para llegar a ese objetivo es necesario entender el funcionamiento de la transmisi&oacute;n inal&aacute;mbrica de energ&iacute;a, conocer sus conceptos b&aacute;sicos e implementarlos para el respectivo dise&ntilde;o.</p>

<p>La teor&iacute;a de la transmisi&oacute;n inal&aacute;mbrica de energ&iacute;a se basa en el principio de campos magn&eacute;ticos resonantes acoplados trabajando en la regi&oacute;n no radiativa o reactiva que pertenece a la regi&oacute;n de campo cercano.</p>

<p>Se comienza haciendo un an&aacute;lisis de los conceptos te&oacute;ricos que se necesitan para generar transmisi&oacute;n inal&aacute;mbrica de energ&iacute;a, luego se emplea un programa de simulaci&oacute;n de circuitos (Proteus) para finalmente con los datos calculados y simulados llevarlos a la elaboraci&oacute;n del dise&ntilde;o.</p>

<p>El montaje consta de un sistema que est&aacute; formado fundamentalmente de un circuito transmisor&nbsp; y un circuito receptor.</p>

<p>El circuito transmisor est&aacute; formado por una bobina y un condensador colocado en paralelo y a su vez es alimentado por una se&ntilde;al sinusoidal de onda cuadr&aacute;tica, por la implementaci&oacute;n de un circuito Royer.</p>

<p>El circuito receptor est&aacute; formado por otra bobina que est&aacute; en paralelo con otro condensador y a su vez tiene conectado una carga.</p>

<p>Circuito transmisor y receptor se encuentran separados f&iacute;sicamente distancias superiores a 30 cm a lo largo del eje imaginario que une las bobinas emisora y receptora.</p>

<p>La teor&iacute;a de la transmisi&oacute;n inal&aacute;mbrica de energ&iacute;a se basa en el concepto de resonancia entre dos objetos resonantes y acoplados. El objetivo de colocar el condensador en paralelo en el circuito transmisor es acoplar la se&ntilde;al que proviene del generador de se&ntilde;ales con la bobina transmisora, y de sintonizar la frecuencia de resonancia del sistema.</p>

<p>La funci&oacute;n que cumple el condensador en el circuito receptor es sintonizar la frecuencia de resonancia del sistema y adaptar la impedancia de carga consiguiendo la m&aacute;xima transferencia de potencia posible.</p>
', '<p>En el dise&ntilde;o, la transmisi&oacute;n de energ&iacute;a inal&aacute;mbrica logro un alcance m&aacute;ximo de hasta 50 cm con la mejor combinaci&oacute;n posible de bobinas colocadas en el circuito transmisor y receptor.</p>

<p>Para que un sistema est&eacute; acoplado, en el circuito transmisor es necesario colocar&nbsp; un condensador en serie entre el circuito oscilador&nbsp; y la bobina transmisora. El condensador cumple la funci&oacute;n de acoplar la se&ntilde;al que proviene del oscilador con la bobina y la de sintonizar la frecuencia del circuito transmisor con la del sistema que es la de resonancia.</p>

<p>El condensador ubicado en paralelo entre la bobina receptora y la carga cumple la funci&oacute;n de sintonizar la frecuencia de resonancia del circuito receptor con la frecuencia de resonancia del sistema y la de adaptar la impedancia de la bobina y la carga permitiendo la m&aacute;xima transferencia de potencia. Si no se colocase el condensador en el circuito receptor el sistema estar&aacute; solamente acoplado, pero no ser&aacute; resonante, debido a que no las frecuencias podr&iacute;an ser diferentes a las del emisor.</p>

<p>En el fen&oacute;meno de la transmisi&oacute;n de energ&iacute;a inal&aacute;mbrica, una vez ajustado el sistema no se pueden intercambiar las bobinas transmisora y receptora, es decir, salvo que las dos bobinas empleadas tanto en el circuito transmisor como en el receptor sean id&eacute;nticas.</p>

<p>Trabajar con un sistema acoplado resonante permite que se obtengan mejores valores de coeficiente de acoplamiento <em>k </em>cercanos a uno.</p>

<p>El dise&ntilde;o de la geometr&iacute;a de la bobina transmisora permite que se obtenga un alto factor de calidad Q de ella, minimizando las p&eacute;rdidas que se producen especialmente debido a la resistencia &oacute;hmica que presenta la bobina.</p>

<ul>
	<li>Cuanto mayor es el n&uacute;mero de vueltas de la bobina transmisora, menos eficiente es el sistema</li>
	<li>Tiene una mayor influencia en el rendimiento del sistema el &aacute;rea de la bobina transmisora que su longitud.</li>
	<li>A menor categor&iacute;a AWG tenga el cable de cobre unifilar que forman las bobinas, el sistema posee un mayor rendimiento.</li>
</ul>
', '2020-02-26', 'dicyt_2020_02_26_21_05_43.docx', 'UNIV. CINTYA MENESES CRUZ', '2019', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('40', '13', '32', 'CAPITAL DE RIESGO COMO FUENTE DE FINANCIAMIENTO PARA LA ADQUISICIÓN  DE MAQUINARIA QUE PERMITA OPTIMIZAR LA PRODUCTIVIDAD DE LA EMPRESA DE SERVICIO?SOMIVILLA SRL?DE LA CIUDAD DE POTOSÍ', '1', '2', '<p>Mejorar la calidad de vida y el desarrollo socioecon&oacute;mico de la poblaci&oacute;n que realiza la actividad minera, a trav&eacute;s de la incentivaci&oacute;n de medidas que incidan la mejora de las infraestructuras, productos, la puesta en valor y protecci&oacute;n de los recursos patrimoniales de los socios de la empresa de servicio SOMIVILLA SRL&nbsp;&nbsp; de tal forma que fomenten pol&iacute;ticas dentro de la empresa.</p>
', '<p>En este trabajo de investigaci&oacute;n, se lo realiz&oacute; con el objetivo principal de identificar una nueva manera de financiamiento, que ayude a la Empresa de servicio Somivilla Srl. por tal el t&iacute;tulo es &ldquo;Capital de Riesgo como fuente de financiamiento para la adquisici&oacute;n&nbsp; de maquinaria que permita optimizar la productividad de la Empresa de Servicios Somivilla SRL de la Ciudad de Potos&iacute; &ldquo; de la cual tiene como caracter&iacute;stica, que el financiador pasa&nbsp; a ser socio en la empresa que financian y como tambi&eacute;n contribuye con conocimientos en el &aacute;rea financiera y marketing.</p>

<p>El diagn&oacute;stico de la investigaci&oacute;n, se vio que la empresa minera realiza el servicio de tratamiento o purificaci&oacute;n de tres tipos de minerales como ser, plata, zinc y&nbsp; esta&ntilde;o, de la cual requieren optimizar su productividad debido a que en los &uacute;ltimos dos a&ntilde;os tuvo una mala productividad debido a la falta de maquinar&iacute;as, generando as&iacute; bajos ingresos y utilidades. Se realiz&oacute; una encuesta a los empleados de producci&oacute;n la cual se determin&oacute; que se requiere de maquinarias nuevas y de mayor capacidad en cada uno de sus &aacute;reas y en la entrevista&nbsp; realizada al due&ntilde;o como al contador, mencionan la necesidad de efectivo para adquisici&oacute;n de maquinarias que permita la optimizaci&oacute;n de la productividad.</p>

<p>Dentro de la propuesta se determin&oacute; el presupuesto para la adquisici&oacute;n de maquinaria, ingresos, costos, gastos,&nbsp; capital de trabajo y finalmente se realiz&oacute; un flujo de efectivo&nbsp; de la cual se determin&oacute; &nbsp;la viabilidad del financiamiento mediante&nbsp; el Capital de riesgo para la empresa minera, ya que se logr&oacute; optimizar la productividad mediante la adquisici&oacute;n de&nbsp; maquinaria.</p>

<p>Los resultados de la investigaci&oacute;n demuestra la viabilidad del trabajo la cual puede ser implementada en la Empresa de Servicios SOMIVILLA SRL , ya que el financiamiento mediante el Capital de Riesgo&nbsp; es una buena alternativa, como tambi&eacute;n contribuye a la Facultad<strong> </strong>de Ciencias Econ&oacute;micas Financieras y Administrativas , m&aacute;s espec&iacute;ficamente al &aacute;rea Financiera.</p>
', '<ol>
	<li>La presente investigaci&oacute;n se ha dedicado al estudio del capital de riesgo para optimizar la productividad ,que permita la ejecuci&oacute;n de proyectos corriendo el riesgo que es caracter&iacute;stica , los participantes de este tipo de financiamiento son la entidad financiera que aporta el capital ,de la cual no tiene una tasa de inter&eacute;s por el financiamiento ,m&aacute;s al contrario es beneficiosa para la empresa que financian ya que en el Balance la deuda no aumenta el pasivo m&aacute;s al contrario incrementa el patrimonio, debido a que el financiador pasa a ser socio de la empresa a largo plazo , es decir 5 a&ntilde;os m&aacute;ximo en la que comparten los derechos y obligaciones de la empresa.</li>
	<li>As&iacute; mismo en el Diagnostico se determin&oacute; la falta efectivo para la adquisici&oacute;n de maquinaria, ya que &nbsp;el financiamientos tradicionales como ser el Banco no realizan pr&eacute;stamos a empresas en el rubro minero debido a que es riesgoso el financiamiento a las mismas, de tal forma que obstaculizan el crecimiento y desarrollo de las empresas, es por eso que la empresa de servicio Somivilla SRL. aceptan la aplicaci&oacute;n del capital de riesgo como alternativa de financiamiento, ya que es la m&aacute;s adecuada dentro del rubro al que pertenece la empresa.</li>
	<li>De tal forma la necesidad de impulsar el desarrollo de la empresa, se fue en busca de un financiamiento adecuado que es el Capital de riesgo, la cual logra mejorar el servicio mediante la adquisici&oacute;n de maquinarias como tambi&eacute;n optimiza la productividad permitiendo su crecimiento y desarrollo. Obteniendo de esta manera una empresa competitiva que pueda hacer frente a la competencia ya que en Potos&iacute; se tienen mucha competencia en el &aacute;rea minera.</li>
</ol>
', '2020-02-12', 'dicyt_2020_02_12_23_53_09.docx', 'UNIV. VERóNICA NOHELIA ISLA GARNICA ', '2019', '2', 'LIC. RENE ERIK BOBARIN RíOS', 'Descriptivo y explicativo ');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('45', '18', '44', 'DISEÑO Y CONSTRUCCION DE UNA IMPRESORA 3D BICOLOR PARA PIEZAS ROBÓTICAS REQUERIDAS Y DISEÑADAS EN CAD, OBTENIENDO PRODUCCIÓN EN SERIE', '1', '2',  E'<p>Dise&ntilde;ar e implementar una impresora 3D en serie, para dise&ntilde;ar en CAD (Dise&ntilde;o Asistido por computador), y a partir de esta fabricar modelos de tercera dimensi&oacute;n (largo, ancho y profundidad)</p>\\r\\n',  E'<p>Este proyecto de impresora 3D bicolor para piezas rob&oacute;ticas es una m&aacute;quina capaz de realizar r&eacute;plicas de dise&ntilde;os en 3D, creando piezas o maquetas volum&eacute;tricas a partir de un dise&ntilde;o hecho por ordenador CAD. Surgen con la idea de convertir archivos de 2D en prototipos reales o 3D. Com&uacute;nmente se ha utilizado en la prefabricado de piezas o componentes, en sectores como la arquitectura y el dise&ntilde;o industrial. En la actualidad se est&aacute; extendiendo su uso en la fabricaci&oacute;n de todo tipo de objetos, modelos para vaciado, piezas complicadas, (ya que la impresi&oacute;n 3D permite adaptar cada pieza fabricada a las caracter&iacute;sticas exactas de cada fabricante).</p>\\r\\n\\r\\n<p>La impresi&oacute;n 3D en el sentido original del t&eacute;rmino se refiere a los procesos en los que secuencialmente se acumula material en una cama o plataforma por diferentes m&eacute;todos de fabricaci&oacute;n en este proyecto el m&eacute;todo tomado es el de extrusi&oacute;n de material o indistintamente llamado Deposito de Material Fundido.</p>\\r\\n\\r\\n<p>En el desarrollo del proyecto el lector tendr&aacute; la capacidad de interpretar y entender a la perfecci&oacute;n como es la construcci&oacute;n y por ende la manipulaci&oacute;n de una impresora 3D y elaborar las piezas que desee. La fabricaci&oacute;n de los productos depende de la capacidad de transformar la materia prima en las piezas necesarias para conformar un producto y obtener as&iacute; a un mueble, una m&aacute;quina, un electrodom&eacute;stico etc. Es por eso que la manufactura es un aspecto importante en el desarrollo de la tecnolog&iacute;a en la vida cotidiana.</p>\\r\\n\\r\\n<p>Muchas de estas piezas de diversos productos tienen que ser muy precisas en su manufactura para que tengan una forma o una caracter&iacute;stica especifica adecuada y as&iacute; el producto al que pertenecen pueda desarrollar su funci&oacute;n de una manera &oacute;ptima. La impresora 3D ofrece la construcci&oacute;n de varios prototipos previamente dise&ntilde;ados en un programa CAD y utiliza material como ABS, PLA que ofrece buenas caracter&iacute;sticas.</p>\\r\\n',  E'<ul>\\r\\n	<li>Imaginar una impresora 3D en cada&nbsp;hogar puede parecer una utop&iacute;a, pero ya vemos que no lo es tanto. Con el tiempo, estas, demostraron valerse por sí mismas y generar avances que provocan el desconcierto popular. &iquest;Qui&eacute;n hubiera imaginado hace 10 años que iba a existir un dispositivo capaz de reproducir cualquier objeto que pase por nuestras manos? y... &iquest;Qué tambi&eacute;n iban a producir avances en el campo de las ciencias? Y m&aacute;s a&uacute;n son las soluciones&nbsp; en el &aacute;rea de la rob&oacute;tica para poder elaborar la pieza de cualquier robot que no se pueda encontrar en el mercado y m&aacute;s a&uacute;n es favorable ya que su valor econ&oacute;mico es favorable&nbsp; y est&aacute; hecho a gusto del cliente.</li>\\r\\n	<li>Se ensamblo un prototipo de impresora 3D en serie para el dise&ntilde;o de piezas rob&oacute;ticas, por medio del uso de CAD, optimizando tiempo de elaboraci&oacute;n y dinero en el proceso constructivo.</li>\\r\\n	<li>Se logr&oacute; obtener dise&ntilde;os 3D usando filamento PLA, dise&ntilde;os a la necesidad de cada individuo especialmente piezas rob&oacute;ticas</li>\\r\\n	<li>Gracias al uso de programas de c&oacute;digo abierto permiten trabajar de forma libre evitando las limitantes que genera costear una licencia de un programa.</li>\\r\\n	<li>El control de la impresora se fundamenta en la tarjeta Arduino mega 2560 y ramps 1.4, debido al bajo precio y una programaci&oacute;n no complicada resulta excelente para el proyecto.</li>\\r\\n	<li>Para el dise&ntilde;o de las piezas se eligi&oacute; aplicaciones con un entorno intuitivo que permita que el dise&ntilde;ador se sienta c&oacute;modo y pueda empezar a dise&ntilde;ar sin problemas. Adem&aacute;s, tambi&eacute;n se hace uso de bibliotecas online donde se puede descargar dise&ntilde;os elaborados y realizar alg&uacute;n cambio seg&uacute;n el de cada usuario.</li>\\r\\n</ul>\\r\\n', '2020-02-26', 'dicyt_2020_02_26_22_18_58.docx', 'UNIV. HILDA AMELIA BAñOS BOLIVAR', '2019', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('44', '18', '42', 'DISEÑO, CONSTRUCCIÓN DE UNA MÁQUINA AMASADORA Y DOSIFICADORA DE INGREDIENTES PARA EL AMASADO DE PAN', '1', '2', '<p>Dise&ntilde;o, construcci&oacute;n de una m&aacute;quina amasadora industrial y dosificadora de adictivos y condimentos para elaborar amasado de pan, que sea capaz de preparar la masa con mayor velocidad y calidad; que un trabajador humano, obteniendo resultados que impulsen la creaci&oacute;n de nuevas microempresas.</p>
', '<p>Actualmente en la regi&oacute;n Norte de departamento de Potos&iacute;, espec&iacute;ficamente en Villa imperial, existe un gran n&uacute;mero de microempresas panificadoras, hoy en d&iacute;a este proceso se realiza en mesas para moldear y amasar el pan manualmente, los cuales son los elementos que generan mayores costos en las empresas, con la p&eacute;rdida de tiempo, mano obra y materia prima, para conseguir la homogeneidad de la mezcla. Con fin de disminuir estas malas pr&aacute;cticas, existen diversas herramientas y m&eacute;todos que permiten llevar un mayor control en las empresas, mejorando la productividad. Para este trabajo primero se analiz&oacute; que la perdida de rendimiento y productividad, centr&aacute;ndose en la etapa de amasado y un sistema dispensador para los ingredientes, la cual se puede optimizar mediante la tecnificaci&oacute;n de este proceso, para elaborar productos con mejor calidad.&nbsp; De esta manera se analizaron los par&aacute;metros de dise&ntilde;o de una m&aacute;quina amasadora y su sistema de dispensador controlados por tiempos, haciendo uso de los fundamentos de elementos de m&aacute;quinas, en lo que concierne a dimensiones y sus propiedades estructurales. Por consiguiente, con este dise&ntilde;o se espera; mejorar el estilo de vida de los trabajadores ayudando a una mayor productividad y calidad en los productos fabricados en el rubro de panificaci&oacute;n, asimismo generando un menor costo en la producci&oacute;n.</p>

<p>El presente proyecto describe el dise&ntilde;o y construcci&oacute;n de una maquina amasadora de pan y dosificador de los ingredientes necesarios del mismo, usando como controlador PIC (Micro ML-CHIP1 Basado en PIC16F876A de 28 Pines) y todo tipo de componentes necesario.</p>
', '<p>El objetivo principal de la investigaci&oacute;n se consigui&oacute;: &ldquo;Dise&ntilde;ar y construir una m&aacute;quina para amasar pan con una capacidad de 50 Kg/h de producci&oacute;n, accionada por un motor trif&aacute;sico, lo que satisface las necesidades y requerimientos establecidos por el cliente.</p>

<p>Para la construcci&oacute;n se aplicaron conocimientos y recursos que nos presenta la nueva tecnolog&iacute;a como son: Dibujo aplicado de planos a trav&eacute;s del programa SOLIDWORKS o AutoCad para el dise&ntilde;o en 3D, Soldaduras especiales TIG Y MIG en los procesos de manufactura de la m&aacute;quina como tambi&eacute;n el conocimiento en m&aacute;quinas-herramientas para que se cumpla la fiabilidad de la m&aacute;quina determinada en el dise&ntilde;o de la amasadora y su excelente presentaci&oacute;n de la parte de dosificaci&oacute;n de los adictivos y condimentos.</p>

<p>Siendo una m&aacute;quina muy pr&aacute;ctica tanto en construcci&oacute;n y mantenimiento es factible aumentar o reducir las revoluciones por minuto u otro par&aacute;metro de dise&ntilde;o, al cambiar alg&uacute;n elemento mec&aacute;nico de transmisi&oacute;n tanto del amasador como del dosificador de ingredientes.</p>

<p>Luego de realizar la prueba de ensayo se observ&oacute; y se registr&oacute; datos t&eacute;cnicos sobre el proceso de producci&oacute;n: cuantitativos y cualitativos como: trabajar con la m&aacute;quina durante la elaboraci&oacute;n del pan es menos agotador y m&aacute;s pr&aacute;ctico. Mejorando la t&eacute;cnica que evita el cansancio del proceso manual y reduce el tiempo de ejecuci&oacute;n.</p>
', '2020-02-26', 'dicyt_2020_02_26_22_08_37.docx', 'UNIV. CIPRIAN JANCO QUISPE', '2019', '0', 'NO DISPONIBLE', 'Descriptiva, Exploratorio');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('50', '13', '35', 'EFECTOS EN LOS ESTADOS FINANCIEROS DEL FONDO COMUNITARIO DE SALUD – TUPIZA, POR ERRORES EN LOS REGISTROS CONTABLES', '1', '2',  E'<p>El objetivo de la investigaci&oacute;n es reducir a lo m&iacute;nimo los errores involuntarios en registros contables explorando reglas y m&eacute;todos, para que los mismos sean expuestos con saldos reales en los Estados Financieros del Fondo Comunitario de Salud Tupiza por 5 gestiones terminadas.</p>\\r\\n',  E'<p>El presente trabajo se realizo con el fin de saber los efectos en los Estados Financieros del Fondo Comunitario de Salud Tupiza&nbsp; por errores en los registros contables de la instituci&oacute;n, por el cual se verifico que existe deficiencias, ya que solo cuenta con trabajador de profesi&oacute;n Contador que realiza la labor de Administrador y otras funciones que no le competen dentro de la escala del manual de funciones ya que tambi&eacute;n&nbsp; el registro de las entradas y salidas&nbsp; existen volteos de cifras considerables en su mayor&iacute;a que llegaron a afectar los Estados de Resultados de cada gesti&oacute;n terminada del cual se modificada en el momento de la presentaci&oacute;n, por el cual se recomend&oacute; optar por un sistema contable confiable y eficaz para la realizaci&oacute;n de las operaciones.</p>\\r\\n\\r\\n<p>Para lo cual tener menos errores y afectando al rendimiento de la instituci&oacute;n en porcentajes m&iacute;nimos o menos significativos.</p>\\r\\n',  E'<p>De acuerdo a los resultados de la entrevista realizada a los Ingresos y Egresos del Fondo Comunitario de Salud. Conforme a los Sub Sistemas establecidos en la Ley N&deg; 1178; se concluye que los recursos manejados por el Administrador del Fondo Comunitario de Salud son las recaudaciones de los afiliados al seguro y es manejado de manera incorrecta, debido que el Administrador no realiza los Dep&oacute;sitos inmediatos, despu&eacute;s de lo recaudado en el d&iacute;a, aclarando que todo Egreso que realiza siempre va acompa&ntilde;ado por una Resoluci&oacute;n de Directorio para poder realizar el gasto aplicadas a Normas Contables.</p>\\r\\n\\r\\n<p>Los Recursos provenientes del Gobierno Aut&oacute;nomo Municipal de Tupiza por la prestaci&oacute;n de servicios a los afiliados de acuerdo a convenio son Administrado por la Red de Salud Y Hospital Eduardo Egu&iacute;a, debido a que el Municipio desembolsa directamente a la Administraci&oacute;n de Red de Salud y no as&iacute; al Fondo Comunitario de Salud Tupiza.</p>\\r\\n\\r\\n<p>Se concluye&nbsp; que el mismo es Ineficaz debido a que no cuenta con los Reglamentos Espec&iacute;ficos, conforme a los subsistemas establecidos en la Ley N&ordm; 1178 ni Manual de Funciones, As&iacute; mismo se ha podido determinar que existen errores por volteos de cifras en los registros contables en la preparaci&oacute;n de los estados financieros que llegan a solucionarlos a ese instante&nbsp; que hace dudar de la Integridad, propiedad y legalidad de los Recursos provenientes de los afiliados al Fondo Comunitario de Salud Tupiza.</p>\\r\\n', '2020-02-26', 'dicyt_2020_02_26_23_11_54.docx', 'UNIV. JHONNY EDGAR YAÑEZ MONTECINOS', '2019', '0', 'LIC. JOSE LUIS TAPIA LOZANO', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('51', '13', '35', 'FACTORES QUE INCIDEN EN EL RENDIMIENTO ACADéMICO DE ESTUDIANTES EN LA MATERIA DE CPA 430 ? MATEMáTICA FINANCIERA II, EN LA CARRERA DE AUDITORIA ? CONTADURíA PúBLICA DE LA UNIVERSIDAD AUTóNOMA ?TOMAS FRíAS? SEDE TUPIZA', '1', '2', '<p>Determinar los factores del bajo rendimiento acad&eacute;mico de los estudiantes de la asignatura CPA 430 &ndash; Matem&aacute;tica Financiera II, del cuarto semestre de la carrera de Auditoria &ndash; Contadur&iacute;a P&uacute;blica de la Universidad Aut&oacute;noma &ldquo;Tomas Fr&iacute;as&rdquo; sede Tupiza.</p>
', '<p>El impacto de las transformaciones sociales en el siglo XXI, caracterizadas por la evoluci&oacute;n de la &ldquo;sociedad industrial&rdquo; a una &ldquo;sociedad del conocimiento&rdquo; y los constantes cambios de aspectos econ&oacute;micos, pol&iacute;ticos, sociales y tecnol&oacute;gicos, han originado un enfoque diferente en la gesti&oacute;n de las organizaciones, que tienen ante s&iacute; retos y desaf&iacute;os importantes.</p>

<p>Ante este escenario, el reto de las universidades es fundamental. Para dar respuesta a estas nuevas demandas, las universidades se han convertido en el motor del crecimiento empresarial, tecnol&oacute;gico y econ&oacute;mico, esto es, en el elemento principal de la construcci&oacute;n y desarrollo de las sociedades.</p>

<p>Es por esta raz&oacute;n que la educaci&oacute;n superior surge ante los adolescentes como un medio fundamental para alcanzar sus metas de realizaci&oacute;n personal. Es por ello, que cada a&ntilde;o las universidades p&uacute;blicas y privadas de nuestro pa&iacute;s, cuentan con una gran cantidad de j&oacute;venes que buscan ingresar a ellas a trav&eacute;s de una plaza que les asegure la formaci&oacute;n profesional necesaria para desenvolverse en un &aacute;mbito con tales caracter&iacute;sticas.&nbsp;</p>

<p>Es as&iacute; que, en la ciudad de Tupiza, se tiene la carrera de Auditoria &ndash; Contadur&iacute;a P&uacute;blica, misma que es dependiente de la Universidad Aut&oacute;noma &ldquo;Tomas Fr&iacute;as&rdquo;, en donde la malla curricular establece la asignatura de CPA 430 - Matem&aacute;tica Financiera II, perteneciente al cuarto semestre del nivel de estudio, en la que los registros de calificaciones proporcionan informaci&oacute;n referente a la asignatura y la misma no es nada satisfactoria.</p>

<p>Muchos pueden ser los factores que influyen en el rendimiento de la materia en menci&oacute;n, sin embargo, la investigaci&oacute;n se focalizara a la incidencia de la metodolog&iacute;a y la evaluaci&oacute;n como referentes. En base a estos argumentos se pretende llevar a cabo un estudio exhaustivo con la finalidad de determinar si la metodolog&iacute;a y la evaluaci&oacute;n empleada son factores que inciden en el rendimiento de los estudiantes que han cursado la asignatura de CPA 430 &ndash; Matem&aacute;tica Financiera II.</p>
', '<p>Seg&uacute;n la hip&oacute;tesis del presente trabajo de investigaci&oacute;n donde literalmente indica que &ldquo;El bajo rendimiento de los estudiantes en la asignatura de CPA 430 &ndash; Matem&aacute;tica Financiera, de la carrera de Auditoria &ndash; Contadur&iacute;a P&uacute;blica de la Universidad Aut&oacute;noma &ldquo;Tomas Fr&iacute;as&rdquo; sede Tupiza, se asocia significativamente a las estrategias metodol&oacute;gicas empleadas por el docente de la asignatura&rdquo; y en base a las t&eacute;cnicas de la encuesta y la entrevista se pudo realizar la presente investigaci&oacute;n.</p>

<p>En consecuencia, se ha determinado que los factores significativos que inciden en el rendimiento acad&eacute;mico de los estudiantes que cursan o hayan cursado la asignatura de CPA 430 &ndash; Matem&aacute;tica Financiera, son las condiciones personales, la calidad en la educaci&oacute;n secundaria y la metodolog&iacute;a empleada por el docente de la materia, mismos que son corroborados a partir de las frecuencias estad&iacute;sticas que confirman la afirmaci&oacute;n demostradas en las gr&aacute;ficas correspondientes.</p>

<p>Con relaci&oacute;n a las condiciones personales se pudo advertir que solo un 13,43% de los estudiantes eligen la carrera de Auditoria &ndash; Contadur&iacute;a P&uacute;blica Sede Tupiza por vocaci&oacute;n, siendo el 86,57% que ingreso por otro motivo, por tal situaci&oacute;n se considera uno de los factores en el bajo rendimiento, debido al alto porcentaje de estudiantes que ingresan a continuar sus estudios superiores por una atribuci&oacute;n diferente al de la vocaci&oacute;n hacia la carrera, as&iacute; mismo se pudo evidenciar que el 58,21% los estudiantes poseen poco control o ning&uacute;n control por parte de sus padres o tutores, en relaci&oacute;n al seguimiento acad&eacute;mico de los mismos.</p>

<p>Con relaci&oacute;n a identificar las falencias y las debilidades que presenta la calidad de la educaci&oacute;n secundaria que tuvieron los estudiantes que cursan o cursaron la asignatura de CPA 430 &ndash; Matem&aacute;tica Financiera ll, de la carrera de Auditoria &ndash; Contadur&iacute;a P&uacute;blica de la Universidad Aut&oacute;noma &ldquo;Tomas Fr&iacute;as&rdquo; Sede Tupiza, se tiene la percepci&oacute;n de los mismos que el 46,27% fue excelente o buena y el&nbsp; restante 53,73% considera que fue regular o mala, siendo esto un factor importante debido a ser esta preparaci&oacute;n una base fundamental con la que el estudiante pueda afrontar sus estudios superiores.</p>

<p>Con relaci&oacute;n al factor de la metodolog&iacute;a empleada por el docente en el proceso de ense&ntilde;anza &ndash; aprendizaje, se pudo evidenciar seg&uacute;n las encuestas realizadas para la presente investigaci&oacute;n que, el 58,21% marcan como factor predominante para su rendimiento acad&eacute;mico a la calidad del docente, esto debido a las estrategias metodol&oacute;gicas empleadas en el desarrollo y avance de los temas en clase, el 22,39% a la motivaci&oacute;n personal, el 4,48% a los ingresos econ&oacute;micos, el 2.99% al apoyo por parte de los padres, el 10,45% la disponibilidad de tiempo, y el 1,49% otro motivo.</p>

<p>As&iacute; mismo se pudo observar que, el 20,90% de los estudiantes se&ntilde;alan que el docente si tiene vocaci&oacute;n en la ense&ntilde;anza de la asignatura CPA 430 &ndash; Matem&aacute;tica Financiera ll, el 22,39% se&ntilde;ala que a veces y el 56,72% se&ntilde;ala que no tiene vocaci&oacute;n por ense&ntilde;ar, se&ntilde;alando a que la clase se torna muy mon&oacute;tona y aburrida.</p>

<p>Tambi&eacute;n se pudo observar que, la facilidad para hacerse entender por parte del docente hac&iacute;a con los estudiantes es del 7,46% para s&iacute;, en cambio el 61,19% se&ntilde;ala que no existe facilidad al momento de hacerse entender y el 31,34% se&ntilde;ala que a veces.</p>

<p>Por otra parte, el 32,84% de los estudiantes se&ntilde;alan que no existe fluidez en la comunicaci&oacute;n del docente en clase debido a que el docente no crea una atmosfera de confianza hacia los estudiantes; el 55,22% dice que existe a veces y solamente el 11,94% se&ntilde;ala que si existe.</p>

<p>De la misma manera, el 34,33% de los estudiantes se&ntilde;alan que el docente, si tiene la motivaci&oacute;n para mantener el inter&eacute;s y la atenci&oacute;n en clase del estudiante, en cambio el 22,39% dice que a veces y 43,28% se&ntilde;ala que no lo tiene.</p>

<p>Por otro lado, se puede apreciar que la estimulaci&oacute;n por parte del docente a que los estudiantes participen en clase es del 7,46%, en cambio el 53,73% de los estudiantes se&ntilde;alan que a veces y el 38,81% dice que no, esto se debe a que muy rara vez la docente incentiva en el mejoramiento de la nota a cambio de resolver alg&uacute;n ejercicio y solo lo aplica si el estudiante lo resuelve correctamente.</p>

<p>Por &uacute;ltimo, se observa que el 47,76% de los estudiantes indica.</p>
', '2020-02-26', 'dicyt_2020_02_26_23_18_37.docx', 'UNIV. ELTON J. ALTAMIRANO', '2019', '0', 'LIC. DAYSI L. DELGADO CORO', 'Cualitativa');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('47', '2', '4', 'CONTRIBUIR A LA DETECCIÓN TEMPRANA DEL CÁNCER CÉRVICO UTERINO CON EL PAPANICOLAU EN MUJERES DE 25 A 54 AÑOS DE EDAD EN EL DISTRITO 14 SE LA CIUDAD DE POTOSÍ GESTIÓN 2019', '1', '2', '<p>Proponer un programa educativo para contribuir a la detecci&oacute;n temprana del c&aacute;ncer c&eacute;rvico uterino con el Papanicolau en mujeres de 25 a 54 a&ntilde;os de edad en el distrito 14 de la ciudad de Potos&iacute; gesti&oacute;n 2019.</p>
', '<p>El c&aacute;ncer c&eacute;rvico uterino constituye un problema de salud p&uacute;blica y salud reproductiva de la mujer a nivel mundial, que lleva a un enfermedad mortal y , representa un gran problema en salud p&uacute;blica por los problemas que conlleva, por tanto, se plantea el siguiente objetivo: Proponer un programa educativo para contribuir a la detecci&oacute;n temprana del c&aacute;ncer c&eacute;rvico uterino con el Papanicolau en mujeres de 25 a 54 a&ntilde;os de edad en el distrito 14 de la ciudad de Potos&iacute;.</p>

<p>El M&eacute;todo de estudio es no experimental con un enfoque cuali cuantitativo de tipo anal&iacute;tico transversal, prospectivo en una poblaci&oacute;n de 200 mujeres entre las edades de 25 a 54 a&ntilde;os del distrito 14 de la ciudad de Potos&iacute; Para la recogida de los&nbsp;&nbsp;&nbsp;&nbsp; datos se utiliz&oacute; un cuestionario.</p>

<p>Los resultados fueron: que las mujeres creen que no es importante la realizaci&oacute;n del examen del papanicolaou raz&oacute;n por la cual no lo realizan. Sabiendo que esta lleva a la mortalidad materna lo cual es importante sensibilizar a las mujeres del distrito 14 de la ciudad de Potos&iacute;, as&iacute; poder contribuir a la detecci&oacute;n temprana del c&aacute;ncer c&eacute;rvico uterino con el Papanicolau.</p>

<p>Entre las conclusiones m&aacute;s relevantes fueron: la causa por la cual no se realizan el examen de Papanicolaou es por falta de tiempo creen que no es importante el examen sin embargo si conocen cuales son solo requisitos de dicho examen, pero no lo realizan.</p>
', '<ul>
	<li>Se evidencia que el conocimiento sobre el examen del Papanicolau es escasa, obteniendo mayor porcentaje en que creen que no es importante y que no es priorizad para realizarse.</li>
	<li>La falta de responsabilidad hacia ellas mismas no prioriza realizar este examen por falta de tiempo sabiendo que requisitos deben cumplir antes de poder realizarlas.</li>
	<li>El poco conocimiento sobre esta enfermedad es una debilidad para las mujeres de este distrito.</li>
	<li>Todav&iacute;a existen mujeres que no se realizaron nunca este examen en el distrito 14 de la ciudad de Potos&iacute;.</li>
</ul>
', '2020-02-26', 'dicyt_2020_02_26_22_40_43.docx', 'UNIV. ANDREA QUISPE VENTURA', '2019', '1', 'LIC. ELIZABETH CANAVIRI', 'Prospectivo, Transversal, Analítico. ');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('49', '13', '35', 'EL  IMPACTO ECONOMICO Y SOCIAL DEL DESBORDE DEL RIO SAN JUAN DEL ORO  EN  LAS FAMILIAS DEL DISTRITO V DEL MUNICIPIO DE TUPIZA', '1', '2', '<p>Determinar los impactos socio-econ&oacute;mico en las familias afectadas en el Distrito V del Municipio de Tupiza, como consecuencia del desborde del Rio San Juan del Oro suscitados en la gesti&oacute;n 2018 en los meses (enero y diciembre).</p>
', '<p>El presente trabajo de investigaci&oacute;n contiene, dos cap&iacute;tulos que corresponde al impacto Econ&oacute;mico y Social a causa del desborde del Rio San Juan del Oro&nbsp; en&nbsp; las Familias del Distrito V del municipio de Tupiza, Suscitados en la gesti&oacute;n 2018 en los meses (enero y diciembre).</p>

<p>Como podemos ver en estos &uacute;ltimos a&ntilde;os&nbsp; hubo diferentes desastres naturales y&nbsp; uno de los principales fue la crecida del Rio San Juan del Oro, que ocasiono desastres y p&eacute;rdidas en la producci&oacute;n.</p>

<p>Esto&nbsp; promueve la migraci&oacute;n&nbsp; en las familias de las comunidades del distrito V, debido a que su ingreso principal proviene de la agricultura, mismas que quedaron arrasadas por las riadas de estos &uacute;ltimos a&ntilde;os.</p>

<p>Se ha logrado cuantificar los da&ntilde;os econ&oacute;micos y sociales mediante el estudio y evaluaci&oacute;n de las afectaciones, estimando las p&eacute;rdidas&nbsp; econ&oacute;micas en la producci&oacute;n agr&iacute;cola de las familias en el Distrito V, ya que es un tema muy importante q afecta a la poblaci&oacute;n, como tambi&eacute;n es importante tener conocimiento acerca de los da&ntilde;os que causa el desborde del rio san juan del oro.</p>

<p>As&iacute; tambi&eacute;n con los resultados obtenidos se podr&aacute; hacer conocer al&nbsp;&nbsp; Gobierno Aut&oacute;nomo Municipal y Gobierno Departamental, con el fin de obtener proyectos para la prevenci&oacute;n y recuperaci&oacute;n de sus tierras, de esta manera poder disminuir la migraci&oacute;n de las familias, separaci&oacute;n de familias y cambio de rubro o actividad.</p>
', '<p>Como resultado del trabajo de investigaci&oacute;n, se concluye que se cumpli&oacute; con el objetivo planeado, puesto que se pretend&iacute;a realizar un estudio para determinar los impactos socio-econ&oacute;micos de las afectaciones y p&eacute;rdidas de la producci&oacute;n en el Distrito V del Municipio de Tupiza, a consecuencia del desborde del Rio San Juan del Oro suscitados en la gesti&oacute;n 2018 en los meses (enero y diciembre).</p>

<p>Los da&ntilde;os y&nbsp; las p&eacute;rdidas&nbsp; econ&oacute;micas fueron en un 100% en la producci&oacute;n agr&iacute;cola en el Distrito V, causando un impacto econ&oacute;mico y social, ocasionando que las familias migren a diferentes lugares del interior y exterior del pa&iacute;s, por falta de ayuda de las autoridades municipales y departamentales.</p>

<p>El 80% de las familias en Distrito V del Municipio de Tupiza&nbsp; fueron afectadas a causa del desborde del Rio San Juan del Oro y el 45% de las familias migraron a diferentes lugares del interior y exterior del pa&iacute;s.</p>

<p>Al realizar este trabajo de investigaci&oacute;n se pudo advertir que es un tema muy amplio y sin duda de mucha importancia para las familias del distrito V, para&nbsp; poder ayudar con la implementaci&oacute;n de proyectos de apoyo para la prevenci&oacute;n y recuperaci&oacute;n de sus tierras, as&iacute; contribuir al desarrollo&nbsp; econ&oacute;mico y social de la regi&oacute;n.</p>

<p>As&iacute; tambi&eacute;n se pudo obtener &nbsp;datos estad&iacute;sticos de las afectaciones y p&eacute;rdidas de la producci&oacute;n, que servir&aacute; como apoyo y conocimiento para el sub alcalde&nbsp; del Distrito V y personal encargado del gobierno aut&oacute;nomo municipal de Tupiza.</p>

<p>En base a las encuestas realizadas se pudo percibir que las familias afectadas est&aacute;n dispuestas a poner su contraparte con mano de obra en el caso de que las autoridades&nbsp; propongan&nbsp; proyectos de prevenci&oacute;n para el desborde del Rio San Juan del Oro.</p>
', '2020-02-26', 'dicyt_2020_02_26_23_02_29.docx', 'UNIV. MARISOL SOLEDAD GUTIERREZ JAIME', '2019', '0', 'LIC. MARVEL CLAUDIO  ROMERO VELASQUEZ', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('34', '1', '2', 'OBTENCIÓN DE FOSFATO ACIDO DE AMONIO A PARTIR DE ROCA FOSFÓRICA DE BUEY-TAMBO (PAMPAS DE LEQUEZANA), POR EL PROCESO DE ACIDULACION Y POSTERIOR NEUTRALIZACIÓN CON AMONIACO PRUEBA', '1', '3', '<ul>
	<li>Obtener fosfato acido de amonio de calidad comercial a partir de roca fosf&oacute;rica de Buey-tambo (pampas del Lequezana), por acidulacion y neutralizaci&oacute;n con amoniaco.</li>
</ul>
', '<p>El fosforo es un elemento indispensable para el rendimiento de buenos cultivos, que es necesario la aplicaci&oacute;n de fertilizantes fosforados sean naturales o sint&eacute;tico. El presente trabajo de investigaci&oacute;n, estuvo dirigido a obtener fosfato acido de amonio a partir de la roca fosf&oacute;rica, muestra obtenida de la localidad de Buey-Tambo, provincia Cornelio Saavedra.</p>

<p>Se pudo determinar que a trav&eacute;s de an&aacute;lisis fisicoqu&iacute;mico existe una considerable cantidad de pentaoxido de fosforo en la roca fosf&oacute;rica con un valor de 23.77 %.</p>

<p>Para el proceso de obtenci&oacute;n de &aacute;cido fosf&oacute;rico por acidulacion, se aplicado el dise&ntilde;o experimental donde las variables influyentes son: temperatura, tiempo de agitaci&oacute;n y concentraci&oacute;n del &aacute;cido. Dando lugar a un mayor rendimiento. Y obteniendo un pH de 1-2.</p>

<p>A partir del &aacute;cido fosf&oacute;rico, por neutralizaci&oacute;n con amoniaco y cristalizaci&oacute;n se llega a obtener fosfato acido de amonio.</p>

<p>En la obtenci&oacute;n de fosfato acido de amonio la generaci&oacute;n de amoniaco gaseoso se realiza por un tiempo de 5 a 10 minutos a una temperatura menos a -5 0C y un tiempo de cristalizaci&oacute;n a temperatura ambiente 20 d&iacute;as.</p>
', '<p>El objetivo principal del presente trabajo de investigaci&oacute;n es la obtenci&oacute;n de fosfato acido de amonio a partir de la roca fosf&oacute;rica de Buey Tambo provincia Cornelio Saavedra del departamento de Potos&iacute; para la utilizaci&oacute;n como reactivo y a la vez pueda resultar una alternativa econ&oacute;mica. La informaci&oacute;n empleada para este estudio es resultado de an&aacute;lisis qu&iacute;micos tanto de la materia prima como del producto, tambi&eacute;n de una revisi&oacute;n bibliogr&aacute;fica que ayudan a obtener buenos resultados y a la vez compararlos.</p>

<ul>
	<li>De acuerdo a las caracter&iacute;sticas qu&iacute;mica de la roca fosf&oacute;rica de Buey Tambo se ha podido observa que se puede obtener fosfato acido de amonio empleando tratamientos adecuados en la materia prima.</li>
	<li>En la realizaci&oacute;n del an&aacute;lisis qu&iacute;mico del fosforo se ha utilizado el m&eacute;todo colorim&eacute;trico del amarillo molibdovanadato por presentar mayor precisi&oacute;n y un rango menor de interferencia.</li>
	<li>En el an&aacute;lisis qu&iacute;mico de nitr&oacute;geno en el producto obtenido fosfato acido de amonio se utiliz&oacute; el procedimiento de an&aacute;lisis del ion amonio por colorimetr&iacute;a, el cual consiste en agregar hidr&oacute;xido de sodio y reactivos Nessler.</li>
	<li>El contenido de P2O5 existente en la materia prima es de 23.77 %.</li>
	<li>La materia prima (roca fosf&oacute;rica) de Buey Tambo contiene minerales de fluorapatita y cuarzo principalmente</li>
	<li>En la obtenci&oacute;n de &aacute;cido fosf&oacute;rico se determina que las mejores condiciones son a una temperatura de 80&ordm;C con un tiempo de agitaci&oacute;n de 30 minutos y una concentraci&oacute;n de &aacute;cido sulf&uacute;rico de 0.5 N. obteniendo un porcentaje de pureza de 73.46 %.</li>
	<li>Se obtuvo fosfato acido de amonio con un porcentaje de rendimiento de 25.10%.</li>
	<li>La obtenci&oacute;n del fosfato acido de amonio se ha efectuado mediante la reacci&oacute;n entre el &aacute;cido fosf&oacute;rico (obtenido a partir de la roca fosf&oacute;rica) y amoniaco generado a partir del hidr&oacute;xido de amonio.</li>
</ul>
', '2019-11-08', 'dicyt_2019_11_08_20_54_46.docx', 'LIC. GUSTAVO NILO MERCADO', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('48', '2', '4', 'PROPONER UNA ESTRATEGIA EDUCATIVA PARA FORTALECER LOS CONOCIMIENTOS  SOBRE MÉTODOS ANTICONCEPTIVOS EN ESTUDIANTES DE LA CARRERA DE ENFERMERÍA, EN LOS NIVELES DE 1RO Y 2DO DE LA UNIVERSIDAD  TOMÁS FRÍAS EN LA GESTIÓN 2019', '1', '2',  E'<p>Dise&ntilde;ar una estrategia educativa para fortalecer los conocimientos&nbsp; sobre &nbsp;m&eacute;todos anticonceptivos, en estudiantes de la carrera de Enfermer&iacute;a en los niveles 1ro y 2do a&ntilde;o de la Universidad Tom&aacute;s Fr&iacute;as&nbsp; de la ciudad de Potos&iacute; en la gesti&oacute;n 2019.</p>\\r\\n',  E'<p>Son los m&eacute;todos o procedimientos que previenen un embarazo en mujeres sexualmente activas conlleva a un embarazo no deseado , por tanto, se plante&oacute; el siguiente objetivo: Dise&ntilde;ar una estrategia educativa para fortalecer los conocimientos&nbsp; sobre&nbsp; m&eacute;todos anticonceptivos, en estudiantes de la carrera de Enfermer&iacute;a en los niveles 1ro y 2do a&ntilde;o de la Universidad Tom&aacute;s Fr&iacute;as&nbsp; de la ciudad de Potos&iacute; en la gesti&oacute;n 2019.&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\\r\\n\\r\\n<p>El M&eacute;todo de estudio es no experimental con un enfoque cuali cuantitativo de tipo anal&iacute;tico transversal, prospectivo en una poblaci&oacute;n de 200 estudiantes mujeres y varones de los niveles de primero y segundo de la carrera de enfermer&iacute;a .Para la recogida de los&nbsp;&nbsp;&nbsp;&nbsp; datos se utiliz&oacute; un cuestionario.</p>\\r\\n\\r\\n<p>Los resultados fueron: que los estudiantes creen que si es importante el uso de m&eacute;todos anticonceptivos, sensibilizar a los estudiantes de la carrera de enfermer&iacute;a la ciudad de Potos&iacute; as&iacute; poder buscar una estrategia y&nbsp; fortalecer los conocimientos sobre m&eacute;todos anticonceptivos.</p>\\r\\n\\r\\n<p>Entre las conclusiones m&aacute;s relevantes fueron: la conciencia sobre la utilizaci&oacute;n de alg&uacute;n m&eacute;todo por la cual en su mayor&iacute;a si lo har&iacute;a con el cond&oacute;n l&aacute;tex sin embargo no saben las consecuencias posteriores o la efectividad sobre ese m&eacute;todo.</p>\\r\\n',  E'<ul>\\r\\n	<li>Se evidencia que el conocimiento sobre los m&eacute;todos anticonceptivos es regularmente satisfecha obteniendo un porcentaje mayor en este presente trabajo.</li>\\r\\n</ul>\\r\\n\\r\\n<ul>\\r\\n	<li>La informaci&oacute;n sobre este tema la reciben m&aacute;s del internet como fuente de informaci&oacute;n.</li>\\r\\n</ul>\\r\\n\\r\\n<ul>\\r\\n	<li>Los estudiantes de la carrera de enfermer&iacute;a si tienen conocimiento sobre este tema y respondieron que podr&iacute;an utilizar el m&eacute;todo del cond&oacute;n l&aacute;tex en su vida sexual.</li>\\r\\n</ul>\\r\\n\\r\\n<ul>\\r\\n	<li>Todav&iacute;a existen alumnos que no dan importancia sobre este tema la propuesta a realizar es para fortalecer la informaci&oacute;n sobre este tema.</li>\\r\\n</ul>\\r\\n', '2020-02-26', 'dicyt_2020_02_26_22_51_13.docx', 'UNIV. ENRRIQUE MORALES FRANCES', '2019', '1', 'LIC. ELIZABETH CANAVIRI', 'Prospectivo, Transversal, Analítico.-');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('33', '1', '1', 'CONSTRUCCIÓN DE CERRADURAS  ELECTRÓNICAS UTILIZANDO LA TECNOLOGÍA DIGITACIÓN POR TECLADO Y PROGRAMACIÓN ASOCIADA EN LA CIUDAD  DE POTOSÍ PRUEBA', '1', '3', '<p>Construir un sistema de &ldquo;Cerradura Electr&oacute;nica&rdquo;, utilizando el PIC16F877A con el cual, pueda realizarse cerradura autom&aacute;tica, con el fin de obtener seguridad m&aacute;xima, en un tiempo m&iacute;nimo posible que la de forma tradicional.</p>
', '<p>Ser claro y breve no deber&iacute;a ser dif&iacute;cil para explicar c&oacute;mo prevenir b&aacute;sicamente la vida, la libertad, el honor y la propiedad de los habitantes en cualquier latitud de la tierra. La seguridad, en sentido estricto y pr&aacute;ctico, es la posibilidad de evitar lo inesperado o, lo que es lo mismo evitar las sorpresas, la incertidumbre.</p>

<p>Siempre estar&aacute; atada al objetivo o al inter&eacute;s que se quiere proteger. No debe ni puede cambiar sino excepcionalmente por la actitud o actividad del enemigo, ni por temor al rid&iacute;culo e, incluso, a despecho de &eacute;l.</p>

<p>La seguridad f&iacute;sica abarca todas&nbsp; las medidas para prevenir el acceso a instalaciones protegidas.</p>

<p>Para ello, desde la antiguo, el hombre instalo barreras: obst&aacute;culos colocados entre el objeto y el intruso; donde las barreras pueden ser: Naturales, Estructurales, Humanos, El&eacute;ctricas y&nbsp; Electr&oacute;nicas.</p>

<p>Sabemos que la seguridad es muy importante en todo el mundo, en Bolivia y en nuestra ciudad de Potos&iacute;.</p>

<p>Por tal motivo la idea de este proyecto es implementar sistemas de seguridad en mayor cantidad posible construyendo cerraduras electr&oacute;nicas aqu&iacute; en Potos&iacute; con el objetivo de&nbsp; disminuir la inseguridad de las instalaciones protegidas.</p>

<p>El proyecto tiene como objetivo general, es generar tecnolog&iacute;a de punta en sistemas de seguridad en la Ciudad de Potos&iacute; y como objetivos espec&iacute;ficos es de fomentar la utilizaci&oacute;n y comercializaci&oacute;n de este producto, promover el uso del producto en totalidad de la cuidad.</p>

<p>Sobre la base de un programa especial de investigaciones y presentaciones por mi persona, el proyecto beneficiara a toda la poblaci&oacute;n de la Ciudad de Potos&iacute; tambi&eacute;n al resto del pa&iacute;s, en especial a los que tienen facilidad de adquisici&oacute;n de este producto.</p>

<p>El Proyecto ser&aacute; rentable porque contara con un Valor Actual Neto y tendr&aacute; una relaci&oacute;n Beneficio &ndash; Costo. Por lo tanto, se recomienda buscar financiamiento para su respectiva implementaci&oacute;n.</p>
', '<p>El proyecto propuesto en este perfil pretende impulsar la fabricaci&oacute;n de cerraduras electr&oacute;nicas en Potos&iacute;&nbsp; mediante un conjunto de acciones de promoci&oacute;n,&nbsp; cursos de actualizaci&oacute;n e inversi&oacute;n.</p>

<p>La meta,&nbsp; del proyecto es de llegar en 10 a&ntilde;os&nbsp; a una fabricaci&oacute;n mayor de cerraduras electr&oacute;nicas&nbsp; que produce en la actualidad, estableciendo la base de difusi&oacute;n y crecimiento en los a&ntilde;os posteriores.</p>

<p>El proyecto tiene la gran ventaja de contar con proveedores de componentes en todo el tiempo del proyecto.</p>

<p>La seguridad en la actualidad es un tema importante, por lo que se dise&ntilde;an cada d&iacute;a mejores equipos como el presentado en este proyecto, donde el acceso a oficinas, casas, almacenes, etc. es primordial.</p>

<p>Este equipo est&aacute; enfocado en el campo de accesos de seguridad, consta como elementos fundamentales del LCD 2x16 caracteres y un teclado matricial. El teclado nos ayuda a manipular los datos que ingresamos, mientras que con la pantalla LCD visualizamos la informaci&oacute;n que se requiere y que ingresa por el teclado.</p>

<p>El equipo para la protecci&oacute;n cuenta con fusible, que lo protege contra sobre voltajes.</p>

<p>En la construcci&oacute;n de un equipo se deben tomar en cuenta muchos factores, como forma f&iacute;sica, interconexi&oacute;n de los distintos elementos, disposici&oacute;n de los elementos, para poder culminar con &eacute;xito un proyecto.</p>

<p>El equipo est&aacute; dentro de una caja pl&aacute;stica que lo protege de las inclemencias del clima y protege los elementos electr&oacute;nicos.</p>

<p>El proyecto ser&aacute; rentable porque contara con un Valor Actual Neto y tendr&aacute; una relaci&oacute;n Beneficio &ndash; Costo. Por lo tanto, se recomienda&nbsp; buscar financiamiento para su respectiva implementaci&oacute;n.</p>
', '2019-11-08', 'dicyt_2019_11_08_20_50_50.docx', 'LIC. DELFíN MENCHACA YUCRA', '2018', '1', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('43', '18', '44', 'DISEÑO Y CONSTRUCCIÓN DE UN BRAZO NEUMÁTICO PARA MANIPULAR MINERAL EN LAS EMPRESAS MINERAS DE POTOSÍ', '1', '2', '<p>Realizar un brazo rob&oacute;tico neum&aacute;tico para manipular y al mismo tiempo pesar mineral en las empresas mineras de Potos&iacute;.</p>
', '<p>El presente trabajo investigativo es de dise&ntilde;ar y construir un de brazo neum&aacute;tico para manipular minerales en las Empresas Mineras de Potos&iacute;, con su finalidad de manipular minerales r&aacute;pidamente e incrementar su producci&oacute;n en la misma. &nbsp;Las Empresas Mineras, no cuentan con maquinarias neum&aacute;ticas, dispositivos de mando y control de los actuadores, lo cual genera retraso en tiempos de entrega e incrementa los costos de producci&oacute;n.</p>

<p>Usando las herramientas adecuadas como la observaci&oacute;n se obtuvo resultados favorables que posteriormente se encaus&oacute; hacia un an&aacute;lisis t&eacute;cnico de la mejor propuesta para la culminaci&oacute;n de los objetivos que se plateo al inicio del proyecto.</p>

<p>Llegando a la conclusi&oacute;n que la implementaci&oacute;n de un brazo neum&aacute;tico incrementara el desarrollo y producci&oacute;n en las Empresas Mineras de Potos&iacute;.</p>
', '<ul>
	<li>Los elementos dise&ntilde;ados se caracterizan por su amplio factor de seguridad por lo tanto no fallaran si se ocupan con los par&aacute;metros con los cuales fueron dise&ntilde;ados.</li>
	<li>Por medio del estudio se concluy&oacute; que para facilitar los procesos de neum&aacute;tica es importante contar con un mecanismo que sea did&aacute;ctico y preste las condiciones de maniobrabilidad y funcionalidad adecuadas.</li>
	<li>Por medio de la investigaci&oacute;n realizada se determin&oacute; que para el control Neum&aacute;tico de los cilindros es necesario utilizar v&aacute;lvulas manuales 4/3 ya que son las recomendadas para el control de cilindros Neum&aacute;ticos de doble efecto.</li>
</ul>
', '2020-02-26', 'dicyt_2020_02_26_21_50_13.docx', 'UNIV. LUIS BENJAMíN ROMANO SIÑANI', '2019', '0', 'NO DISPONIBLE', 'cualitativo');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('42', '2', '4', 'CAUSAS QUE INFLUYEN EN EL BULLYING EN ESTUDIANTES DE SECUNDARIA EN LA UNIDAD EDUCATIVA MANUEL ASCENCIO PADILLA DE LA CIUDAD DE POTOSÍ GESTIÓN 2019', '1', '2', '<p>Determinar las causas&nbsp; que influyen en el acoso escolar bullying en estudiantes de secundaria en unidad educativa &ldquo;Manuel Asencio Padilla&rdquo; de la ciudad de Potos&iacute; gesti&oacute;n 2019.</p>
', '<p>En el presente proyecto se trat&oacute; un tema muy importante sobre las causas del bullying en el cual se indagara en los estudiantes de secundaria.</p>

<p>Teniendo en cuenta que el bullying tiene muchas causas para que se practique en los estudiantes la mayor causa son problemas familiares. Ya sea del padre, madre, hermanos o t&iacute;os que son causantes para que el joven o se&ntilde;orita sea agresivo con los dem&aacute;s, la persona lo disfruta haciendo da&ntilde;o a los dem&aacute;s o saca ah&iacute; el da&ntilde;o que a esa persona se le realiza. Podemos decir tambi&eacute;n que en los colegios los profesores no se familiarizan con los estudiantes para darse cuenta de lo que pasa en el colegio y algunas veces obviando lo que se ve.</p>

<p>Por lo cual se plante&oacute; el siguiente problema &iquest;Cu&aacute;les son las causas que influyen en el &ldquo;bullying&rdquo; en estudiantes de secundaria en la unidad educativa &ldquo;Manuel Asencio Padilla &ldquo;de la ciudad de Potos&iacute; gesti&oacute;n 2019?; cuyo objetivo fue Determinar las causas que influyen en el acoso escolar bullying en estudiantes de secundaria en unidad educativa &ldquo;Manuel Asencio Padilla&rdquo; de la ciudad de Potos&iacute; gesti&oacute;n 2019.&nbsp;</p>

<p>Vimos la mejor forma de orientar a profesores, estudiantes y padres de familia el riesgo que significa el bullying en j&oacute;venes. La importancia de estar al tanto de sus hijos y no vivir en un ambiente de peleas todo el tiempo que da&ntilde;an a los hijos, los profesores que se familiaricen m&aacute;s con los estudiantes conociendo lo b&aacute;sico de sus vidas y vean las reacciones que cada uno presenta.</p>

<p>En definitiva se pudo evidenciar que los j&oacute;venes necesitan que se les escuche y vean paz en su entorno tanto para el agresor como para el agredido ya que ambos corren mucho riesgo en su vivir.</p>
', '<p>Con el presente trabajo llegamos a la conclusi&oacute;n que el bullying existe en el colegio Manuel Ascencio Padilla.</p>

<p>Del mismo modo resaltamos la importancia de realizar una medida de prevenci&oacute;n oportuna y pertinente de las situaciones de bullying, por ser algo preventivo se podr&aacute; disminuir los casos de bullying</p>

<p>Pues con esto se llega que:</p>

<ul>
	<li>Una de las causas principales del bullying es problemas familiares por lo cual los estudiantes con violencia familiar tienden a desquitar ese resentimiento con sus compa&ntilde;eros.</li>
	<li>Los profesores no est&aacute;n enterados lo que sucede por la falta de confianza que existe entre estudiante &ndash; profesor.</li>
</ul>

<p>La estrategia educativa podr&aacute; servir de mucho en el colegio porque ayudara a entender que el bullying no es algo que se debe dejar pasar y la confianza que debe existir entre profesor, estudiante y a la vez con su familia.</p>
', '2020-02-26', 'dicyt_2020_02_26_21_37_42.docx', 'UNIV. JENNY CONSUELO PACO CAYO', '2019', '1', 'LIC. MARGARITA ROSSEL MORENO  -  LIC. ELIZABETH CANAVIRI', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('24', '1', '24', 'ESTUDIO DEMOGRAFICO DE LA INCIDENCIA DE LA MIGRACION  (CAMPO-CIUDAD) EN EL COMERCIO INFORMAL EN EL MERCADO  CHUQUIMIA DE LA CIUDAD DE POTOSI', '1', '2', '<p>Determinar la incidencia de la migraci&oacute;n (campo-cuidad) en el comercio informal en el mercado Chuquimia de la ciudad de Potos&iacute; a trav&eacute;s de la demograf&iacute;a.</p>
', '<p>La demograf&iacute;a es la ciencia que estudia a la poblaci&oacute;n humana que se ocupa de la dimensi&oacute;n, estructura, caracteres generales, considerados principalmente desde el punto de vista cuantitativo estos cambios que pueden ser identificados como la densidad de la poblaci&oacute;n, crecimiento y decrecimiento, es decir la din&aacute;mica estructura a las poblaciones humanas.</p>

<p>La edad y el sexo son las caracter&iacute;sticas b&aacute;sicas de una poblaci&oacute;n, y la composici&oacute;n de la poblaci&oacute;n seg&uacute;n estas tiene importantes repercusiones sobre los fen&oacute;menos demogr&aacute;ficos y socioecon&oacute;micos. En general, cuando un dem&oacute;grafo se refiere expresamente a la estructura de la poblaci&oacute;n, alude a la composici&oacute;n por edad de la&nbsp; estructura de la poblaci&oacute;n los dem&oacute;grafos usualmente recogen informaci&oacute;n del pasado eval&uacute;an el presente y hacen predicciones sobre el futuro y tiene gran importancia para los an&aacute;lisis demogr&aacute;ficos. En el presente trabajo se puedo distinguir las edades m&aacute;ximas que son entre los 16 y 64 a&ntilde;os de las personas que son objeto de estudio. La edad media es de 35.3 mediante pir&aacute;mides demogr&aacute;ficas se pudo comprobar que las mujeres m&aacute;s que los hombres se dedican al comercio informal en la cuidad de Potos&iacute;, cuyas edades est&aacute;n comprendidas entre 25 a 29 a&ntilde;os. La raz&oacute;n de la migraci&oacute;n campo ciudad fundamentalmente es por la oportunidad de trabajo que hay en la cuidad aspecto que no est&aacute;n cierto, por falta de trabajo esas personas se dedicaron al comercio informal porque no cuentan con otro fuente de ingresos.</p>

<p>Los resultados obtenidos fueron a trav&eacute;s del software, EXCEL, SPSS, para el procesamiento y an&aacute;lisis del presente trabajo de investigaci&oacute;n que los mismos fueron satisfechos en funci&oacute;n a las pir&aacute;mides demogr&aacute;ficas que sirvi&oacute; para tomar decisiones.</p>
', '<p>NO DISPONIBLE</p>
', '2019-11-04', 'dicyt_2019_11_04_10_46_25.docx', 'UNIV. NORMA TATIANA BRAVO MARTíNEZ', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('23', '13', '34', 'AUDITORIA OPERATIVA QUE PERMITA OPTIMIZAR LA ACTIVIDAD DE LA EMPRESA TURISTICA HIDALGO ', '1', '2', '<p>El <strong>objetivo general</strong> Propuso un sistema de auditoria operativa administrativa que permita optimizar la actividad de la empresa tur&iacute;stica Hidalgo tours en el departamento de potos&iacute;.</p>

<p>La aplicaci&oacute;n de la auditoria operativa tiene por objetivo, de evaluar la eficiencia de sus resultados, con referencia a las metas fijadas, los recursos humanos y materiales empleados, la organizaci&oacute;n, la utilizaci&oacute;n as&iacute; mismo coordinaci&oacute;n de dichos recursos y los controles establecidos sobre dicha gesti&oacute;n, cuyo objetivo es emitir una opini&oacute;n acerca de la razonabilidad del funcionamiento de los sistemas operativos e informaci&oacute;n del ente, identificando los errores que dichos sistemas puedan tener, corregirlos logrando as&iacute; una mayor eficacia y eficiencia de la gesti&oacute;n de la organizaci&oacute;n, con el prop&oacute;sito de evaluar e informar sobre la utilizaci&oacute;n de manera econ&oacute;mica y eficiente de sus recursos as&iacute; para el logro de sus objetivos.</p>
', '<p>El presente trabajo de Investigaci&oacute;n titulado, <strong>&ldquo;&ldquo;Auditoria operativa que permita optimizar la actividad de&nbsp; la empresa tur&iacute;stica hidalgo &ndash; tours en el departamento de potos&iacute;&rdquo;</strong></p>

<p>Ha sido elaborado con la finalidad de dise&ntilde;ar un plan de auditor&iacute;a operativa con el prop&oacute;sito de evaluar los procesos de &nbsp;desempe&ntilde;o&nbsp; de la agencia de turismo Hidalgo &ndash; Tours.</p>

<p>Debido a que, no existe un adecuado Sistema de Archivamiento de Documentos, desorden en el manejo de comprobantes de los ingresos y gastos como facturas, boletas, la mayor&iacute;a de estos presentan borrones, enmendaduras, algunos son escritos a mano con letra ilegible adem&aacute;s de un inadecuado tramite documentario, es por ello, que es necesario dise&ntilde;ar un Plan de Auditor&iacute;a Operativa con la finalidad de evaluar los procesos tanto como el desempe&ntilde;o de la Instituci&oacute;n.</p>

<p>En la <strong><em>fase de planificaci&oacute;n </em></strong>encontramos la orden de trabajo, la notificaci&oacute;n de inicio de auditor&iacute;a, la visita previa, la planificaci&oacute;n espec&iacute;fica, el programa de auditor&iacute;a y los esquemas de los cuestionarios de auditor&iacute;a. Esta fase es el pilar fundamental para el desarrollo de todas las actividades sistem&aacute;ticas programadas con tiempos y objetivos a&nbsp; alcanzarse como producto final de la auditor&iacute;a.</p>

<p>Esto servir&aacute; para evaluar el proceso y encontrar la evidencia suficiente y relevante que permita dar una opini&oacute;n, conclusiones y recomendaciones acertadas en las fases siguientes.</p>

<p>La <strong>s<em>egunda fase que es la de ejecuci&oacute;n </em></strong>se demuestra la aplicaci&oacute;n del programa de auditor&iacute;a planteado, de cuestionarios de control interno, y de indicadores de gesti&oacute;n a utilizarse, que permitan generar los papeles de trabajo del auditor para determinar hallazgos, y documentarlos en las cedulas narrativas con sus cuatro atributos que son: criterio, condici&oacute;n, causa y efecto, que encajen como soporte a pasar a la siguiente fase. Adem&aacute;s se describe las marcas de referencia utilizadas en los papeles de trabajo y documentos del auditor.</p>

<p>En la <strong><em>&uacute;ltima fase </em></strong>que es la <strong><em>presentaci&oacute;n del informe </em></strong>se divide en tres cap&iacute;tulos; en <em>el primero </em>se relata una informaci&oacute;n <em>introductoria de la agencia de viajes Hidalgo Tours</em>, como extracto de la visita previa e informaci&oacute;n general del mismo, en <em>el segundo </em>se resume las c&eacute;dulas narrativas con sus respectivos hallazgos y la evidencia suficiente, y los resultados del examen.</p>

<p>Se formulan comentarios, conclusiones y recomendaciones que beneficiaran al mejoramiento constante de la empresa que ha sido auditada, las mismas que se respaldar&aacute;n en la evidencia argumentada en los papeles de trabajo y que quedar&aacute;n a disposici&oacute;n de la administraci&oacute;n de la empresa.</p>
', '<p><strong>En el presente trabajo de investigaci&oacute;n ha llegado a las siguientes conclusiones.</strong></p>

<ol>
	<li>Conclusi&oacute;n de la auditoria sobre los aspectos positivos de la gesti&oacute;n gerencial -&nbsp; operativa y sus resultados, as&iacute; como los principios, normas y metodolog&iacute;as, a pesar de que el nivel de confianza se alto, se debe considerar las variaciones para mejorar el compromiso empresarial de todo el personal.</li>
	<li>Los hallazgos en la presente auditoria, tienen un impacto m&iacute;nimo, ya que el riesgo detectado en todo el an&aacute;lisis, es bajo a excepci&oacute;n de los conocimientos b&aacute;sicos del personal operativos de la agencia tur&iacute;stica que se hall&oacute; un riesgo moderado. Los directivos del hotel tienen algunos tipos de motivaci&oacute;n hacia el personal y por ende alcanzar la eficiencia, eficacia y calidad de su desempe&ntilde;o hacia el alcance de metas como parte din&aacute;mica de la empresa.</li>
	<li>Conclusi&oacute;n sobre el efecto econ&oacute;mico y social producido por los perjuicios y da&ntilde;os y da&ntilde;os materiales ocasionados , tambi&eacute;n por las ineficiencias, practicas antiecon&oacute;micas, incumplimientos y deficiencias&nbsp; en general , y las causa y condiciones que incidieron en el incumplimiento.</li>
</ol>
', '2019-11-04', 'dicyt_2019_11_04_10_59_39.pdf', 'UNIV. NOELIA VANEZA MAYTA MOLINA', '2018', '0', 'NO DISPONIBLE', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('16', '1', '2', 'OBTENCIÓN DEL CLORURO DE POTASIO POR EL MÉTODO DE FLOTACION A PARTIR DE LA SALMUERADEL SALAR DE UYUNI-POTOSI', '1', '2', '<p>Obtener cloruro de potasio por el m&eacute;todo de flotaci&oacute;n, utilizando recursos naturales, del Salar de Uyuni ubicado en el departamento de Potos</p>
', '<p>El salar de Uyuni perteneciente al departamento de Potos&iacute;, cuenta con grandes riquezas de recursos no renovables, donde contiene elevadas cantidades de iones litio y potasio al cual se puede dar valor agregado para tener beneficio socioecon&oacute;mico para la regi&oacute;n.</p>

<p>El presente trabajo de investigaci&oacute;n es uno de los m&eacute;todos para la obtenci&oacute;n de cloruro de potasio por el proceso de flotaci&oacute;n, se aplic&oacute; el dise&ntilde;o de plackett-Bruman en donde se identific&oacute; claramente los factores de mayor influencia,se tom&oacute; en cuenta las siguientes variables: % s&oacute;lidos. Granulometr&iacute;a, velocidad de agitaci&oacute;n, dosificaci&oacute;n del reactivo y tiempo de acondicionamiento.</p>

<p>En esta investigaci&oacute;n se tuvieron resultados &oacute;ptimos, donde se obtuvo cloruro de potasio con una pureza de 97.02%y un rendimiento 60.97%.</p>
', '<p>Las conclusiones a las que se llego en el presente trabajo&nbsp; de investigaci&oacute;n&nbsp; despu&eacute;s de analizar e interpretar cada uno de los resultados.</p>

<p>Se llego a obtener cloruro de potaci&oacute;n por el m&eacute;todo de flotaci&oacute;n partiendo as&iacute;&nbsp; de la salmuera natural donde se tenia un alto contenido de cloruro de sodio con un 85.70(g/L) pero en la primera cristalizaci&oacute;n,&nbsp; solo se cristalizo cloruro de sodio y as&iacute; en una segunda ya se pudo cristalizar la silvinita un poco mas pura. As&iacute; teniendo como punto de partida la sal de silvinita con un contenido de&nbsp; 287.37 (g/kg) de potasio teniendo as&iacute; un aumento muy significativo &nbsp;en la concentraci&oacute;n del ion potasio el cual es 975.42 (g/kg) despu&eacute;s de la flotaci&oacute;n.</p>

<p>En el an&aacute;lisis f&iacute;sico- qu&iacute;mico de los componentes principales en&nbsp; la salmuera se fue verificando en cada una de ellas la recuperaci&oacute;n&nbsp; y el porcentaje de&nbsp; pureza que se obtuvo de acuerdo a las variables</p>

<p>Los resultados estad&iacute;sticos muestran que la prueba &quot;3&quot; es la m&aacute;s &oacute;ptima en el dise&ntilde;o aplicado para esta investigaci&oacute;n, donde presenta un porcentaje&nbsp; de recuperaci&oacute;n del 60.97 y un 97.02 de pureza. De acuerdo al an&aacute;lisis estad&iacute;stico las variables enesta &nbsp;prueba tienen mucha influencia en el proceso de flotaci&oacute;n los cuales son los siguientes porcentaje de s&oacute;lidos es de 35%, la granulometr&iacute;a es de 150&nbsp; Tyler&nbsp; y la velocidad de agitaci&oacute;n es de 600rpm.</p>

<p>La adici&oacute;n del colector que se utilizo en el proceso jugo un papel muy importante ya que contribuye de gran manera a la parte de la qu&iacute;mica ya que &nbsp;genero con facilidad la separaci&oacute;n de los iones sodio y potasio&nbsp; de la muestra de silvinita adem&aacute;s cabe resaltar que dicho reactivo tiene la propiedad de volver una hidrofobicas y adem&aacute;s trabajar como espumante en dicho proceso.</p>

<p>Los resultados que muestra en el m&eacute;todo que se aplico en esta investigaci&oacute;n&nbsp;&nbsp; se puede decir que es ventajoso ya que se tiene una buena recuperaci&oacute;n en la obtenci&oacute;n de cloruro de potasio, la aplicaci&oacute;n del reactivo&nbsp; no es contaminante para el medio ambiente solo que el costo de dicho reactivo es un poco alto ya que se adquiri&oacute; el reactivo por que en la carrera de Qu&iacute;mica no exist&iacute;a el reactivo para hacer las pruebas que se requer&iacute;an; pero es el &uacute;nico que se usa en dicho proceso ya que no es necesario el uso del espumante o alg&uacute;n estabilizante &nbsp;por que este tiene esas funciones de trabajar como espumante y colector que en anteriores estudios se usaba colectores y espumantes para la obtenci&oacute;n del cloruro de potasio.</p>
', '2019-11-04', 'dicyt_2019_11_04_09_18_09.pdf', 'UNIV. ALICIA NORMA  CRUZ GUTIÉRREZ.', '2018', '0', 'LIC. ELENA GARCíA.', 'no disponible');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('2', '13', '35', 'ANALISIS ECONOMICO DEL SALARIO MINIMO NACIONAL, EN RELACION A LA SATISFACCION DE NECESIDADES DE LAS FAMILIAS DE TUPIZA DEL BARRIO  SAN ANTONIO EN LA GESTIÓN 2018', '1', '2', '<p>Determinar en qu&eacute; medida se satisfacen las Necesidades B&aacute;sicas de las familias de Tupiza el Salario M&iacute;nimo Nacional.</p>
', '<p>El trabajo de investigaci&oacute;n estar&aacute; direccionado a poder lograr realizar un an&aacute;lisis de la econom&iacute;a en Bolivia reflejada en la ciudad de Tupiza en el barrio de San Antonio, el mismo que de acuerdo a lo establecido el 1 de mayo de 2018 por el gobierno un m&iacute;nimo nacional de 2060 bolivianos y en relaci&oacute;n al art&iacute;culo 23 de los Derechos Humanos esa escala ser&iacute;a necesario para poder cubrir todas las necesidades de las familias de Tupiza.</p>

<p>As&iacute; mismo se realizara el estudio de investigaci&oacute;n en ocho familias diferentes dos parejas sin hijos pero la diferencia de una con la otra ser&aacute; que en un c&iacute;rculo familiar solo existir&aacute; un ingreso econ&oacute;mico y en el otro caso existir&aacute;n dos ingresos econ&oacute;micos, en dos familias con un hijo que al igual que el caso anterior por un lado existir&aacute; un solo ingreso econ&oacute;mico y por otro lado existir&aacute;n dos ingresos econ&oacute;micos, en dos familias con dos hijos que al igual que el caso anterior por un lado existir&aacute; un solo ingreso econ&oacute;mico y por otro lado existir&aacute;n dos ingresos econ&oacute;micos y en dos familias con tres hijos que al igual que el caso anterior por un lado existir&aacute; un solo ingreso econ&oacute;mico y por otro lado existir&aacute;n dos ingresos econ&oacute;micos.</p>

<p>Las encuestas aplicadas nos direccionaran a determinar cu&aacute;l son las necesidades familiares m&aacute;s indispensables para que despu&eacute;s de la recolecci&oacute;n de datos logremos realizar un an&aacute;lisis de todo lo expuesto en relaci&oacute;n al salario m&iacute;nimo nacional.</p>
', '<p>De acuerdo con el resultado obtenido se llega a las siguientes conclusiones:</p>

<ul>
	<li>La Familia es la estructuraci&oacute;n de la uni&oacute;n de dos culturas diferentes en funci&oacute;n de manifestar una nueva cultura, que prioriza como necesidades familiares la alimentaci&oacute;n, la salud y la educaci&oacute;n.</li>
	<li>Las necesidades b&aacute;sicas a manera espec&iacute;fica en las familias del barrio de San Antonio de la ciudad de Tupiza son los siguientes: Alimentaci&oacute;n, transporte; comunicaci&oacute;n, agua, luz, alquileres, educaci&oacute;n, salud, etc. Los costos m&aacute;s elevados en alimentaci&oacute;n son las tres comidas diarias con un gasto en el desayuno, almuerzo y la cena considerando que solo estos alimentos se los consume en casa.</li>
	<li>De acuerdo con lo establecido como salario m&iacute;nimo para la gesti&oacute;n 2018 consideramos que las necesidades familiares son basta y el salario m&iacute;nimo no abastece para cubrir las mismas.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_33_18.pdf', 'UNIV. MARCIA ROSA LUZ GARCíA VALDEZ', '2018', '0', 'LIC. AMADEO CONDOR', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('4', '18', '44', 'AUTOMATIZACIÓN DE SELLADORA PARA BOLSAS DE PAN', '1', '2', '<p>Desarrollar una maquina semiautom&aacute;tica de sellado que sea capaz de consumir menos tiempo y desperdiciar menos material que la maquina actual.</p>
',  E'<p>La Automatizaci&oacute;n es la aplicaci&oacute;n de diferentes tecnolog&iacute;as para controlar un proceso, maquina, aparato o dispositivo que por lo regular cumple funciones o tareas epetitivas,<br />
\\r\\nhaciendo que opere autom&aacute;ticamente, reduciendo al m&iacute;nimo la intervenci&oacute;n humana.</p>

<p>Lo que se busca con la Automatizaci&oacute;n es generar la mayor cantidad de producto, en el menor tiempo posible, con el fin de reducir los costos y garantizar una uniformidad en la calidad.</p>

<p>La Automatizaci&oacute;n es posible gracias a la uni&oacute;n de distintas tecnolog&iacute;as, por ejemplo la olehidraulica, la neum&aacute;tica, los servos y los motores son los encargados del movimiento, nos ayudan a realizar esfuerzos f&iacute;sicos (mover una bomba, prensar o desplazar un objeto), los sensores nos indican lo que est&aacute; sucediendo con el proceso, donde se encuentra en un momento determinado y dar la se&ntilde;al para que siga el siguiente paso, los sistemas de comunicaci&oacute;n enlazan todas las partes y los Controladores L&oacute;gicos Programables o por sus siglas PLC se encargan de controlar que todo tenga una secuencia, toma decisiones de acuerdo a una programaci&oacute;n pre establecida, se encarga de que el proceso cumpla con una repetici&oacute;n, a esto debemos a&ntilde;adir otras tecnolog&iacute;as como el vac&iacute;o, la rob&oacute;tica, telemetr&iacute;a y otras m&aacute;s.</p>
',  E'<p>Las alternativas seleccionadas para desarrollar la construcci&oacute;n del prototipo fueron las correctas debido a que cada sistema satisface a los requerimientos impuestos por la<br />
\\r\\nempresa.</p>

<p>Todos los elementos que conforman la m&aacute;quina est&aacute;n dise&ntilde;ados bajo par&aacute;metros y criterios que permiten a la m&aacute;quina un mejor desempe&ntilde;o, rendimiento fiabilidad. Adem&aacute;s de que son de f&aacute;cil mantenimiento y control.</p>

<p>Una vez realizado el an&aacute;lisis econ&oacute;mico de la m&aacute;quina se concluye que la m&aacute;quina cumple con las expectativas de la empresa y la inversi&oacute;n se recupera en un a&ntilde;o y medio. Adem&aacute;s el costo de fabricaci&oacute;n es menor a m&aacute;quinas de similares caracter&iacute;sticas.</p>

<p>La simulaci&oacute;n en programa ANSYS facilito obtener algunas variables fundamentales para el correcto funcionamiento de la m&aacute;quina como es la velocidad y su transferencia<br />
de calor, de &eacute;sta manera se puede obtener un sellado &oacute;ptimo y se evita el desperdicio de material en pruebas.</p>

<p>Se logr&oacute; comprobar los resultados de los c&aacute;lculos y an&aacute;lisis de Ansys Workbench con la pruebas realizadas, ya que variando uno de los par&aacute;metros dados en los c&aacute;lculos se<br />
obtienen errores en las pruebas de sellado. Un ejemplo claro es al variar la temperatura, si se alcanza una temperatura mayor a la temperatura de operaci&oacute;n del polipropileno biorientado hace que se queme y si la temperatura es menor el sellado no es el &oacute;ptimo.</p>

<p>En el ensamble es importante la alineaci&oacute;n y lubricaci&oacute;n correcta de los elementos de transmisi&oacute;n, ya que la mala ubicaci&oacute;n de los mismos provoca un incremento en el<br />
\\r\\ntorque del motor ocasionando su sobrecalentamiento o posibles trabas en los mecanismos.</p>
', '2019-07-19', 'dicyt_2019_07_19_22_31_55.pdf', 'UNIV BEYMAR DANY LAIME RAMOS', '2018', '4', 'ING. BERGMAN CARRASCO URIONA', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('13', '12', '19', 'IDENTIFICACIÓN DE FUENTES DE AGUA POTABLE POR GRAVEDAD PARA LAS COMUNIDADES AFECTADAS POR LA CONTAMINACIÓN DEL RIÓ  DE CAIZA ', '1', '2',  E'<p>El objetivo general del trabajo de investigaci&oacute;n es identificar nuevas fuentes para agua potable por gravedad para las comunidades de Chincurani, Mauca Caiza, Jatun Pampa<br />
\\r\\ndel municipio de Caiza D.</p>
', '<p>NO DISPONIBLE</p>
', '<ul>
	<li>El caudal de ofertada de las diferentes fuentes de agua es apreciable para el aforo de que se la realiza de manera normal utilizando el m&eacute;todo volum&eacute;trico.</li>
	<li>Los par&aacute;metros de los resultados del an&aacute;lisis de las diferentes muestras de agua son aceptables, encontr&aacute;ndose dentro el rango de fuentes de agua BUENA.</li>
	<li>presencia del Ph en las tres muestras se encuentra levemente fuera del rango, bajo, pero no es riesgo directo para la salud, por lo que se el an&aacute;lisis de calidad de agua, es potable, es buena para el consumo humano.</li>
	<li>El caudal ofertado por las diferentes fuentes de agua cubre la demanda de agua de los pobladores que habitan en las comunidades de Chincurani, Mauca Caiza y Jatum Pampa.</li>
	<li>El &aacute;rea de estudio para las obras de toma de las fuentes de agua se encuentran a una buena altura don referencia al reservorio, por lo que le sistema de agua funcionaria por gravedad.</li>
	<li>En la fuente de agua &ldquo;Sewencani&rdquo; de la comunidad de chincurani presnta un tipo de fuente denominada &ldquo;MANANTIAL&rdquo;, las fuentes de &ldquo;Jalanta&rdquo; y &ldquo;Jalaru&rdquo; de las comunidades de Mauca Caiza y Jatun Pampa presentan un tipo de fuente denominado &ldquo;ARROYOS&rdquo;.</li>
</ul>
', '2019-07-19', 'dicyt_2019_07_19_22_32_32.pdf', 'UNIV. FRANKLIN ANAGUA COILA', '2018', '0', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('12', '12', '7', 'PROYECTO DE INVESTIGACION CARTOGRFIA TURISTICA APLICADO EN LAS COMUNIDAD DE TARAPAYA Y MONDRAGON', '1', '2', '<p>Realizar la cartograf&iacute;a tem&aacute;tica de las comunidades de TARAPAYA Y MONDRAGON para el desarrollo del turismo comunitario, de esa marera las comunidades que cuenten con la cartograf&iacute;a actualizada para el beneficio del municipio de yocalla y tambi&eacute;n mediante ella incentivar al turismo que va generar ingresos econ&oacute;micos para el municipio.</p>
', '<p>El presente trabajo de investigaci&oacute;n, consiste en desarrollar la cartograf&iacute;a tur&iacute;stica para generar el incentivo tur&iacute;stico en las comunidades de TARAPAYA y MONDRAG&Oacute;N ya que en las comunidades mencionadas existen mucha potencial de turismo mediante la cartograf&iacute;a tur&iacute;stica podemos generar gran cantidad de turistas visitando a nuestras comunidades y mediante ella generar recursos que ingresen al municipio.</p>

<p>El problema de investigaci&oacute;n fui analizar los aspectos que contempla la implementaci&oacute;n de un proyecto una innovaci&oacute;n, considerados fundamentales para la permanencia del turismo.</p>

<p>El proyecto de investigaci&oacute;n se realiz&oacute; en base al estudio&nbsp; de metodolog&iacute;a de informaci&oacute;n de diversas fuentes como documentos internos&nbsp; de las instituciones entrevistas encuestas con la comunidades de TARAPAYA Y MONDRAG&Oacute;N observaciones y una revisi&oacute;n literatura, se analiza el trabajo a trav&eacute;s de variables media te el ruteo con GPS a lo largo de la investigaci&oacute;n que son la motivaci&oacute;n para los pueblos de municipio y poseen los mecanismos hacia su trabajo para participar y generar recursos sustentables y sostenibles en el sistema de certificaci&oacute;n a nivel tur&iacute;stico hay la cartograf&iacute;a y percepci&oacute;n que tiene los trabajador del &aacute;rea rural.</p>

<p>A partir de este trabajo, se argumenta la necesidad que tienen estas comunidades de conocer sus respectivas naturalezas y tur&iacute;sticas, con el fin de elaborar una pol&iacute;tica tur&iacute;stica propia, adaptando la gesti&oacute;n de los flujos tur&iacute;sticos a las caracter&iacute;sticas del patrimonio natural y cultural propio de cada uno de ellos, y no al contrario.</p>

<p>El presente trabajo de grado, es una investigaci&oacute;n que trata sobre el estudio de la Optimizaci&oacute;n de cartograf&iacute;a y de recursos: humanos, materiales, &uacute;tiles de oficina, tiempo en la atenci&oacute;n dl personal tur&iacute;stica de s hemos realizado investigaci&oacute;n de campo en las comunidades mencionadas, observando falencias que existen de manera notoria en las cartograf&iacute;as, en cuanto se refiere a tiempo en la tramitaci&oacute;n de documentos, errores en la base de datos, respuestas inapropiadas a los usuarios. Recopilamos informaci&oacute;n a trav&eacute;s de la t&eacute;cnica de la encuesta dirigida hacia los investigadores y entrevista a personal administrativo, que nos sirven como orientaci&oacute;n para realizar la propuesta de la elaboraci&oacute;n de una gu&iacute;a para optimizar recursos, misma que determina seg&uacute;n el diagnostico factores favorables y desfavorables que afectan a la Instituci&oacute;n y que permitieron establecer los objetivos a lograrse.</p>
', '<p>En la investigaci&oacute;n del presente trabajo se han logrado alcanzar los objetivos planteados con gran satisfacci&oacute;n.</p>

<p>Implementar m&aacute;s estudios de investigaci&oacute;n a nuestras comunidades para describir mas lugares atractivos tur&iacute;sticos.</p>

<p>Se considera adem&aacute;s que es necesario que los autoridades municipales y provinciales tomen conciencia de la importancia de contar con un trabajo de investigaci&oacute;n.</p>
', '2019-07-19', 'dicyt_2019_07_19_22_17_57.docx', 'UNIV. BENITO MAMANI CARVAJAL', '2018', '1', 'LIC. LUIS VELIS CHUMACERO', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('7', '1', '5', 'PROPIEDADES FÍSICAS EN LA APLICACIÓN DE SISTEMAS FOTOVOLTAICO PARA EL CALENTAMIENTO DE AGUA EN VIVIENDAS FAMILIARES', '1', '2', '<p>Cuantificar las propiedades f&iacute;sicas de sistemas fotovoltaico con el fin generar energ&iacute;a el&eacute;ctrica para calentamiento de agua en viviendas familiares en el departamento de Potos&iacute;.</p>
', '<p>En resumen, la corriente entregada a una carga por un diodo semiconductor iluminado es el resultado neto de dos componentes internas de corriente que se oponen:</p>

<ol>
	<li>La corriente fotogenerada o fotocorriente debida a la generaci&oacute;n de potadores que producen la iluminaci&oacute;n.</li>
	<li>La corriente de diodo o corriente de oscuridad debida a la recombinaci&oacute;n de portadores que producen el voltaje externo necesario para poder entregar a la energ&iacute;a a la carga.</li>
</ol>

<p>La corriente neta que circula por el exterior vendr&aacute; dada por la suma algebraica de las dos componentes de corriente anteriores. Tomando como positivas las corrientes de generaci&oacute;n, se puede escribir (E., 1994, pp. 64-68):</p>

<p>Que es la ecuaci&oacute;n caracter&iacute;stica de la c&eacute;lula solar, valida en todos sus rangos de funcionamiento.</p>
', '<p>Se cuantifico las propiedades f&iacute;sicas de sistemas fotovoltaico con el fin generar energ&iacute;a el&eacute;ctrica para calentamiento de agua en viviendas familiares en el departamento de Potos&iacute;.</p>

<p>Como se puede observar en la Tabla 3.3 y Tabla 3.4 que la radiaci&oacute;n solar se aproxim&oacute; al mapa solar del departamento de Potos&iacute;.</p>

<p>La utilizaci&oacute;n de la tecnolog&iacute;a fotovoltaica es aplicable para las duchas, vale decir en disminuir carga el&eacute;ctrica, a&uacute;n no se extendi&oacute; y es donde mejor pueden desarrollarse este tipo de sistemas, sin alterar el entorno ni perjudicar la flora y la fauna de la regi&oacute;n, teniendo en cuenta la ubicaci&oacute;n y las condiciones del entorno.</p>

<p>La implementaci&oacute;n de un sistema solar fotovoltaico, es una soluci&oacute;n a la necesidad energ&eacute;tica continua para la prestaci&oacute;n de los servicios domiciliares, que traer&aacute; una mejora en las condiciones de vida de los pobladores, ya que el servicio que actualmente se tiene presenta muchas deficiencias.</p>
', '2019-07-19', 'dicyt_2019_07_19_22_21_52.pdf', 'UNIV. JUAN JOSE BUHEZO SOTO', '2018', '0', 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO trabajo_investigacion (id_investigacion, id_facultad, id_carrera, titulo_investigacion, autor, tipo_investigador, objetivo_general, resumen, conclusiones, fecha, archivo, nombre_autor, gestion, visitas, tutor, tipo_investigacion) VALUES ('46', '13', '32', 'ESTRATEGIA  FINANCIERA  BASADA EN EL ESTUDIO  DE CAPITAL DE TRABAJO PARA OPTIMIZAR LA PRODUCCION EN LA FABRICA DE ROPA DEPORTIVA ? C Y C ? EN LA CIUDAD DE POTOSI', '1', '2', '<p>El <strong>objetivo general es</strong> proponer una&nbsp; estrategia&nbsp; financiera basada en el capital de trabajo para optimizar la producci&oacute;n de la f&aacute;brica de ropa deportiva C y C&nbsp;&nbsp; de la ciudad de&nbsp; Potos&iacute;.</p>
', '<p>El presente trabajo de investigaci&oacute;n titula Estrategia Financiera basada en capital de trabajo para optimizar la producci&oacute;n en la f&aacute;brica de ropa deportiva de la ciudad de potos&iacute;&nbsp; a principios de a&ntilde;o se realiz&oacute; una gu&iacute;a de observaci&oacute;n dentro la f&aacute;brica que no contaba con el suficiente maquinaria para su producci&oacute;n a dem&aacute;s que no cuenta con el personal capacitado, ni el espacio suficiente, para que los trabajadores puedan elaborar los deportivos a gusto del cliente, por tal motivo el en los &uacute;ltimos a&ntilde;os la f&aacute;brica no tuvo muchos contratos.</p>

<p>El diagn&oacute;stico de la investigaci&oacute;n demuestra que la visi&oacute;n de la f&aacute;brica&nbsp; de ropa deportiva es ser una empresa reconocida a nivel departamental por la calidad de sus productos&nbsp; garantizados que brinda a la ciudad de Potos&iacute; que de la misma forma busca optimizar la producci&oacute;n debido a que los anterior a&ntilde;os no tiene una buena producci&oacute;n, por tal motivo afecta a sus ingresos de las dos &uacute;ltimas gestiones.</p>

<p>La elaboraci&oacute;n de la estrategia financiera determina todos los ingresos, costos, gastos, y el presupuesto para la adquisici&oacute;n de maquinaria que se requiere.</p>

<p>De la misma forma se demuestra que con la compra&nbsp; de nuevas m&aacute;quinas de &uacute;ltima tecnolog&iacute;a&nbsp; que &nbsp;se logra optimizar la producci&oacute;n, debido a que la obtiene muchos contratos debido a que se cumple con la exigencia de cada cliente ya no existe reclamos oh devoluciones de los deportivos, como anteriormente mencionaba el propietario de la f&aacute;brica, con esta estrategia de financiamiento la f&aacute;brica tendr&aacute; mayor producci&oacute;n beneficiando a&nbsp; la utilidad de la f&aacute;brica, a&nbsp; la ves esto ser&aacute; beneficioso para el propietario y los trabajadores como tambi&eacute;n a los clientes debido que se entregara deportivos de alta calidad.&nbsp;</p>

<p>Los resultados de la investigaci&oacute;n demuestra la viabilidad del trabajo la cual puede ser implementando en la f&aacute;brica de ropa deportiva debido que el financiamiento ser&aacute; de gran ayuda para la f&aacute;brica para optimizar la producci&oacute;n con las nuevas maquinarias.</p>
', '<p>En el <strong>cap&iacute;tulo I</strong> se recopilara todos los instrumentos te&oacute;ricos enfoques y estudios antecedentes generales los cuales est&aacute;n bien estructurados y puntualizados los cuales se refieren al problema de investigaci&oacute;n la optimizar de la producci&oacute;n de la f&aacute;brica de ropa deportiva C y C&nbsp; generando dificultades en el momento de la&nbsp; compra de sus materiales teniendo los&nbsp; costos&nbsp; elevados, para los problemas que atraviesa no cuenta con maquinarias de &uacute;ltima tecnolog&iacute;a</p>

<p>En el <strong>cap&iacute;tulo II</strong>&nbsp; se dedicara al diagn&oacute;stico cuyo prop&oacute;sito b&aacute;sico esencial es el conocimiento real y explicativo del&nbsp; sector adem&aacute;s, tener una explicaci&oacute;n casual del sector considerado en su conjunto y en cada uno de sus dimensiones o partes en la cual se pudo observar que&nbsp; su producci&oacute;n&nbsp;&nbsp; es muy baja en las dos &uacute;ltimas gestiones y&nbsp; realizando una encuesta a los trabajadores se pudo evidenciar que el problema es la falta de m&aacute;quina y la capacitaci&oacute;n al personal</p>

<p>En el<strong> cap&iacute;tulo III</strong>&nbsp; se realizara la estructura del modelo te&oacute;rico como posici&oacute;n y resultado directo de todo lo expuesto, hace referencia a la propuesta que dar&aacute; soluci&oacute;n al problema planteado, para lo cual se realiz&oacute; una estrategia de financiamiento para la compra de nuevas maquinaras y brindar capacitaci&oacute;n al personal para que la producci&oacute;n aumente en los siguientes a&ntilde;os</p>
', '2020-02-26', 'dicyt_2020_02_26_22_32_37.docx', 'UNIV. AYDEE CONDORI CHOQUE', '2019', '1', 'LIC. ERIK BOBARIN', 'descriptivas');

-- INSERT DATA becas
INSERT INTO becas (id_beca, titulo, fecha, descripcion, imagen, id_usuario) VALUES ('5', 'CURSO TALLER DE KODULAR ARDUINO ', '2018-09-30', '<p>Aprende a crear aplicaciones para Android y manipular Arduino a tu gusto mediante bluetooth.</p>
', '99010920_1003322086737265_1924685135802793984_n.jpg', '1');
INSERT INTO becas (id_beca, titulo, fecha, descripcion, imagen, id_usuario) VALUES ('1', 'MAESTRÍA EN REDES Y TELECOMUNICACIONES', '2019-06-04', '<p>En un escenario globalizado y altamente competitivo, como el que se vive actualmente, las cambiantes y cada vez m&aacute;s exigentes necesidades de la poblaci&oacute;n han hecho que los sistemas tradicionales de comunicaci&oacute;n se transformen, al ampliar su cobertura e incorporar nuevos y eficientes servicios.</p>

<p>Hoy en d&iacute;a, las Redes y Sistemas de Comunicaciones constituyen un soporte indispensable para el desarrollo de la sociedad desde aspectos tecnol&oacute;gicos, econ&oacute;micos y sociales, ya que proporciona nuevas y mejores formas de relaci&oacute;n e interacci&oacute;n entre distintos agentes sociales, mediante infraestructuras, servicios y aplicaciones para comunicaciones.</p>

<p>La Maestr&iacute;a en Redes y Telecomunicaciones es un programa de posgrado adscrito a la Carrera de Ing. Inform&aacute;tica en el que se profundiza, estudia, investiga, desarrolla.</p>
', 'a_redes.jpg', '1');
INSERT INTO becas (id_beca, titulo, fecha, descripcion, imagen, id_usuario) VALUES ('3', 'MAESTRÍA EN HIDROLOGÍA Y OBRAS HIDRÁULICAS', '2017-04-12', '<p>El manejo inadecuado de los recursos naturales de las cuencas hidrogr&aacute;ficas, causan dificultades relacionadas con el recurso h&iacute;drico, principalmente en la captaci&oacute;n, retenci&oacute;n del agua de lluvia en los suelos, el incremento del escurrimiento superficial y en la disminuci&oacute;n en la recarga de los acu&iacute;feros, propiciando con ello erosi&oacute;n h&iacute;drica severa y p&eacute;rdida de suelo f&eacute;rtil en las tierras de laderas y su arrastre hacia cauces y zonas bajas.</p>

<p>Es menester profundizar conocimientos te&oacute;ricos y pr&aacute;cticos en los profesionales en el dise&ntilde;o de presas, incorporando aspectos y consideraciones del manejo integral de cuencas hidrogr&aacute;ficas, desde una &oacute;ptica af&iacute;n a los principios del desarrollo sostenible.</p>
', 'a_hidrologia.jpg', '1');
INSERT INTO becas (id_beca, titulo, fecha, descripcion, imagen, id_usuario) VALUES ('2', 'MAESTRÍA EN PREPARACIÓN, EVALUACIÓN Y GESTIÓN DE PROYECTOS DE INVERSIÓN', '2017-04-10', '<p>Es un objetivo de la Universidad Aut&oacute;noma Tom&aacute;s Fr&iacute;as y en especial de la Facultad de Ciencias Econ&oacute;micas y Financieras, es dotar a profesionales, t&eacute;cnicos, empresarios y directivos de empresas, con herramientas de decisi&oacute;n de inversiones y gesti&oacute;n de empresas que les permitan enfrentar con &eacute;xito los desaf&iacute;os a los que continuamente se ven enfrentados.</p>

<p>En esa l&iacute;nea, se presenta la Maestr&iacute;a en Preparaci&oacute;n, Evaluaci&oacute;n y Gesti&oacute;n de Proyectos de Inversi&oacute;n, encontr&aacute;ndonos seguros que la misma responder&aacute; al objetivo de adquirir una especializaci&oacute;n calificada para el an&aacute;lisis, dise&ntilde;o y evaluaci&oacute;n cualitativa y cuantitativa en la tem&aacute;tica de elaboraci&oacute;n, evaluaci&oacute;n y gerencia de proyectos.</p>

<p>Tomar decisiones d</p>
', 'a_proyectos.jpg', '1');
INSERT INTO becas (id_beca, titulo, fecha, descripcion, imagen, id_usuario) VALUES ('4', 'MAESTRÍA EN FINANZAS', '2017-02-20', '<p>En la actualidad existe la necesidad apremiante de que el sector empresarial cuente con recursos humanos preparados para llevar a cabo las operaciones de gesti&oacute;n financiera, lo cual exige la especializaci&oacute;n o formaci&oacute;n acad&eacute;mica de postgrado. En este sentido, existe la necesidad de contar con recursos humanos con visi&oacute;n y competencias a nivel local e internacional para afrontar los retos de la globalizaci&oacute;n y su impacto en el mundo empresarial, donde el &aacute;rea financiera juega un rol preponderante en los procesos de apertura de los mercados y la internacionalizaci&oacute;n de la econom&iacute;a.</p>

<p>La direcci&oacute;n financiera se ha convertido en una parte esencial de la gesti&oacute;n de las empresas. Y en una funci&oacute;n m&aacute;s compleja para cuyo desempe&ntilde;o se requieren conocimientos y actitudes espec&iacute;ficas</p>
', 'a_finanzas.jpg', '1');

-- INSERT DATA tipo_convenio
INSERT INTO tipo_convenio (id_convenio, nombre_convenio) VALUES ('1', 'Convenios Internacionales');
INSERT INTO tipo_convenio (id_convenio, nombre_convenio) VALUES ('2', 'Convenios Nacionales');
INSERT INTO tipo_convenio (id_convenio, nombre_convenio) VALUES ('3', 'Convenios Regionales');

-- INSERT DATA tipo_convocatoria
INSERT INTO tipo_convocatoria (id_tipo_convocatoria, nombre_tipo) VALUES ('1', 'Convocatoria a Ferias de Investigación');
INSERT INTO tipo_convocatoria (id_tipo_convocatoria, nombre_tipo) VALUES ('2', 'Convocatoria a Becas de Auxiliares de Investigación');

-- INSERT DATA detalle_avances
INSERT INTO detalle_avances (id_detalle, id_avance, id_usuario, archivo, fecha, puntage, estado, avance) VALUES ('11', '10', '7', '1ra__CONVOCATORIA_AUXILIAR_DE_INVESTIGACIÓN_20181.pdf', '2019-12-09', '0', '1', '');

-- INSERT DATA tipo_publicacion
INSERT INTO tipo_publicacion (id_tipo_publi, nombre_publicacion) VALUES ('1', 'articulos');
INSERT INTO tipo_publicacion (id_tipo_publi, nombre_publicacion) VALUES ('2', 'boletines');
INSERT INTO tipo_publicacion (id_tipo_publi, nombre_publicacion) VALUES ('4', 'noticias y eventos');
INSERT INTO tipo_publicacion (id_tipo_publi, nombre_publicacion) VALUES ('5', 'revistas');

-- INSERT DATA carrera
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('1', '1', 'Ingeniería Informática', 'INFOR.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('2', '1', 'Quimica', 'QUIMICA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('3', '17', 'Medicina', 'Medicina.jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('4', '2', 'Enfermeria', 'ESCUDO_ENF.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('5', '1', 'Fisica', 'ESCUDO_FISICA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('7', '12', 'Ingeniería en Geodesia y Topografía', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('8', '7', 'Turismo - Uyuni', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('9', '7', 'Trabajo Social - Uncia', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('10', '7', 'Turismo', 'TURISMO.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('11', '7', 'Lingüística e Idiomas', 'LINGUISTICA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('12', '7', 'Trabajo Social', 'TRABAJO_SOCIAL.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('13', '7', 'Lingüística e Idiomas - Uyuni', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('14', '8', 'Ingeniería Agropecuaria - Villazon', 'ESCUDO_AGROPECUARIA_VILLAZON.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('15', '8', 'Med. Veterinaria y Zootecnia - Tupiza', 'ESCUDO_VETERINARIA_TUPIZA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('16', '8', 'Ingeniería Agronomica', 'CARRERA_AGRONOMIA.jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('17', '8', 'Ingeniería AgroIndustrial', 'descarga.jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('18', '8', 'Ingeniería en Desarrollo Rural', 'ESCUDO_DESARROLLO_RURAL.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('19', '12', 'Ingeniería Civil', 'descarga_(1).jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('20', '12', 'Construcciones Civiles', 'CONSTRUCCIONES_CIVILES.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('21', '2', 'Enfermería - Villazon', 'LOGO_ENF__VILLAZON.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('22', '14', 'Artes Musicales', 'logo_artes_musicales_oficial_2222.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('23', '14', 'Artes Plásticas', 'ESCUDO-C_-ARTES-PLAS.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('24', '1', 'Estadistica', 'ESTADISTICA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('25', '1', 'Matemática', 'MATEMATICA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('26', '1', 'Ingeniería de Sistemas', 'logoSis.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('27', '15', 'Ingeniería Geológica', 'ESCUDO_GEOLOGIA.jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('28', '15', 'Ingeniería del Medio Ambiente', 'ESCUDO_MEDIO_BAMBIENTE.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('29', '13', 'Economía - Uyuni', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('30', '13', 'Administración de Empresas', 'LOGO_ADMINISTRACION.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('31', '13', 'Economía - Uncia', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('32', '13', 'Contabilidad y Finanzas', 'CONTABILIDAD_Y_FINANZAS.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('33', '13', 'Economía', 'ESCUDO_ECONOMIA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('34', '13', 'Auditoria - Contaduría Publica', 'AUDITORIA_ESCUDO_BROCHE.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('35', '13', 'Contaduría Publica - Tupiza', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('36', '16', 'Derecho', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('37', '16', 'Derecho - Uncia', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('38', '5', 'Ingeniería Minera', 'FACULTAD_ING_MINERA.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('39', '5', 'Ingeniería de Procesos de Materias Primas Minerales', 'ING__DE_PROCESOS.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('40', '18', 'Ingeniería Eléctrica', 'images.jpg');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('41', '18', 'Mecánica Automotriz', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('42', '18', 'Ingeniería Electrónica', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('43', '18', 'Ingeniería Mecánica', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('44', '18', 'Ingeniería Mecatronica', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('45', '14', 'Arquitectura', 'descarga.png');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('46', '7', 'Comunicación Social', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('47', '17', 'Odontología ', '');
INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera, imagenc) VALUES ('48', '13', 'Ingeniería Comercial', '');

-- INSERT DATA usuario
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('1', 'super', 'admin pat', 'admin mat', 'administrador', 'MTIz', '12345678', 'admin_dir', '1234321', 'admin@hotmail.com', '1', '0', '0', '1', '21232013_264985600678652_4847179112510477865_n.jpg', '0', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('8', 'coordinador', 'cor pa', 'cor ma', 'cordinador', 'MTIz', '98989833', 'coor_dir', '1234321', 'coor@gmail.com', '4', '0', '0', '1', '51989158_2258941544150410_6014629066961846272_n.jpg', '0', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('11', 'jorge', 'valza', 'vlaza', 'jorguito', 'MTIzNA==', '9908987h', 'cañete s/n', '879877697', 'jorge@hotmail.com', '3', '5', '38', '1', 'screen-shot-2015-12-10-at-11-15-06-am-800x800.jpg', '2', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('15', 'jorge', 'quispe', 'valle', 'jorge quispe', 'NTE0MTk5OQ==', '5141999', 'peru # 10', '26243565', 'jorge_valle@hotmail.com', '3', '13', '30', '1', 'images_(1).jpg', '1', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('16', 'monica', 'valda', 'valdez', 'monica valda', 'NjAxMjc4Mw==', '6012783', 'la paz s/n', '26222834', 'moniquita@hotmail.com', '3', '18', '43', '1', 'images_(7).jpg', '1', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('17', 'orlando', 'choque', 'ayma', 'orlando choque', 'MTgzMjU2Nw==', '1832567', 'lindaura s/n', '79456213', 'choquesito@hotmail.com', '2', '7', '8', '1', 'images_(2).jpg', '0', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('14', 'maribel', 'condori', 'salas', 'maribelsita', 'OTAwOTgwOThqag==', '90098098jj', 'otero # 1234', '125664456', 'soybuena@hotmail.com', '3', '15', '28', '1', 'images_(6).jpg', '1', '2018');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('13', 'Leticia', 'Valda', 'Revollo', 'leticia123', 'OTg3OTg3OTg3OQ==', '9879879879', 'Bustillos # 31', '2147483647', 'leti@hotmail.com', '2', '16', '36', '1', 'images_(3).jpg', '0', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('5', 'Juan Carlos', 'Flores', 'Flores', 'carlos', 'MTIzNDU2NzEy', '123456712', 'Av. Quijarro # 23', '79123265', 'direc@hotmail.com', '2', '1', '1', '1', 'images.jpg', '1', '2018');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('7', 'alex', 'quispe', 'villarroel', 'alequillo', 'Z2cxMmUyMjM=', 'gg12e223', 'Av. Duarte #129', '791232653', 'usuario@hotmail.com', '3', '1', '1', '1', 'descarga.jpg', '2', '2018');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('12', 'reyna', 'pachas', 'gonzales', 'reynitapa', 'ODc4Njg3Ng==', '8786876', 'las lomas # 12', '876587678', 'reyna@hotmail.com', '3', '2', '4', '1', 'images_(5).jpg', '1', '2019');
INSERT INTO usuario (id_usuario, nombre_completo, apellido_pat, apellido_mat, usuario, contrasena, ci, direccion, telefono, email, rol_id, id_facultad, id_carrera, estado, imagen, tipo_investigador, gestion) VALUES ('18', 'mauricio', 'nina', 'mijica', 'mauricio nina', 'Mzc0Mjg3NA==', '3742874', 'delicia', '7883624', 'mauricio_nina@hotmail.com', '3', '5', '38', '1', 'ESCUDO_ENF.png', '2', '2020');

-- FOREIGN KEY
ALTER TABLE becas ADD CONSTRAINT becas_ibfk_1 FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario);
ALTER TABLE carrera ADD CONSTRAINT carrera_ibfk_1 FOREIGN KEY (id_facultad) REFERENCES facultades (id_facultad);
ALTER TABLE convenios ADD CONSTRAINT convenios_ibfk_1 FOREIGN KEY (tipo_convenio) REFERENCES tipo_convenio (id_convenio);
ALTER TABLE convocatoria ADD CONSTRAINT convocatoria_ibfk_1 FOREIGN KEY (id_tipo_convocatoria) REFERENCES tipo_convocatoria (id_tipo_convocatoria);
ALTER TABLE detalle_avances ADD CONSTRAINT detalle_avances_ibfk_1 FOREIGN KEY (id_avance) REFERENCES eventos (id_evento);
ALTER TABLE fotos_noticias ADD CONSTRAINT fotos_noticias_ibfk_1 FOREIGN KEY (id_publi) REFERENCES publicacion (id_publicacion);
ALTER TABLE personal ADD CONSTRAINT personal_ibfk_1 FOREIGN KEY (id_cargo) REFERENCES cargo (id_cargo);
ALTER TABLE publicacion ADD CONSTRAINT publicacion_ibfk_1 FOREIGN KEY (id_tipo_publi) REFERENCES tipo_publicacion (id_tipo_publi);
ALTER TABLE trabajo_investigacion ADD CONSTRAINT trabajo_investigacion_ibfk_2 FOREIGN KEY (id_carrera) REFERENCES carrera (id_carrera);
ALTER TABLE trabajo_investigacion ADD CONSTRAINT trabajo_investigacion_ibfk_3 FOREIGN KEY (tipo_investigador) REFERENCES tipo_investigador (id);
ALTER TABLE usuario ADD CONSTRAINT usuario_ibfk_1 FOREIGN KEY (rol_id) REFERENCES roles (id);


-- ALTER SEQUENCE becas_id_beca_seq
ALTER SEQUENCE becas_id_beca_seq OWNED BY becas.id_beca;
SELECT pg_catalog.setval('becas_id_beca_seq', 5, true);
ALTER TABLE ONLY becas ALTER COLUMN id_beca SET DEFAULT nextval('becas_id_beca_seq'::regclass);

-- ALTER SEQUENCE cargo_id_cargo_seq
ALTER SEQUENCE cargo_id_cargo_seq OWNED BY cargo.id_cargo;
SELECT pg_catalog.setval('cargo_id_cargo_seq', 7, true);
ALTER TABLE ONLY cargo ALTER COLUMN id_cargo SET DEFAULT nextval('cargo_id_cargo_seq'::regclass);

-- ALTER SEQUENCE carrera_id_carrera_seq
ALTER SEQUENCE carrera_id_carrera_seq OWNED BY carrera.id_carrera;
SELECT pg_catalog.setval('carrera_id_carrera_seq', 48, true);
ALTER TABLE ONLY carrera ALTER COLUMN id_carrera SET DEFAULT nextval('carrera_id_carrera_seq'::regclass);

-- ALTER SEQUENCE convenios_id_convenios_seq
ALTER SEQUENCE convenios_id_convenios_seq OWNED BY convenios.id_convenios;
SELECT pg_catalog.setval('convenios_id_convenios_seq', 3, true);
ALTER TABLE ONLY convenios ALTER COLUMN id_convenios SET DEFAULT nextval('convenios_id_convenios_seq'::regclass);

-- ALTER SEQUENCE convocatoria_id_convocatoria_seq
ALTER SEQUENCE convocatoria_id_convocatoria_seq OWNED BY convocatoria.id_convocatoria;
SELECT pg_catalog.setval('convocatoria_id_convocatoria_seq', 4, true);
ALTER TABLE ONLY convocatoria ALTER COLUMN id_convocatoria SET DEFAULT nextval('convocatoria_id_convocatoria_seq'::regclass);

-- ALTER SEQUENCE detalle_avances_id_detalle_seq
ALTER SEQUENCE detalle_avances_id_detalle_seq OWNED BY detalle_avances.id_detalle;
SELECT pg_catalog.setval('detalle_avances_id_detalle_seq', 11, true);
ALTER TABLE ONLY detalle_avances ALTER COLUMN id_detalle SET DEFAULT nextval('detalle_avances_id_detalle_seq'::regclass);

-- ALTER SEQUENCE eventos_id_evento_seq
ALTER SEQUENCE eventos_id_evento_seq OWNED BY eventos.id_evento;
SELECT pg_catalog.setval('eventos_id_evento_seq', 12, true);
ALTER TABLE ONLY eventos ALTER COLUMN id_evento SET DEFAULT nextval('eventos_id_evento_seq'::regclass);

-- ALTER SEQUENCE fotos_noticias_id_noticias_seq
ALTER SEQUENCE fotos_noticias_id_noticias_seq OWNED BY fotos_noticias.id_noticias;
SELECT pg_catalog.setval('fotos_noticias_id_noticias_seq', 4, true);
ALTER TABLE ONLY fotos_noticias ALTER COLUMN id_noticias SET DEFAULT nextval('fotos_noticias_id_noticias_seq'::regclass);

-- ALTER SEQUENCE fotos_publicaciones_id_foto_seq
ALTER SEQUENCE fotos_publicaciones_id_foto_seq OWNED BY fotos_publicaciones.id_foto;
SELECT pg_catalog.setval('fotos_publicaciones_id_foto_seq', 76, true);
ALTER TABLE ONLY fotos_publicaciones ALTER COLUMN id_foto SET DEFAULT nextval('fotos_publicaciones_id_foto_seq'::regclass);

-- ALTER SEQUENCE mensajes_id_mensaje_seq
ALTER SEQUENCE mensajes_id_mensaje_seq OWNED BY mensajes.id_mensaje;
SELECT pg_catalog.setval('mensajes_id_mensaje_seq', 8, true);
ALTER TABLE ONLY mensajes ALTER COLUMN id_mensaje SET DEFAULT nextval('mensajes_id_mensaje_seq'::regclass);

-- ALTER SEQUENCE personal_id_personal_seq
ALTER SEQUENCE personal_id_personal_seq OWNED BY personal.id_personal;
SELECT pg_catalog.setval('personal_id_personal_seq', 4, true);
ALTER TABLE ONLY personal ALTER COLUMN id_personal SET DEFAULT nextval('personal_id_personal_seq'::regclass);

-- ALTER SEQUENCE portada_id_portada_seq
ALTER SEQUENCE portada_id_portada_seq OWNED BY portada.id_portada;
SELECT pg_catalog.setval('portada_id_portada_seq', 10, true);
ALTER TABLE ONLY portada ALTER COLUMN id_portada SET DEFAULT nextval('portada_id_portada_seq'::regclass);

-- ALTER SEQUENCE publicacion_id_publicacion_seq
ALTER SEQUENCE publicacion_id_publicacion_seq OWNED BY publicacion.id_publicacion;
SELECT pg_catalog.setval('publicacion_id_publicacion_seq', 10, true);
ALTER TABLE ONLY publicacion ALTER COLUMN id_publicacion SET DEFAULT nextval('publicacion_id_publicacion_seq'::regclass);

-- ALTER SEQUENCE recurso_id_recurso_seq
ALTER SEQUENCE recurso_id_recurso_seq OWNED BY recurso.id_recurso;
SELECT pg_catalog.setval('recurso_id_recurso_seq', 9, true);
ALTER TABLE ONLY recurso ALTER COLUMN id_recurso SET DEFAULT nextval('recurso_id_recurso_seq'::regclass);

-- ALTER SEQUENCE roles_id_seq
ALTER SEQUENCE roles_id_seq OWNED BY roles.id;
SELECT pg_catalog.setval('roles_id_seq', 4, true);
ALTER TABLE ONLY roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);

-- ALTER SEQUENCE tipo_convenio_id_convenio_seq
ALTER SEQUENCE tipo_convenio_id_convenio_seq OWNED BY tipo_convenio.id_convenio;
SELECT pg_catalog.setval('tipo_convenio_id_convenio_seq', 3, true);
ALTER TABLE ONLY tipo_convenio ALTER COLUMN id_convenio SET DEFAULT nextval('tipo_convenio_id_convenio_seq'::regclass);

-- ALTER SEQUENCE tipo_convocatoria_id_tipo_convocatoria_seq
ALTER SEQUENCE tipo_convocatoria_id_tipo_convocatoria_seq OWNED BY tipo_convocatoria.id_tipo_convocatoria;
SELECT pg_catalog.setval('tipo_convocatoria_id_tipo_convocatoria_seq', 2, true);
ALTER TABLE ONLY tipo_convocatoria ALTER COLUMN id_tipo_convocatoria SET DEFAULT nextval('tipo_convocatoria_id_tipo_convocatoria_seq'::regclass);

-- ALTER SEQUENCE tipo_investigador_id_seq
ALTER SEQUENCE tipo_investigador_id_seq OWNED BY tipo_investigador.id;
SELECT pg_catalog.setval('tipo_investigador_id_seq', 3, true);
ALTER TABLE ONLY tipo_investigador ALTER COLUMN id SET DEFAULT nextval('tipo_investigador_id_seq'::regclass);

-- ALTER SEQUENCE tipo_publicacion_id_tipo_publi_seq
ALTER SEQUENCE tipo_publicacion_id_tipo_publi_seq OWNED BY tipo_publicacion.id_tipo_publi;
SELECT pg_catalog.setval('tipo_publicacion_id_tipo_publi_seq', 5, true);
ALTER TABLE ONLY tipo_publicacion ALTER COLUMN id_tipo_publi SET DEFAULT nextval('tipo_publicacion_id_tipo_publi_seq'::regclass);

-- ALTER SEQUENCE trabajo_investigacion_id_investigacion_seq
ALTER SEQUENCE trabajo_investigacion_id_investigacion_seq OWNED BY trabajo_investigacion.id_investigacion;
SELECT pg_catalog.setval('trabajo_investigacion_id_investigacion_seq', 51, true);
ALTER TABLE ONLY trabajo_investigacion ALTER COLUMN id_investigacion SET DEFAULT nextval('trabajo_investigacion_id_investigacion_seq'::regclass);

-- ALTER SEQUENCE usuario_id_usuario_seq
ALTER SEQUENCE usuario_id_usuario_seq OWNED BY usuario.id_usuario;
SELECT pg_catalog.setval('usuario_id_usuario_seq', 18, true);
ALTER TABLE ONLY usuario ALTER COLUMN id_usuario SET DEFAULT nextval('usuario_id_usuario_seq'::regclass);

-- ALTER SEQUENCE facultades_id_facultad_seq
ALTER SEQUENCE facultades_id_facultad_seq OWNED BY facultades.id_facultad;
SELECT pg_catalog.setval('facultades_id_facultad_seq', 18, true);
ALTER TABLE ONLY facultades ALTER COLUMN id_facultad SET DEFAULT nextval('facultades_id_facultad_seq'::regclass);