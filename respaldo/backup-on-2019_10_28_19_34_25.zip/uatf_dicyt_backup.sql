#
# TABLE STRUCTURE FOR: becas
#

DROP TABLE IF EXISTS `becas`;

CREATE TABLE `becas` (
  `id_beca` int(30) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` varchar(900) NOT NULL,
  `imagen` varchar(100) NOT NULL,
  `id_usuario` int(30) NOT NULL,
  PRIMARY KEY (`id_beca`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `becas` (`id_beca`, `titulo`, `fecha`, `descripcion`, `imagen`, `id_usuario`) VALUES (1, 'Convocatoria de Becas de Excelencia de Programas Especiales del Gobierno de México para Extranjeros.', '2019-06-04', 'Convocatoria de Becas de Excelencia de Programas Especiales del Gobierno de México para Extranjeros 2016, de la Agencia Mexicana de Cooperación Internacional para el Desarrollo AMEXCID Con el propósito de contribuir a la construcción de puentes de diálogo permanentes y de largo plazo que enriquezcan a la academia y cultura mexicana, mediante la presencia en México de estudiantes, investigadores, académicos y artistas extranjeros, el Gobierno de México otorga becas a través de los siguientes Programas Especiales.', 'b.jpg', 1);


#
# TABLE STRUCTURE FOR: cargo
#

DROP TABLE IF EXISTS `cargo`;

CREATE TABLE `cargo` (
  `id_cargo` int(100) NOT NULL AUTO_INCREMENT,
  `nombre_cargo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_cargo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cargo` (`id_cargo`, `nombre_cargo`) VALUES (1, 'Director de DICYT');
INSERT INTO `cargo` (`id_cargo`, `nombre_cargo`) VALUES (2, 'Secretari@');
INSERT INTO `cargo` (`id_cargo`, `nombre_cargo`) VALUES (4, 'Portero');


#
# TABLE STRUCTURE FOR: carrera
#

DROP TABLE IF EXISTS `carrera`;

CREATE TABLE `carrera` (
  `id_carrera` int(100) NOT NULL AUTO_INCREMENT,
  `id_facultad` int(100) NOT NULL,
  `nombre_carrera` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_carrera`),
  KEY `id_facultad` (`id_facultad`),
  KEY `id_facultad_2` (`id_facultad`),
  CONSTRAINT `carrera_ibfk_1` FOREIGN KEY (`id_facultad`) REFERENCES `facultades` (`id_facultad`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (1, 1, 'Ingeniería Informática');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (2, 1, 'Quimica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (3, 17, 'Medicina');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (4, 2, 'Enfermeria');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (5, 1, 'Fisica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (7, 12, 'Ingeniería en Geodesia y Topografía');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (8, 7, 'Turismo - Uyuni');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (9, 7, 'Trabajo Social - Uncia');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (10, 7, 'Turismo');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (11, 7, 'Lingüística e Idiomas');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (12, 7, 'Trabajo Social');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (13, 7, 'Lingüística e Idiomas - Uyuni');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (14, 8, 'Ingeniería Agropecuaria - Villazon');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (15, 8, 'Med. Veterinaria y Zootecnia - Tupiza');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (16, 8, 'Ingeniería Agronomica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (17, 8, 'Ingeniería AgroIndustrial');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (18, 8, 'Ingeniería en Desarrollo Rural');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (19, 12, 'Ingeniería Civil');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (20, 12, 'Construcciones Civiles');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (21, 2, 'Enfermería - Villazon');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (22, 14, 'Artes Musicales');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (23, 14, 'Artes Plásticas');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (24, 1, 'Estadistica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (25, 1, 'Matemática');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (26, 1, 'Ingeniería de Sistemas');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (27, 15, 'Ingeniería Geológica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (28, 15, 'Ingeniería del Medio Ambiente');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (29, 13, 'Economía - Uyuni');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (30, 13, 'Administración de Empresas');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (31, 13, 'Economía - Uncia');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (32, 13, 'Contabilidad y Finanzas');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (33, 13, 'Economía');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (34, 13, 'Auditoria - Contaduría Publica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (35, 13, 'Contaduría Publica - Tupiza');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (36, 16, 'Derecho');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (37, 16, 'Derecho - Uncia');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (38, 5, 'Ingeniería Minera');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (39, 5, 'Ingeniería de Procesos de Materias Primas Minerales');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (40, 18, 'Ingeniería Eléctrica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (41, 18, 'Mecánica Automotriz');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (42, 18, 'Ingeniería Electrónica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (43, 18, 'Ingeniería Mecánica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (44, 18, 'Ingeniería Mecatronica');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (45, 14, 'Arquitectura');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (46, 7, 'Comunicación Social');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (47, 17, 'Odontología ');
INSERT INTO `carrera` (`id_carrera`, `id_facultad`, `nombre_carrera`) VALUES (48, 13, 'Ingeniería Comercial');


#
# TABLE STRUCTURE FOR: convenios
#

DROP TABLE IF EXISTS `convenios`;

CREATE TABLE `convenios` (
  `id_convenios` int(30) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` longtext NOT NULL,
  `tipo_convenio` int(30) NOT NULL,
  `id_usuario` int(30) NOT NULL,
  PRIMARY KEY (`id_convenios`),
  KEY `tipo_convenio` (`tipo_convenio`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `convenios` (`id_convenios`, `titulo`, `fecha`, `descripcion`, `tipo_convenio`, `id_usuario`) VALUES (1, 'CONVENIOS NACIONALES 2010 - 2014', '2019-06-03', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL NACIONAL 2010 - 2014 Se establecieron alianzas de cooperación con instituciones para el desarrollo de actividades conjuntas que promueven, canalizan, distintas posibilidades para realizar prácticas en la industria y modalidades de graduación e investigación.', 2, 1);
INSERT INTO `convenios` (`id_convenios`, `titulo`, `fecha`, `descripcion`, `tipo_convenio`, `id_usuario`) VALUES (2, 'CONVENIOS REGIONALES', '2019-05-13', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL REGIONAL.- La suscripción de convenios interinstitucionales responde a los lineamientos planteados en la política de vinculación con nuestro medio y responsabilidad social de la Universidad Técnica de Oruro.', 3, 1);
INSERT INTO `convenios` (`id_convenios`, `titulo`, `fecha`, `descripcion`, `tipo_convenio`, `id_usuario`) VALUES (3, 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL INTERNACIONAL GESTION 2015', '2019-04-23', 'CONVENIOS DE COOPERACIÓN GESTIONADOS A NIVEL INTERNACIONAL GESTION 2015 Se establecieron alianzas de cooperación con instituciones para el desarrollo de actividades conjuntas que promueven, canalizan, distintas posibilidades para realizar intercambios cooperación y modalidades de graduación e investigación Docente-Estudiantil.', 1, 1);
INSERT INTO `convenios` (`id_convenios`, `titulo`, `fecha`, `descripcion`, `tipo_convenio`, `id_usuario`) VALUES (10, 'hhhhh', '2019-10-18', '<p>jhgjgjg</p>\r\n\r\n<ul>\r\n	<li>kj</li>\r\n</ul>\r\n', 1, 0);


#
# TABLE STRUCTURE FOR: convocatoria
#

DROP TABLE IF EXISTS `convocatoria`;

CREATE TABLE `convocatoria` (
  `id_convocatoria` int(100) NOT NULL AUTO_INCREMENT,
  `id_tipo_convocatoria` int(100) NOT NULL,
  `titulo` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `resumen` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `requerimiento` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_final` date NOT NULL,
  `archivo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_convocatoria`),
  KEY `id_tipo_convocatoria` (`id_tipo_convocatoria`),
  KEY `id_tipo_convocatoria_2` (`id_tipo_convocatoria`),
  CONSTRAINT `convocatoria_ibfk_1` FOREIGN KEY (`id_tipo_convocatoria`) REFERENCES `tipo_convocatoria` (`id_tipo_convocatoria`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `convocatoria` (`id_convocatoria`, `id_tipo_convocatoria`, `titulo`, `descripcion`, `resumen`, `requerimiento`, `fecha_inicio`, `fecha_final`, `archivo`, `estado`) VALUES (1, 1, 'CONVOCATORIA ELABORACIÓN DE ARTÍCULOS PARA LA REVISTA CIENTÍFICA “CienciaXplora” DE LA DICyT', 'algo breve ', 'hhchsch hsdjgjhs bjsbhdjsndjkhsd sjdfnsjkdfhsjdnfsd sjdnskjdnsjkd sdisjdlkjshdklsjd skjslkdjalkhd fskdjksdfkljsf sjkdfnsjkdfskmfks ksjdslkjdlksd skdjsn dksd sjkns djs ksjdkjssnms  skj kjsksldklmslkjsdmf ksmjksklskd ksjdmslkdlskdlsm,d nk sjsnd sjkdmslkjlksjds\r\ndlkksjd\r\nk }{+sndjk´sjo lsjk suid s dk sd jks dkjs dkjsjdkjsh\'0kjshksnjd6jkhsjhq1|asdfgbnmñ{\r\n', 'con experiencia de 2 años medio pudiente y que sea menor de 20 años', '2019-01-01', '2019-01-31', 'conv_tra_inv.jpg', '1');
INSERT INTO `convocatoria` (`id_convocatoria`, `id_tipo_convocatoria`, `titulo`, `descripcion`, `resumen`, `requerimiento`, `fecha_inicio`, `fecha_final`, `archivo`, `estado`) VALUES (2, 2, 'nivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japon', 'tambien algo breve', 'nivel master en ciencias técnicas (administración de tecnología) Universidgdfgd hdhhnnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japon nivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japon vnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonvvvvvnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yamagata-Japonnivel master en ciencias técnicas (administración de tecnología) Universidad estatal de Yam', 'que no sea gilberto gegegeg', '2019-01-01', '2019-01-18', 'conv_bec.jpg', '1');
INSERT INTO `convocatoria` (`id_convocatoria`, `id_tipo_convocatoria`, `titulo`, `descripcion`, `resumen`, `requerimiento`, `fecha_inicio`, `fecha_final`, `archivo`, `estado`) VALUES (3, 1, 'kjhkjhkjhkkjhkjh', 'kjhkjhjk', 'kjhkjhkjh', 'khkjhkjhjkh', '2019-06-07', '2019-06-29', 'carro-fancesa1.png', '1');
INSERT INTO `convocatoria` (`id_convocatoria`, `id_tipo_convocatoria`, `titulo`, `descripcion`, `resumen`, `requerimiento`, `fecha_inicio`, `fecha_final`, `archivo`, `estado`) VALUES (4, 1, 'jhkjhk', 'hkjhkjhk', 'jhkjhjk', 'hkjhkjh', '2019-10-10', '2019-10-26', 'Doc1.docx', '1');


#
# TABLE STRUCTURE FOR: detalle_avances
#

DROP TABLE IF EXISTS `detalle_avances`;

CREATE TABLE `detalle_avances` (
  `id_detalle` int(30) NOT NULL AUTO_INCREMENT,
  `id_avance` int(30) NOT NULL,
  `id_usuario` int(30) NOT NULL,
  `archivo` varchar(200) NOT NULL,
  `fecha` date NOT NULL,
  `puntage` int(30) NOT NULL,
  `estado` int(30) NOT NULL,
  `avance` varchar(30) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_avance` (`id_avance`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `detalle_avances` (`id_detalle`, `id_avance`, `id_usuario`, `archivo`, `fecha`, `puntage`, `estado`, `avance`) VALUES (1, 1, 1, '', '2019-06-09', 23, 0, '12');
INSERT INTO `detalle_avances` (`id_detalle`, `id_avance`, `id_usuario`, `archivo`, `fecha`, `puntage`, `estado`, `avance`) VALUES (2, 4, 1, 'dana.pdf', '2019-10-18', 0, 1, '');
INSERT INTO `detalle_avances` (`id_detalle`, `id_avance`, `id_usuario`, `archivo`, `fecha`, `puntage`, `estado`, `avance`) VALUES (3, 6, 1, 'Doc1.docx', '2019-10-18', 0, 1, '');


#
# TABLE STRUCTURE FOR: estado_facultad
#

DROP TABLE IF EXISTS `estado_facultad`;

CREATE TABLE `estado_facultad` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `estado` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `estado_facultad` (`id`, `estado`) VALUES (1, 'Activo');
INSERT INTO `estado_facultad` (`id`, `estado`) VALUES (2, 'Inactivo');


#
# TABLE STRUCTURE FOR: eventos
#

DROP TABLE IF EXISTS `eventos`;

CREATE TABLE `eventos` (
  `id_evento` int(100) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_final` datetime NOT NULL,
  `color` varchar(30) NOT NULL,
  `link` varchar(200) NOT NULL,
  `color_texto` varchar(30) NOT NULL,
  PRIMARY KEY (`id_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (1, 'Primer Avance', '2019-06-03 10:00:00', '2019-06-17 18:00:00', '#00FF00', '', '#FFFFFF');
INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (2, 'Entrega Final', '2019-12-01 12:00:00', '2019-12-07 00:00:00', '#FF0000', 'calendario_modal/ver/', '#FFFFFF');
INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (3, 'avance tres', '2019-07-08 00:00:00', '2019-07-11 00:00:00', '#FF0000', '', '#FFFFFF');
INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (6, 'bbb', '2019-10-17 12:00:00', '2019-10-21 00:00:00', '#00CCFF', 'calendario_modal/ver/', '#FFFFFF');
INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (7, 'Pre inscripción y confirmación 1ra Prueba de Suficiencia Académica 1/2019', '2018-10-01 00:00:00', '2018-11-13 00:00:00', '#00FF00', '', '#FFFFFF');
INSERT INTO `eventos` (`id_evento`, `titulo`, `fecha_inicio`, `fecha_final`, `color`, `link`, `color_texto`) VALUES (8, 'ACTIVIDADES ACADÉMICAS', '2019-02-08 00:00:00', '2019-12-16 00:00:00', '#00FF00', '', '#FFFFFF');


#
# TABLE STRUCTURE FOR: facultades
#

DROP TABLE IF EXISTS `facultades`;

CREATE TABLE `facultades` (
  `id_facultad` int(100) NOT NULL AUTO_INCREMENT,
  `nombre_facultad` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `imagen` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `imagenr` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_facultad`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (1, 'Ciencias Puras', 1, 'puras.png', 'ciencias puras.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (2, 'Ciencias de la Salud', 1, 'enfermeria.png', 'enfermeria.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (5, 'Ingeniería Minera', 1, 'minera.png', 'minas.jpeg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (7, 'Ciencias Sociales y Humanisticas', 1, 'humanisticas.png', 'humanisticas.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (8, 'Ciencias Agrícolas y Pecuarias', 1, 'agronomia.png', 'agro.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (12, 'Ingeniería', 1, 'ingenieria.png', 'ingenieria.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (13, 'Ciencias Económicas Financieras y Administrativas', 1, 'economia.png', 'Economia.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (14, 'Artes', 1, 'artes.png', 'artes.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (15, 'Ingeniería Geológica', 1, 'geologia.png', 'geologia.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (16, 'Derecho', 1, 'derecho.png', 'derecho.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (17, 'Medicina', 1, 'medicina.png', 'medicina.jpg');
INSERT INTO `facultades` (`id_facultad`, `nombre_facultad`, `estado`, `imagen`, `imagenr`) VALUES (18, 'Ingeniería Tecnológica', 1, 'tecnica.png', 'tecnologica.jpg');


#
# TABLE STRUCTURE FOR: fotos_publicaciones
#

DROP TABLE IF EXISTS `fotos_publicaciones`;

CREATE TABLE `fotos_publicaciones` (
  `id_foto` int(10) NOT NULL AUTO_INCREMENT,
  `id_publicacion` int(10) NOT NULL,
  `nombre_foto` varchar(100) NOT NULL,
  PRIMARY KEY (`id_foto`),
  KEY `cod_publicacion` (`id_publicacion`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mensajes
#

DROP TABLE IF EXISTS `mensajes`;

CREATE TABLE `mensajes` (
  `id_mensaje` int(20) NOT NULL AUTO_INCREMENT,
  `id_emisor` int(20) NOT NULL,
  `id_remitente` int(20) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `mensaje` longtext NOT NULL,
  `fecha` datetime NOT NULL,
  `archivo` varchar(100) NOT NULL,
  `leido` tinyint(4) NOT NULL,
  `eliminado` int(4) NOT NULL,
  `fecha_borrado` datetime NOT NULL,
  PRIMARY KEY (`id_mensaje`),
  KEY `id_emisor` (`id_emisor`),
  KEY `id_remitente` (`id_remitente`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `mensajes` (`id_mensaje`, `id_emisor`, `id_remitente`, `titulo`, `mensaje`, `fecha`, `archivo`, `leido`, `eliminado`, `fecha_borrado`) VALUES (1, 1, 7, 'no se ', '<p>positivo</p>', '2019-03-08 00:00:00', '', 1, 1, '0000-00-00 00:00:00');
INSERT INTO `mensajes` (`id_mensaje`, `id_emisor`, `id_remitente`, `titulo`, `mensaje`, `fecha`, `archivo`, `leido`, `eliminado`, `fecha_borrado`) VALUES (3, 5, 1, 'entra', '<p>nada</p><h1>prr</h1>', '2019-03-07 05:05:25', '', 1, 1, '0000-00-00 00:00:00');
INSERT INTO `mensajes` (`id_mensaje`, `id_emisor`, `id_remitente`, `titulo`, `mensaje`, `fecha`, `archivo`, `leido`, `eliminado`, `fecha_borrado`) VALUES (4, 1, 7, 'prueba de ', '<p>hora y algo asi</p>', '2019-03-08 02:45:57', '', 1, 1, '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: personal
#

DROP TABLE IF EXISTS `personal`;

CREATE TABLE `personal` (
  `id_personal` int(100) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_pat` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellido_mat` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `id_cargo` int(100) NOT NULL,
  `correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `ci` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_personal`),
  KEY `id_cargo` (`id_cargo`),
  KEY `id_cargo_2` (`id_cargo`),
  CONSTRAINT `personal_ibfk_1` FOREIGN KEY (`id_cargo`) REFERENCES `cargo` (`id_cargo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `personal` (`id_personal`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `id_cargo`, `correo`, `ci`, `direccion`, `imagen`) VALUES (1, 'Ing. César Luis', 'Viscarra ', 'Pinto', 1, 'cluis@hotmail.com', '12345678', 'Calle Camargo #45', 'avatar.png');
INSERT INTO `personal` (`id_personal`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `id_cargo`, `correo`, `ci`, `direccion`, `imagen`) VALUES (2, 'Javier Gabriel', 'Rodriguez', 'Rojas', 2, 'rrfranz@gmail.com', '87654321', 'Av. Duarte #12', 'avatar2.png');
INSERT INTO `personal` (`id_personal`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `id_cargo`, `correo`, `ci`, `direccion`, `imagen`) VALUES (3, 'Lic. Manuel Fernando', 'Torrez', 'Pacara', 4, 'manuelpt@hotmail.com', '344199383', 'Calle Camargo # 24', 'avatar04.png');
INSERT INTO `personal` (`id_personal`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `id_cargo`, `correo`, `ci`, `direccion`, `imagen`) VALUES (5, 'hhhhhb', 'hhhh', 'hhhh', 2, 'bbb@bbb.com', '1231313131', 'skjhfsjhf', 'tecnica.png');


#
# TABLE STRUCTURE FOR: portada
#

DROP TABLE IF EXISTS `portada`;

CREATE TABLE `portada` (
  `id_portada` int(100) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(200) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `usuario` int(10) NOT NULL,
  PRIMARY KEY (`id_portada`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (3, '1.jpg', 'TECNOLOGÍA EN TUS MANOS', 'Para un buen Futuro', 1);
INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (4, '2.jpg', 'UNA VISIÓN HACIA EL FUTURO', 'Disfruta de la tecnológia', 1);
INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (6, '3.jpg', 'BIOTECNOLOGÍA ', 'Mejora la salud con métodos tecnológicos', 1);
INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (7, '4.jpg', 'MICRO-TECNOLOGÍA', 'Para desarrollos espectaculares ', 1);
INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (9, '5.jpg', 'APLICACIÓN AL INSTANTE', 'Para facilidades sin apuros', 1);
INSERT INTO `portada` (`id_portada`, `imagen`, `titulo`, `descripcion`, `usuario`) VALUES (10, 'd7e1725b3801fb6cdeb212884c893f79.jpg', ' LA TECNOLOGíA AVANZADA', 'La Tecnología es algo que no estaba cuando usted nació', 1);


#
# TABLE STRUCTURE FOR: publicacion
#

DROP TABLE IF EXISTS `publicacion`;

CREATE TABLE `publicacion` (
  `id_publicacion` int(30) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` varchar(450) NOT NULL,
  `id_tipo_publi` int(30) NOT NULL,
  `id_usuario` int(30) NOT NULL,
  PRIMARY KEY (`id_publicacion`),
  KEY `id_tipo_publi` (`id_tipo_publi`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `publicacion` (`id_publicacion`, `titulo`, `fecha`, `descripcion`, `id_tipo_publi`, `id_usuario`) VALUES (1, 'Capacidad Científica y Tecnológica de la U.A.T.F. 2016', '2019-06-10', 'Durante la gestión 2016 se ha realizado el relevamiento de información sobre la capacidad instalada en recursos humanos, líneas de trabajo y equipamiento disponible en estas Unidades.', 4, 1);
INSERT INTO `publicacion` (`id_publicacion`, `titulo`, `fecha`, `descripcion`, `id_tipo_publi`, `id_usuario`) VALUES (2, 'kajsbhd', '2019-10-02', '10 – Solicitar algo  11 – Pedir algo  12 – Solicitando algo    Ejemplos de solicitud: Carta de solicitud de información: La mayor parte de las solicitudes de información son de carácter comercial. Solicitamos la información que no aparece en los catálogos, información que no sepamos sobre cualquier producto que queramos comprar.  Por ello este tipo de modelo es un claro ejemplo de cómo solicitar información, en este caso sobre una oferta de baños', 5, 1);


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES (1, 'admin', 'control total');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES (2, 'director', 'control total');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES (3, 'usuario', 'ciertos modulos');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES (4, 'coordinador', 'control medio');


#
# TABLE STRUCTURE FOR: tipo_convenio
#

DROP TABLE IF EXISTS `tipo_convenio`;

CREATE TABLE `tipo_convenio` (
  `id_convenio` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_convenio` varchar(100) NOT NULL,
  PRIMARY KEY (`id_convenio`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tipo_convenio` (`id_convenio`, `nombre_convenio`) VALUES (1, 'Convenios Internacionales');
INSERT INTO `tipo_convenio` (`id_convenio`, `nombre_convenio`) VALUES (2, 'Convenios Nacionales');
INSERT INTO `tipo_convenio` (`id_convenio`, `nombre_convenio`) VALUES (3, 'Convenios Regionales');


#
# TABLE STRUCTURE FOR: tipo_convocatoria
#

DROP TABLE IF EXISTS `tipo_convocatoria`;

CREATE TABLE `tipo_convocatoria` (
  `id_tipo_convocatoria` int(100) NOT NULL AUTO_INCREMENT,
  `nombre_tipo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_tipo_convocatoria`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipo_convocatoria` (`id_tipo_convocatoria`, `nombre_tipo`) VALUES (1, 'Convocatoria de Investigacion');
INSERT INTO `tipo_convocatoria` (`id_tipo_convocatoria`, `nombre_tipo`) VALUES (2, 'Convocatoria a Becas');


#
# TABLE STRUCTURE FOR: tipo_investigador
#

DROP TABLE IF EXISTS `tipo_investigador`;

CREATE TABLE `tipo_investigador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_investigador` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tipo_investigador` (`id`, `nombre_investigador`) VALUES (1, 'Trabajo Docente');
INSERT INTO `tipo_investigador` (`id`, `nombre_investigador`) VALUES (2, 'Trabajo Estudiante');
INSERT INTO `tipo_investigador` (`id`, `nombre_investigador`) VALUES (3, 'Proyecto de Investigación');


#
# TABLE STRUCTURE FOR: tipo_publicacion
#

DROP TABLE IF EXISTS `tipo_publicacion`;

CREATE TABLE `tipo_publicacion` (
  `id_tipo_publi` int(30) NOT NULL AUTO_INCREMENT,
  `nombre_publicacion` varchar(100) NOT NULL,
  PRIMARY KEY (`id_tipo_publi`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tipo_publicacion` (`id_tipo_publi`, `nombre_publicacion`) VALUES (1, 'articulos');
INSERT INTO `tipo_publicacion` (`id_tipo_publi`, `nombre_publicacion`) VALUES (2, 'boletines');
INSERT INTO `tipo_publicacion` (`id_tipo_publi`, `nombre_publicacion`) VALUES (3, 'feria nacional');
INSERT INTO `tipo_publicacion` (`id_tipo_publi`, `nombre_publicacion`) VALUES (4, 'noticias y eventos');
INSERT INTO `tipo_publicacion` (`id_tipo_publi`, `nombre_publicacion`) VALUES (5, 'revistas');


#
# TABLE STRUCTURE FOR: trabajo_investigacion
#

DROP TABLE IF EXISTS `trabajo_investigacion`;

CREATE TABLE `trabajo_investigacion` (
  `id_investigacion` int(100) NOT NULL AUTO_INCREMENT,
  `id_facultad` int(100) NOT NULL,
  `id_carrera` int(100) NOT NULL,
  `titulo_investigacion` varchar(2000) COLLATE utf8_spanish_ci NOT NULL,
  `autor` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_investigador` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `objetivo_general` varchar(3000) COLLATE utf8_spanish_ci NOT NULL,
  `resumen` varchar(5000) COLLATE utf8_spanish_ci NOT NULL,
  `conclusiones` varchar(5000) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `archivo` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `nombre_autor` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `gestion` int(11) NOT NULL,
  `visitas` int(11) NOT NULL,
  `tutor` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_investigacion` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_investigacion`),
  KEY `id_facultad` (`id_facultad`),
  KEY `id_carrera` (`id_carrera`),
  KEY `id_facultad_2` (`id_facultad`),
  KEY `id_carrera_2` (`id_carrera`),
  KEY `tipo_investigador` (`tipo_investigador`),
  CONSTRAINT `trabajo_investigacion_ibfk_1` FOREIGN KEY (`id_facultad`) REFERENCES `facultades` (`id_facultad`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `trabajo_investigacion_ibfk_2` FOREIGN KEY (`id_carrera`) REFERENCES `carrera` (`id_carrera`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (1, 7, 11, 'LA ENSEÑANZA DE LA LENGUA QUECHUA EN EL SISTEMA EDUCATIVO DE LA ESCUELA SAN CRISTOBAL DE LA CIUDAD DE POTOSÍ', '1', '2', '<p>&ldquo;Elaborar un plan nacional para la implementaci&oacute;n de la ense&ntilde;anza de la lengua quechua, desde primero a sexto de primaria, en la unidad educativa San Crist&oacute;bal de la ciudad de potos&iacute;&rdquo;</p>\r\n', '<p>En el presente trabajo de investigaci&oacute;n, se analizara todos los factores que influyen negativamente en el proceso de aprendizaje del idioma quechua en estudiantes de la unidad educativa &ldquo;San Crist&oacute;bal de la ciudad de Potos&iacute;&rdquo;.</p>\r\n\r\n<p>Para ello, en primer lugar, se analizaran las diferentes t&eacute;cnicas, estrategias metodol&oacute;gicas y did&aacute;cticas de los docentes del idioma quechua como as&iacute; mismo aspectos que tienen que ver con el rol y entorno del estudiante, ya que las aptitudes del estudiante dentro de lo que es la adquisici&oacute;n u aprendizaje de una determina idioma, depende en gran parte de la subjetividad del estudiante. Al respecto, se presenta la siguiente hip&oacute;tesis Con la aplicaci&oacute;n de m&eacute;todos y t&eacute;cnicas m&aacute;s din&aacute;micos en la ense&ntilde;anza de una segunda lengua como el quechua, mejorara el nivel acad&eacute;mico y manejo de la segunda lengua en los estudiantes de la menci&oacute;n quechua. Teniendo presente esta situaci&oacute;n, se busca establecer cu&aacute;les son las mejores t&eacute;cnicas, m&eacute;todos, estrategias, que deben ser utilizados por los docentes a momento de proceder a ense&ntilde;ar el idioma quechua y dentro de que circunstancias o contexto deben ser empleadas.</p>\r\n', '<p>En el presente capitulo se presentan las conclusiones y propuestas que tienen como prop&oacute;sito eficientizar el proceso de ense&ntilde;anza-aprendizaje en las distintas clases de ingl&eacute;s en sus diferentes modalidades, mediante el uso del material autentico.</p>\r\n\r\n<p>Respecto a la percepci&oacute;n de los alumnos acerca de la planeaci&oacute;n del trabajo docente, se puede constatar que efectivamente la planificaci&oacute;n de la clase de ingl&eacute;s regularmente se lleva a cabo, no obstante se deja entrever de que es una actividad que requiere consolidar su funci&oacute;n.</p>\r\n\r\n<p>As&iacute; mismo se puede observar que por lo general el profesor realiza una planeaci&oacute;n escrita de sus clases, sin embargo es necesario reforzar esta tarea ya que no se refleja en su totalidad en el aula. Por otra parte se aprecia que el profesorado opina que efectivamente, la planificaci&oacute;n de la clase de ingl&eacute;s se lleva a cabo en su totalidad. De igual manera, seg&uacute;n su apreciaci&oacute;n se puede concluir que en el mayor de los casos, el docente lleva a cabo la definici&oacute;n de estrategias que llevara a cabo durante la clase, no obstante, existe casi una quinta parte de los profesores que opina que solo algunas veces efect&uacute;an esta tarea. Los profesores de ingl&eacute;s refieren que, en dicha planeaci&oacute;n definen los materiales que usan en el desarrollo de la clase, lo cual les permite tener un mejor control sobre los apoyos que utiliza en el aula.</p>\r\n', '2019-07-19', 'dicyt_2019_07_19_20_18_13.pdf', 'UNIV. OMAR CONDORI MENACHO', 2018, 3, 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (2, 13, 35, 'ANALISIS ECONOMICO DEL SALARIO MINIMO NACIONAL, EN RELACION A LA SATISFACCION DE NECESIDADES DE LAS FAMILIAS DE TUPIZA DEL BARRIO  SAN ANTONIO EN LA GESTIÓN 2018', '1', '2', 'Determinar en qué medida se satisfacen las Necesidades Básicas de las familias de Tupiza el Salario Mínimo Nacional.', 'El trabajo de investigación estará direccionado a poder lograr realizar un análisis de la economía en Bolivia reflejada en la ciudad de Tupiza en el barrio de San Antonio, el mismo que de acuerdo a lo establecido el 1 de mayo de 2018 por el gobierno un mínimo nacional de 2060 bolivianos y en relación al artículo 23 de los Derechos Humanos esa escala sería necesario para poder cubrir todas las necesidades de las familias de Tupiza.   Así mismo se realizara el estudio de investigación en ocho familias diferentes dos parejas sin hijos pero la diferencia de una con la otra será que en un círculo familiar solo existirá un ingreso económico y en el otro caso existirán dos ingresos económicos, en dos familias con un hijo que al igual que el caso anterior por un lado existirá un solo ingreso económico y por otro lado existirán dos ingresos económicos, en dos familias con dos hijos que al igual que el caso anterior por un lado existirá un solo ingreso económico y por otro lado existirán dos ingresos económicos y en dos familias con tres hijos que al igual que el caso anterior por un lado existirá un solo ingreso económico y por otro lado existirán dos ingresos económicos.   Las encuestas aplicadas nos direccionaran a determinar cuál son las necesidades familiares más indispensables para que después de la recolección de datos logremos realizar un análisis de todo lo expuesto en relación al salario mínimo nacional.', '	La Familia es la estructuración de la unión de dos culturas diferentes en función de manifestar una nueva cultura, que prioriza como necesidades familiares la alimentación, la salud y la educación. 	Las necesidades básicas a manera específica en las familias del barrio de San Antonio de la ciudad de Tupiza son los siguientes: Alimentación, transporte; comunicación, agua, luz, alquileres, educación, salud, etc. Los costos más elevados en alimentación son las tres comidas diarias con un gasto en el desayuno, almuerzo y la cena considerando que solo estos alimentos se los consume en casa. 	De acuerdo con lo establecido como salario mínimo para la gestión 2018 consideramos que las necesidades familiares son basta y el salario mínimo no abastece para cubrir las mismas.', '2019-07-19', 'dicyt_2019_07_19_22_33_18.pdf', 'UNIV. MARCIA ROSA LUZ GARCíA VALDEZ', 2018, 0, 'LIC. AMADEO CONDOR', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (3, 8, 14, 'USO DE FILTROS BIOLÓGICOS (BIO-FILTROS) PARA LA REMOCIóN DE NUTRIENTES EN AGUAS GRISES, CON ESPECIES FORRAJERAS; GRAMíNEAS Y LEGUMINOSAS ADAPTADAS AL MUNICIPIO DE VILLAZON', '1', '2', 'Usar Filtros biológicos (bio-filtros) para la remoción de nutrientes en aguas grises, con especies forrajeras; gramíneas y leguminosas adaptadas al municipio de villazon.', 'En la calle chichas 10 entre mojo a 50 metros del rio internacional se llevó a cabo el Uso Filtros biológicos (bio-filtros) para la remoción de nutrientes en aguas grises, con especies forrajeras; gramíneas y leguminosas adaptadas al municipio de villazon. Disminuir el grado de contaminación por aguas servidas con la utilización de biofiltros. Adaptabilidad de las especies forrajeras. Adaptabilidad de este método bajo estas condiciones climatológicas dado q el método usado es muy frecuente en la zona centroamericana. Análisis de aguas al inicio y al final del proceso Es un trabajo que determina la importancia de tratar aguas residuales con el fin de cuidar y preservar el medio ambiente, este trabajo de investigación dio como resultado que los biofiltros empleados para tratar las aguas grises son los siguientes.  El uso de bio filtros con leguminosas resulta más efectivo para la remoción de nutrientes en aguas grises  El desperdicio total de agua gris o sucia fue de 4363,075 litros de agua en los meses de agosto, septiembre, octubre, noviembre y diciembre.  Se redujo de 2790 milibares a un 576,10 milibares con las leguminosas teniendo un 79,35% con relación al agua gris y un 11,58 % con relación al agua potable y su acercamiento a la neutralidad esto en las leguminosas.  Se redujo de 2790 milibares a un 666,30 milibares con las gramíneas teniendo un 76,12 % con relación al agua gris y un 30,80 % con relación al agua potable y su acercamiento a la neutralidad esto en las gramíneas.  se redujo en buen tamaño el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,20 de pH neutro ligero con relación al patrón de referencia 7 en leguminosas.  se redujo en buen tamaño el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,36 de pH neutro ligero con relación al patrón de referencia 7 en gramíneas.  El uso de filtros biológicos confirma la efectividad y la necesidad de implantar filtros biológicos en domicilios cercanos a ríos, vertientes, lagunas, lagos, etc. Con el fin de reducir el impacto ambiental  Los filtros biológicos pueden funcionar como jardines para especies florales en el caso de las leguminosas.', ' El uso de bio filtros con leguminosas resulta más efectivo para la remoción de nutrientes en aguas grises  El desperdicio total de agua gris o sucia fue de 4363,075 litros de agua en los meses de agosto, septiembre, octubre, noviembre y diciembre.  Se redujo de 2790 milibares a un 576,10 milibares con las leguminosas teniendo un 79,35% con relación al agua gris y un 11,58 % con relación al agua potable y su acercamiento a la neutralidad esto en las leguminosas.  Se redujo de 2790 milibares a un 666,30 milibares con las gramíneas teniendo un 76,12 % con relación al agua gris y un 30,80 % con relación al agua potable y su acercamiento a la neutralidad esto en las gramíneas.  se redujo en buen tamaño el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,20 de pH neutro ligero con relación al patrón de referencia 7 en leguminosas.  se redujo en buen tamaño el pH alcalino de provocado por aguas grises cuyo origen son los detergentes, teniendo un pH de 9, 47 hasta llegar a un pH de 7,36 de pH neutro ligero con relación al patrón de referencia 7 en gramíneas.  El uso de filtros biológicos confirma la efectividad y la necesidad de implantar filtros biológicos en domicilios cercanos a ríos, vertientes, lagunas, lagos, etc. Con el fin de reducir el impacto ambiental  Los filtros biológicos pueden funcionar como jardines para especies florales en el caso de las leguminosas.', '2019-07-19', 'dicyt_2019_07_19_22_32_56.pdf', 'UNIV. ALFONSO YVER GÓMEZ ARACA', 2018, 1, 'no disponible', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (4, 18, 44, 'AUTOMATIZACIÓN DE SELLADORA PARA BOLSAS DE PAN', '1', '2', 'Desarrollar una maquina semiautomática de sellado que sea capaz de consumir menos tiempo y desperdiciar menos material que la maquina actual.', 'La Automatización es la aplicación de diferentes tecnologías para controlar un proceso, maquina, aparato o dispositivo que por lo regular cumple funciones o tareas repetitivas, haciendo que opere automáticamente, reduciendo al mínimo la intervención humana. Lo que se busca con la Automatización es generar la mayor cantidad de producto, en el menor tiempo posible, con el fin de reducir los costos y garantizar una uniformidad en la calidad. La Automatización es posible gracias a la unión de distintas tecnologías, por ejemplo la olehidraulica, la neumática, los servos y los motores son los encargados del movimiento, nos ayudan a realizar esfuerzos físicos (mover una bomba, prensar o desplazar un objeto), los sensores nos indican lo que está sucediendo con el proceso, donde se encuentra en un momento determinado y dar la señal para que siga el siguiente paso, los sistemas de comunicación enlazan todas las partes y los Controladores Lógicos Programables o por sus siglas PLC se encargan de controlar que todo tenga una secuencia, toma decisiones de acuerdo a una programación pre establecida, se encarga de que el proceso cumpla con una repetición, a esto debemos añadir otras tecnologías como el vacío, la robótica, telemetría y otras más.', 'Las alternativas seleccionadas para desarrollar la construcción del prototipo fueron las correctas debido a que cada sistema satisface a los requerimientos impuestos por la empresa. Todos los elementos que conforman la máquina están diseñados bajo parámetros y criterios que permiten a la máquina un mejor desempeño, rendimiento fiabilidad. Además de que son de fácil mantenimiento y control. Una vez realizado el análisis económico de la máquina se concluye que la máquina cumple con las expectativas de la empresa y la inversión se recupera en un año y medio. Además el costo de fabricación es menor a máquinas de similares características. La simulación en programa ANSYS facilito obtener algunas variables fundamentales para el correcto funcionamiento de la máquina como es la velocidad y su transferencia de calor, de ésta manera se puede obtener un sellado óptimo y se evita el desperdicio de material en pruebas. Se logró comprobar los resultados de los cálculos y análisis de Ansys Workbench con la pruebas realizadas, ya que variando uno de los parámetros dados en los cálculos se obtienen errores en las pruebas de sellado. Un ejemplo claro es al variar la temperatura, si se alcanza una temperatura mayor a la temperatura de operación del polipropileno biorientado hace que se queme y si la temperatura es menor el sellado no es el óptimo. En el ensamble es importante la alineación y lubricación correcta de los elementos de transmisión, ya que la mala ubicación de los mismos provoca un incremento en el torque del motor ocasionando su sobrecalentamiento o posibles trabas en los mecanismos.', '2019-07-19', 'dicyt_2019_07_19_22_31_55.pdf', 'UNIV BEYMAR DANY LAIME RAMOS', 2018, 4, 'ING. BERGMAN CARRASCO URIONA', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (5, 18, 42, 'AUTOMATIZACIÓN Y MONITOREO DEL INVERNADERO DE LA LOCALIDAD DE CHAQUI', '1', '2', '<p>Implementar un sistema para automatizar y monitorear un invernadero el cual nos permita ajustar las variables de temperatura, humedad y realice el riego autom&aacute;tico, los cuales se controlen por PID mediante un PLC y se supervisen mediante un sistema SCADA para el Invernadero de la localidad de Chaqui.</p>\r\n', '<p>El proyecto consiste en realizar la automatizaci&oacute;n y monitoreo de un invernadero localizado en Chaqui, dentro de un invernadero es posible obtener condiciones artificiales de microclima, y con ello cultivar plantas fuera de estaci&oacute;n en condiciones &oacute;ptimas, al no estar expuesto a los cambios dr&aacute;sticos de clima y a las causas naturales, los cultivos que est&eacute;n dentro del invernadero estar&aacute;n totalmente protegidos, as&iacute; tambi&eacute;n lo estar&aacute;n de las posibles plagas o bacterias. El cultivo bajo invernadero siempre ha permitido obtener producciones de primera calidad y mayores rendimientos, en cualquier &eacute;poca del a&ntilde;o.</p>\r\n\r\n<p>Se pretende realizar una investigaci&oacute;n para el desarrollo de la automatizaci&oacute;n y monitorizaci&oacute;n; Para la automatizaci&oacute;n se requieren sensores de humedad, de viento y de<br />\r\ntemperatura y actuadores los cuales trabajaran con variables de temperatura, humedad y viento, realizando un control PID mediante un PLC se pretende establecer las condiciones de forma ideal para el cultivo, permitiendo ingresar un punto de ajuste para cada variable, accionando el riego autom&aacute;tico por goteo, abriendo dos ventanas cenitales y accionando el sistema de ventilaci&oacute;n si la temperatura es alta, o accionando un sistema de calefacci&oacute;n si la temperatura es baja, de esta forma todas estas variables ser&aacute;n monitoreadas por el PLC y llevado a una computadora para su visualizaci&oacute;n mediante un sistema SCADA que facilite la interacci&oacute;n, y supervisi&oacute;n.</p>\r\n', '<ul>\r\n	<li>Los c&aacute;lculos obtenidos nos permiten seleccionar de manera ideal los sensores y/o actuadores requeridos.</li>\r\n	<li>El prototipo funciona de manera ideal accionando los actuadores mediante la lectura de los sensores, aun cuando no fue posible implementar el sistema PID.</li>\r\n	<li>Se obtiene una lectura precisa tanto en el Display como en el sistema Scada realizado en Labview.</li>\r\n	<li>Se pretende tener un impacto econ&oacute;mico al transferir la tecnolog&iacute;a del dise&ntilde;o y desarrollo de invernaderos para mejorar las pr&aacute;cticas agr&iacute;colas.</li>\r\n	<li>Al tener condiciones ambientales controladas en el cultivo bajo invernadero, se garantiza la producci&oacute;n aun con condiciones clim&aacute;ticas adversas como heladas, granizadas, sequ&iacute;as y hasta plagas derivadas de estas condiciones.</li>\r\n	<li>La parte ambiental se ve favorecida, al contar con un riego controlado, se mejorar&aacute; el aprovechamiento del agua, pues solo se usar&aacute; la m&iacute;nima necesaria, de manera que los mantos fri&aacute;ticos no se afectar&iacute;an.</li>\r\n	<li>El sistema de riego automatizado puede ser replicado con componentes accesibles en mercado local e implementado por agricultores.</li>\r\n	<li>En raz&oacute;n que el sistema de riego del invernadero es aut&oacute;nomo, el agricultor puede dedicarse a m&aacute;s labores productivas.</li>\r\n</ul>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_18_38.pdf', 'UNIV. CRISTIAN GADIEL ALARCON CHOQUE', 2018, 0, 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (6, 1, 26, 'SISTEMA DE GESTIÓN BAJO PLATAFORMA WEB PARA UNA MEJOR ADMINISTRACION DE LA INFORMACIÓN EN EL CENTRO DE ESTUDIANTES DE LA CARRERA INGENIERÍA DE SISTEMAS', '1', '2', '<p>NO DISPONIBLE</p>\r\n', '<p>El centro de estudiantes, es el &oacute;rgano natural de representaci&oacute;n, participaci&oacute;n, discusi&oacute;n y organizaci&oacute;n del estamento estudiantil de la carrera de ingenier&iacute;a de sistemas para la defensa y protecci&oacute;n de sus derechos.</p>\r\n\r\n<p>Sin embargo la falta de un sistema que permita procesar y organizar la informaci&oacute;n que se genera de una forma m&aacute;s &aacute;gil y eficaz, dificulta cumplir tal objetivo.</p>\r\n\r\n<p>Debido a lo anteriormente mencionado, surge la necesidad de desarrollar un sistema que logre mejorar y agilizar los procesos implicados en el manejo de informaci&oacute;n del centro de estudiantes de la carrera de ingenier&iacute;a de sistemas.</p>\r\n\r\n<p>Para la elaboraci&oacute;n del sistema y el cumplimiento de los objetivos trazados se utiliz&oacute; la metodolog&iacute;a Scrum. Adem&aacute;s durante la fase de desarrollo se usaron diversas herramientas de las que resaltan el lenguaje de programaci&oacute;n PHP bajo el framework Laravel y el sistema manejador de base de datos MySQL.</p>\r\n\r\n<p>Una vez finalizada la fase de desarrollo y corregidos los errores encontrados durante la fase de pruebas, se procedi&oacute; a la implementaci&oacute;n y capacitaci&oacute;n del personal, concluy&eacute;ndose de esta manera que el proyecto mejora el procesamiento de informaci&oacute;n de estudiantes y por tanto es de utilidad en el logro de los objetivos impuestos.</p>\r\n', '<p>El desarrollo de presente trabajo, permiti&oacute; cumplir las tareas inicialmente planteadas y de esta forma cumplir con el objetivo general trazado, como resultado se obtienen las siguientes conclusiones:</p>\r\n\r\n<ul>\r\n	<li>El marco te&oacute;rico sustenta la presente investigaci&oacute;n, realizado mediante la investigaci&oacute;n, an&aacute;lisis y s&iacute;ntesis de una serie de postulados bibliogr&aacute;ficos de manera que permitan fundamentar las diferentes herramientas utilizadas para el desarrollo del presente proyecto.</li>\r\n	<li>Mediante el diagn&oacute;stico de los procesos de control y seguimiento de la informaci&oacute;n y los m&eacute;todos actuales usados en la realizaci&oacute;n de tareas que componen tales procesos, se pudo determinar que la realizaci&oacute;n de tales procesos se realiza de forma manual, lo cual pod&iacute;a producir informaci&oacute;n poco oportuna y susceptible a fallos.</li>\r\n	<li>La metodolog&iacute;a Scrum, permiti&oacute; la planificaci&oacute;n del presente proyecto, usando para ello las historias de usuario para conformar la pila del producto y de esta formar fijar los requerimientos y posterior inicio de los sprints.</li>\r\n	<li>Se efectu&oacute; la implementaci&oacute;n del sistema propuesto usando el lenguaje de programaci&oacute;n PHP, el framework Laravel 5.5 bajo el patr&oacute;n Modelo-Vista-Controlador y MySQL como gestor de bases de datos, debido a su f&aacute;cil integraci&oacute;n con el resto de las herramientas escogidas.</li>\r\n</ul>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_20_14.pdf', 'UNIV. HERALD CHOQUE VARGAS', 2018, 1, 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (7, 1, 5, 'PROPIEDADES FÍSICAS EN LA APLICACIÓN DE SISTEMAS FOTOVOLTAICO PARA EL CALENTAMIENTO DE AGUA EN VIVIENDAS FAMILIARES', '1', '2', '<p>Cuantificar las propiedades f&iacute;sicas de sistemas fotovoltaico con el fin generar energ&iacute;a el&eacute;ctrica para calentamiento de agua en viviendas familiares en el departamento de Potos&iacute;.</p>\r\n', '<p>En resumen, la corriente entregada a una carga por un diodo semiconductor iluminado es el resultado neto de dos componentes internas de corriente que se oponen:</p>\r\n\r\n<ol>\r\n	<li>La corriente fotogenerada o fotocorriente debida a la generaci&oacute;n de potadores que producen la iluminaci&oacute;n.</li>\r\n	<li>La corriente de diodo o corriente de oscuridad debida a la recombinaci&oacute;n de portadores que producen el voltaje externo necesario para poder entregar a la energ&iacute;a a la carga.</li>\r\n</ol>\r\n\r\n<p>La corriente neta que circula por el exterior vendr&aacute; dada por la suma algebraica de las dos componentes de corriente anteriores. Tomando como positivas las corrientes de generaci&oacute;n, se puede escribir (E., 1994, pp. 64-68):</p>\r\n\r\n<p>Que es la ecuaci&oacute;n caracter&iacute;stica de la c&eacute;lula solar, valida en todos sus rangos de funcionamiento.</p>\r\n', '<p>Se cuantifico las propiedades f&iacute;sicas de sistemas fotovoltaico con el fin generar energ&iacute;a el&eacute;ctrica para calentamiento de agua en viviendas familiares en el departamento de Potos&iacute;.</p>\r\n\r\n<p>Como se puede observar en la Tabla 3.3 y Tabla 3.4 que la radiaci&oacute;n solar se aproxim&oacute; al mapa solar del departamento de Potos&iacute;.</p>\r\n\r\n<p>La utilizaci&oacute;n de la tecnolog&iacute;a fotovoltaica es aplicable para las duchas, vale decir en disminuir carga el&eacute;ctrica, a&uacute;n no se extendi&oacute; y es donde mejor pueden desarrollarse este tipo de sistemas, sin alterar el entorno ni perjudicar la flora y la fauna de la regi&oacute;n, teniendo en cuenta la ubicaci&oacute;n y las condiciones del entorno.</p>\r\n\r\n<p>La implementaci&oacute;n de un sistema solar fotovoltaico, es una soluci&oacute;n a la necesidad energ&eacute;tica continua para la prestaci&oacute;n de los servicios domiciliares, que traer&aacute; una mejora en las condiciones de vida de los pobladores, ya que el servicio que actualmente se tiene presenta muchas deficiencias.</p>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_21_52.pdf', 'UNIV. JUAN JOSE BUHEZO SOTO', 2018, 0, 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (8, 8, 14, 'FORMULACION DE TRES RACIONES ALIMENTICIAS PARA LA GANANCIA DE PESO EN CUYES ( CAVIA PORCELLUS ) EN EL MUNICIPIO DE VILLAZON DE LA PROVINCIA MODESTO OMISTE', '1', '2', 'Formular tres raciones alimenticias y observar cual tiene el mejor efecto en la ganancia de peso en cuyes (Cavia porcellus) en crecimiento.', 'no disponible', ' El consumo de alimento de acuerdo a los datos obtenidos indica que la ración alfalfa + balanceado presenta el mayor dato con 4251 gr. seguida de la ración germinado + balanceado con 4081 gr. Y la ración chala + balanceado presenta un dato inferior con 4074, en cuanto al cuadro ANVA se demostró estadísticamente que no existen diferencias significativas.  En cuanto a ganancia de peso se observa que la ración alfalfa + balanceado presenta mayor dato con 582 gr. seguida de la ración germinado + balanceado con 529,50 gr. Y por último la ración chala + balanceado con 528,50 gr, el cuadro ANVA presenta diferencias significativas entre repeticiones, en la prueba de Duncan se observa la formación de tres grupos significativamente diferentes entre raciones.  En la conversión alimenticia indica que la ración alfalfa + balanceado obtuvo un dato de 7.5, seguido de la ración germinado + balanceado con 7,6 y por último la ración chala + balanceado con 7,7, en el cuadro ANVA indica existen diferencias significativas entre repeticiones, en la prueba Dunkan se observa la formación de tres grupos significativamente diferentes entre las variedades.  En el rendimiento a la carcaza se observa que la racion alfalfa + balanceado tiene un dato de 62% seguido de las raciones germinado + balanceado y chala + balanceado con un dato de 61%, el cuadro ANVA indica que no existen diferencias significativas.  En la relación Beneficio/Costo tomando en cuenta solo en cuenta los gastos de alimentación de los cuyes se tiene un dato de 1.03 Bs lo que nos indica que la actividad de crianza es rentable.', '2019-07-19', 'dicyt_2019_07_19_22_33_56.pdf', 'UNIV. JUAN LEONEL LOPEZ TITO', 2018, 2, 'no disponible', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (9, 13, 35, 'DISEÑO DE UN SISTEMA DE CONTROL DE INVENTARIOS PARA LA EMPRESA CONSTRUCTORA ', '1', '2', 'Diseñar un sistema de control de inventarios para la Empresa Constructora “ECO RAL” S.R.L. El cual permitirá optimizar sus recursos y establecer un control confiable y adecuado a sus necesidades.', 'El presente Trabajo de Investigación corresponde a un Diseño de un Sistema de Control de Inventarios para la Empresa Constructora “ECO RAL” S.R.L., el interés en el desarrollo de este trabajo radica en el estudio de esta Empresa Constructora y específicamente en el control de sus inventarios que es la esencia de su giro. Con la evolución tecnológica, la Empresa se ha visto en la necesidad de prestar mayor atención a la planificación y control de sus inventarios ya que estos constituyen la principal fuente de sus ingresos, de allí que un buen control de los inventarios y su eficiente aplicación garantizará la continuación de la empresa. La situación antes expuesta hace necesario establecer lineamientos que permitan a la empresa un mejor y eficaz control de sus inventarios, es por ello la realización del presente trabajo de investigación, la cual estará orientada al Diseño de un Sistema de Control de Inventarios para la Empresa Constructora “ECO RAL” S.R.L. El objetivo que se plantea es: Diseñar un Sistema de Control de Inventarios para la Empresa Constructora “ECO RAL” S.R.L. El cual permitirá optimizar sus recursos y establecer un control confiable y adecuado a sus necesidades.', 'El diseño de un sistema de control de inventarios en cuanto al manejo de existencias y materiales de la empresa constructora permitirá, visualizar la trayectoria correcta de la información sobre las compras realizadas, evitando trastornos, en la entrega, recepción, almacenamiento, pago y utilización de materiales en la producción o el posible desvío en el uso de los materiales. Con la ejecución del nuevo sistema se logrará llenar las expectativas, los requerimientos y las exigencias por parte de la Empresa, lo cual es indispensable para el desarrollo del sistema y permitirá obtener mejores resultados que se reflejen en los estados financieros, donde se podrá analizar las cuentas y así determinar con firmeza y seguridad cuales deben ser las proyecciones y acciones correctivas que se deben realizar en la empresa. Este Diseño del Sistema de Inventario le garantizara a la empresa una disminución de las fallas, que se presentan dentro del almacén y así llevar una eficiente y exitosa administración de los recursos existentes. Por la importancia que representa los inventarios para la Empresa objeto de estudio, es necesario manejarlos de forma eficiente por medio de sistemas y procedimientos, los cuales permitan obtener el máximo rendimiento de los mismos. La empresa cuenta con medidas empíricas del manejo de los inventarios que no están dentro de un sistema. Lo cual, genera inconvenientes detectados y resumidos en la hoja de hallazgos. En base a este argumento se menciona que es necesario implementar el Diseño de Sistema de Control de Inventarios propuesto con la finalidad de optimizar recursos, evitar robos y fraudes. En la actualidad el flujo de información de sus inventarios es incierto e incorrecto. Por lo que se ha diseñado formatos para cada tipo de movimiento de mercadería esto ayudara a llevar un adecuado control del movimiento de los inventarios. Si no se diseñan procedimientos adecuados y lógicos para el desarrollo de las actividades en el área de Inventarios, se corre el riesgo de que exista duplicidad de tareas, demora en la prestación del servicio a otras áreas, personal innecesario y emisión de información incorrecta, etc. La empresa no cuenta con un encargado de almacenes para el manejo y control de los inventarios. Por lo cual se ha diseñado un manual de funciones detallando las responsabilidades y obligaciones, con el objetivo del manejo correcto de la existencias y materiales. La constante revisión, control y mejoramiento de las normas y procedimientos relacionados con los inventarios de la Empresa de Construcción, mejora la eficiencia de sus operaciones, reduce el riesgo de malversaciones y se obtiene información oportuna y confiable.', '2019-07-19', 'dicyt_2019_07_19_22_31_33.pdf', 'UNIV. REINA REBECA RIVERA HERRERA', 2018, 0, 'LIC. RAUL CADENA TERAN', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (10, 5, 38, 'COMPARACIÓN TÉCNICO ECONÓMICA ENTRE EL TRATAMIENTO ACTIVO CON CAL Y EL SISTEMA PASIVO RAPS EN MINA COLQUECHAQUITA PARA MINIMIZAR LOS CONTAMINANTES DEL DAM', '1', '2', '<ul>\r\n	<li>Comparaci&oacute;n t&eacute;cnico econ&oacute;mico entre el tratamiento activo con cal y el sistema pasivo RAPS en la Mina Colquechaquita para minimizar el DAM</li>\r\n</ul>\r\n', '<p>Los drenajes de aguas &aacute;cidas de minas y los metales asociados a ellas son un problema ambiental y ecol&oacute;gico, por lo que existe la necesidad de aplicar tecnolog&iacute;as basadas en sistemas de tratamiento pasivo.</p>\r\n\r\n<p>El objeto de estudio son las aguas acidas de mina Colquechaquita que se encuentra ubicada a 4600 m.s.n.m. al sud este de la ciudad de Potos&iacute;.</p>\r\n\r\n<p>El trabajo de investigaci&oacute;n:<strong> &ldquo;COMPARACION TECNICO ECONOMICA ENTRE EL TRATAMIENTO ACTIVO CON CAL Y EL SISTEMA PASIVO RAPS EN MINA COLQUECHAQUITA PARA MINIMIZAR LOS CONTAMINANTES DEL DAM&rdquo;</strong> el objetivo es realizar un tratamiento pasivo anaer&oacute;bico a muestras de agua &aacute;cida tomada de la mina Colquechaquita, utilizando caliza y esti&eacute;rcol bovino a nivel de laboratorio para evaluar el comportamiento del pH en este tratamiento.</p>\r\n\r\n<p>Los materiales de relleno propuesto son agentes reductores activos, como la materia org&aacute;nica esti&eacute;rcol de bovino y la caliza como agente neutralizador de la acidez.</p>\r\n\r\n<p>La caliza (CaCO3) es un mineral carbonatado abundante en la zona que consume &aacute;cido a trav&eacute;s de la formaci&oacute;n de bicarbonato (HCO3) o &aacute;cido carb&oacute;nico (H2CO3<img src=\"file:///C:\\Users\\DANAAN~1\\AppData\\Local\\Temp\\msohtmlclip1\\01\\clip_image002.gif\" style=\"height:20px; width:9px\" />) y podemos afirmar que tiende a neutralizar las soluciones llev&aacute;ndolas hasta un pH neutro.</p>\r\n\r\n<p>Para el estudio se dise&ntilde;a un tanque a escala de laboratorio cuyo volumen es de veinte litros, en la parte inferior se rellena con graba de caliza y en la parte superior se complementa con esti&eacute;rcol de bovino, y hace discurrir un flujo de agua &aacute;cida en forma descendente por la parte inferior se toma la muestra para analizar el par&aacute;metro pH.</p>\r\n\r\n<p>Los resultados obtenidos de esta investigaci&oacute;n nos llevaran a la comparaci&oacute;n t&eacute;cnico econ&oacute;mica entre el sistema actual que realizan que es el de tratamiento activo con cal.</p>\r\n', '<ul>\n	<li>Dentro de las pruebas realizadas en laboratorio (sistema de reducci&oacute;n de alcalinidad escala laboratorio), se concluye que el uso de estas servir&aacute; para tomarlo encuentra como un tratamiento primario, en cuanto se refiere a un tratamiento pasivo de RAPS de la mina Colquechaquita se ha logrado elevar el ph de 2-3 inicial a ph de 5-6 en promedio total.</li>\n	<li>Dentro de los factores que influyen en el sistema de tratamiento son el caudal, tama&ntilde;o de grano, en funci&oacute;n a estas se tendr&aacute;n resultados y logrando una mejor reacci&oacute;n qu&iacute;mica.</li>\n</ul>\n', '2019-07-19', 'dicyt_2019_07_19_22_17_36.docx', 'UNIV. RENE VILLCA CRUZ', 2018, 1, 'NO DISPONIBLE', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (11, 13, 35, 'INFLUENCIA DEL ESTRÉS EN EL RENDIMIENTO ACADÉMICO EN LOS ESTUDIANTES DE LA UNIVERSIDAD AUTÓNOMA ', '1', '2', 'Determinar la influencia del .estrés en el rendimiento académico en los estudiantes de la Universidad Autónoma “Tomás Frías” Carrera de Auditoria - Contaduría Pública Sede Tupiza.', 'El presente trabajo de investigación trata sobre la influencia que tiene el estrés en el rendimiento académico, lo cual es una reacción cada vez más extendida entre los universitarios por las situaciones estresantes que identificamos en el presente trabajo. El estrés en los estudiantes no recibe la suficiente atención , porque los factores estresantes son día a día , como lo son la salud física y mental, imprevistos, pruebas objetivas, trabajos investigativos relaciones interpersonales inadecuadas a los que todo joven o persona enfrenta de diversas maneras afectando sin duda su desempeño académico al no saber de qué manera actuar ante múltiples estímulos como ser el cansancio, agotamiento alta presión laboral, excesiva competitividad, entre otros. El alcance de la investigación fue de tipo descriptivo a estudiantes la UNIVERSIDAD AUTÓNOMA “TOMÁS FRÍAS” CARRERA DE AUDITORÍA - CONTADURÍA PÚBLICA SEDE TUPIZA, lo cual se aplicó encuestas y entrevistas para llegar a resultados que muestran que el estrés si influye en el rendimiento académico, en el ámbito general no significativamente; Pero siempre está en cada una de las personas no siempre en los estudiantes no se puede eliminar pero si se puede controlar con actitud positiva lo cual guiará al éxito y si se lo toma con actitud negativa esto lo llevara al fracaso.', 'El resultado de la investigación que es sobre la influencia del estrés en el rendimiento académico, se concluye que los estudiantes de la Universidad Autónoma “Tomas Frías” Carrera de Auditoria - Contaduría Pública Sede Tupiza, presentan estrés que influye mucho sobre su rendimiento académico ya que se identificó situaciones estresantes que afecta emocionalmente a la personalidad de cada universitario. Las factores estresantes de los estudiantes si no son controlados puede ser el factores de un bajo rendimiento académico lo cual significa el cansancio excesivo, que se presentan a veces con problemas digestivos y alteraciones de sueño provocando dolores de cabeza o migraña esto impide la concentración en clases induciendo a bajas calificaciones y esto puede afectar su estado emocional de los estudiantes pero en este trabajo de investigación no hubo caso extremo de estrés crónica lo que significa que existe un nivel controlado de estrés y un rendimiento académico regular. Por otra parte, el estar en un entorno desfavorecedor, con una mala alimentación, y aumentando problemas familiares, económicos o académicos, provocan la que los estudiantes mujeres y varones entren en un estado de nerviosismo pánico y preocupación, la diferencia del nivel de estrés mujeres son representado en mayor porcentaje del 64% y varones en 36%, esto no significa que solamente las mujeres padecen de preocupación y nerviosismo: de acuerdo a la investigación. Sobre el análisis referido al estrés y los resultados obtuvimos se puede concluir que el estrés influye en ambos géneros y en maneras diferentes, cabe mencionar que la diferencia vista en los niveles de estrés que tienen los universitarios es por la existencia de más estudiantes mujeres que varones que son matriculados en la gestión 2018. 60 El estrés académicos porque es como un fenómeno que tiene como finalidad poder adaptar al organismo ante algunos hechos que suceden durante la vida académica, los cuales influyen en los estudiantes de forma positiva o negativa. De manera positiva: permite realizar una actividad con mayor expectativa y de mejor forma, ayudando a tener un rendimiento regular bueno dentro de la facultad, no permitiendo cansar con facilidad y dando mayor capacidad de concentración. Y de manera Negativa: algunas veces afecta a la realización de cualquier actividad. Finalmente se puede decir que el estrés influye siempre en la vida diaria de cada persona sean niños, adultos, universitarios etc. de acuerdo a la investigación hace conocer que el estrés no puede ser eliminado totalmente, porque siempre existe de alguna manera en porcentaje mínima. Por esta razón los estudiantes aprenden a vivir con esa inquietud, cabe decir que el estrés, no a gran extremo; puede ser beneficioso para obtener resultados favorables ayuda afrontar los retos y aumentar la autoestima de los estudiantes de la universidad, sabiendo que son capaces de lograr sus objetivos y sentirse satisfecho en el futuro.', '2019-07-19', 'dicyt_2019_07_19_22_32_12.pdf', 'UNIV. RUTH MARLENY CASTRO PUMA', 2018, 1, 'LIC. JOSÉ LUÍS SARDINAS M.', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (12, 12, 7, 'PROYECTO DE INVESTIGACION CARTOGRFIA TURISTICA APLICADO EN LAS COMUNIDAD DE TARAPAYA Y MONDRAGON', '1', '2', '<p>realizar la cartograf&iacute;a tem&aacute;tica de las comunidades de TARAPAYA Y MONDRAGON para el desarrollo del turismo comunitario, de esa marera las comunidades que cuenten con la cartograf&iacute;a actualizada para el beneficio del municipio de yocalla y tambi&eacute;n mediante ella incentivar al turismo que va generar ingresos econ&oacute;micos para el municipio.</p>\r\n', '<p>El presente trabajo de investigaci&oacute;n, consiste en desarrollar la cartograf&iacute;a tur&iacute;stica para generar el incentivo tur&iacute;stico en las comunidades de TARAPAYA y MONDRAG&Oacute;N ya que en las comunidades mencionadas existen mucha potencial de turismo mediante la cartograf&iacute;a tur&iacute;stica podemos generar gran cantidad de turistas visitando a nuestras comunidades y mediante ella generar recursos que ingresen al municipio.</p>\r\n\r\n<p>El problema de investigaci&oacute;n fui analizar los aspectos que contempla la implementaci&oacute;n de un proyecto una innovaci&oacute;n, considerados fundamentales para la permanencia del turismo.</p>\r\n\r\n<p>El proyecto de investigaci&oacute;n se realiz&oacute; en base al estudio&nbsp; de metodolog&iacute;a de informaci&oacute;n de diversas fuentes como documentos internos&nbsp; de las instituciones entrevistas encuestas con la comunidades de TARAPAYA Y MONDRAG&Oacute;N observaciones y una revisi&oacute;n literatura, se analiza el trabajo a trav&eacute;s de variables media te el ruteo con GPS a lo largo de la investigaci&oacute;n que son la motivaci&oacute;n para los pueblos de municipio y poseen los mecanismos hacia su trabajo para participar y generar recursos sustentables y sostenibles en el sistema de certificaci&oacute;n a nivel tur&iacute;stico hay la cartograf&iacute;a y percepci&oacute;n que tiene los trabajador del &aacute;rea rural.</p>\r\n\r\n<p>A partir de este trabajo, se argumenta la necesidad que tienen estas comunidades de conocer sus respectivas naturalezas y tur&iacute;sticas, con el fin de elaborar una pol&iacute;tica tur&iacute;stica propia, adaptando la gesti&oacute;n de los flujos tur&iacute;sticos a las caracter&iacute;sticas del patrimonio natural y cultural propio de cada uno de ellos, y no al contrario.</p>\r\n\r\n<p>El presente trabajo de grado, es una investigaci&oacute;n que trata sobre el estudio de la Optimizaci&oacute;n de cartograf&iacute;a y de recursos: humanos, materiales, &uacute;tiles de oficina, tiempo en la atenci&oacute;n dl personal tur&iacute;stica de s hemos realizado investigaci&oacute;n de campo en las comunidades mencionadas, observando falencias que existen de manera notoria en las cartograf&iacute;as, en cuanto se refiere a tiempo en la tramitaci&oacute;n de documentos, errores en la base de datos, respuestas inapropiadas a los usuarios. Recopilamos informaci&oacute;n a trav&eacute;s de la t&eacute;cnica de la encuesta dirigida hacia los investigadores y entrevista a personal administrativo, que nos sirven como orientaci&oacute;n para realizar la propuesta de la elaboraci&oacute;n de una gu&iacute;a para optimizar recursos, misma que determina seg&uacute;n el diagnostico factores favorables y desfavorables que afectan a la Instituci&oacute;n y que permitieron establecer los objetivos a lograrse.</p>\r\n', '<p>En la investigaci&oacute;n del presente trabajo se han logrado alcanzar los objetivos planteados con gran satisfacci&oacute;n.</p>\r\n\r\n<p>Implementar m&aacute;s estudios de investigaci&oacute;n a nuestras comunidades para describir mas lugares atractivos tur&iacute;sticos.</p>\r\n\r\n<p>&nbsp;Se considera adem&aacute;s que es necesario que los autoridades municipales y provinciales tomen conciencia de la importancia de contar con un trabajo de investigaci&oacute;n.</p>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_17_57.docx', 'UNIV. BENITO MAMANI CARVAJAL', 2018, 1, 'LIC. LUIS VELIS CHUMACERO', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (13, 12, 19, 'IDENTIFICACIÓN DE FUENTES DE AGUA POTABLE POR GRAVEDAD PARA LAS COMUNIDADES AFECTADAS POR LA CONTAMINACIÓN DEL RIÓ  DE CAIZA ', '1', '2', 'El objetivo general del trabajo de investigación es identificar nuevas fuentes para agua potable por gravedad para las comunidades de Chincurani, Mauca Caiza, Jatun Pampa del municipio de Caiza D.', 'NO DISPONIBLE', ' El caudal de ofertada de las diferentes fuentes de agua es apreciable para el aforo de que se la realiza de manera normal utilizando el método volumétrico.  Los parámetros de los resultados del análisis de las diferentes muestras de agua son aceptables, encontrándose dentro el rango de fuentes de agua BUENA, salvo que la presencia del Ph en las tres muestras se encuentra levemente fuera del rango, bajo, pero no es riesgo directo para la salud, por lo que se el análisis de calidad de agua, es potable, es buena para el consumo humano.  El caudal ofertado por las diferentes fuentes de agua cubre la demanda de agua de los pobladores que habitan en las comunidades de Chincurani, Mauca Caiza y Jatum Pampa.  El área de estudio para las obras de toma de las fuentes de agua se encuentran a una buena altura don referencia al reservorio, por lo que le sistema de agua funcionaria por gravedad.  En la fuente de agua “Sewencani” de la comunidad de chincurani presnta un tipo de fuente denominada “MANANTIAL”, las fuentes de “Jalanta” y “Jalaru” de las comunidades de Mauca Caiza y Jatun Pampa presentan un tipo de fuente denominado “ARROYOS”.', '2019-07-19', 'dicyt_2019_07_19_22_32_32.pdf', 'UNIV. FRANKLIN ANAGUA COILA', 2018, 0, 'no disponible', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (14, 17, 3, 'VALORACIÓN DE LA MONITORIZACIÓN ELECTRÓNICA FETAL, EN EL RIESGO DE PÉRDIDA DE BIEN ESTAR FETAL, EN EL SERVICIO DE GINECOOBSTETRICIA DEL HOSPITAL OBRERO Nº 5 DE LA CIUDAD DE POTOSÍ EN LOS MESES DE  MARZO ', '1', '2', '<p>Conocer la valoraci&oacute;n de la monitorizaci&oacute;n electr&oacute;nica fetal, en el riesgo de p&eacute;rdida de bien estar fetal, en pacientes atendidas en el SERVICIO DE GINECOOBSTETRICIA DEL HOSPITAL OBRERO N&ordm; 5 de la ciudad de Potos&iacute; en los meses de marzo-agosto de 2018</p>\r\n', '<p>El presente trabajo de investigaci&oacute;n tiene como objetivo &ldquo;Determinar la valoraci&oacute;n de la monitorizaci&oacute;n electr&oacute;nica fetal, en el riesgo de la p&eacute;rdida del bienestar fetal, en el servicio de ginecolog&iacute;a y obstetricia&nbsp; del Hospital Obrero de N&ordm; 5 de la ciudad de Potos&iacute;, entre los meses de Marzo a Agosto del a&ntilde;o 2018&rdquo;. Se realiz&oacute; una investigaci&oacute;n de tipo descriptivo, prospectivo y de corte transversal; La muestra estuvo constituida por 68 usuarias a las que se les realiz&oacute; el monitoreo fetal electr&oacute;nico durante el periodo intraparto. Las t&eacute;cnica utilizadas para la obtenci&oacute;n de la informaci&oacute;n fueron mediante la revisi&oacute;n documental de historias cl&iacute;nicas, para obtener un soporte te&oacute;rico, tambi&eacute;n se utiliz&oacute; el test de Dexeus; el procesamiento se expres&oacute; en tablas estad&iacute;sticas y gr&aacute;ficos, de discusi&oacute;n y s&iacute;ntesis, comparando de acuerdo a las variables para buscar los objetivos trazados.</p>\r\n\r\n<p>Los datos obtenidos indican que de 68 pacientes que se les realiz&oacute; el Test de Dexeus, 71% es reactivo y &nbsp;el 29% no es reactivo.&nbsp; De las 68 pacientes el 46 % tiene un resultado normal, el 31% tiene un resultado Pre patol&oacute;gico y el 23% tiene un resultado patol&oacute;gico.</p>\r\n\r\n<p>El estudio ha permitido observar que dicho monitoreo, ciertamente es una prueba que permite una mejor detecci&oacute;n del curso normal o anormal de la condici&oacute;n fetal, sin embargo no es definitorio con respecto a la condici&oacute;n del reci&eacute;n nacido.</p>\r\n', '<ul>\r\n	<li>EL Monitoreo Fetal Electr&oacute;nico es una prueba de bienestar utilizada con mucha frecuencia a nivel hospitalario de atenci&oacute;n obst&eacute;trica ya sea en pacientes con embarazos de riesgo o en aquellas que no presenten riesgo.</li>\r\n	<li>La realizaci&oacute;n de monitor&eacute;os continuos en pacientes en gestaci&oacute;n nos permite determinar si existe una alteraci&oacute;n el bienestar.</li>\r\n	<li>La realizaci&oacute;n de monitor&eacute;os a mujeres durante el trabajo de parto han reducido la incidencia de reci&eacute;n nacidos con Apgar bajo al nacimiento.</li>\r\n	<li>La inadecuada interpretaci&oacute;n del monitoreo fetal electr&oacute;nica aumentan el riesgo de complicaciones en el reci&eacute;n nacido.</li>\r\n	<li>La monitorizaci&oacute;n fetal realizada en gestantes en labor de parto, es de gran utilidad para la valoraci&oacute;n uterina y del estado fetal pues ayuda a tomar una decisi&oacute;n ante cualquier signo de alarma para culminar con el embarazo.</li>\r\n	<li>El patr&oacute;n alterado de frecuencia cardiaca fetal nos orienta a terminaci&oacute;n del embarazo, pero no determina el da&ntilde;o real al cual nos podemos enfrentar posterior al nacimiento, a un latido cardiaco normal.</li>\r\n	<li>En la mayor&iacute;a de las veces el trazado de la cardiotocograf&iacute;a esta alterado por la frecuencia cardiaca fetal y por desaceleraciones variables o tard&iacute;as, la observaci&oacute;n de desaceleraciones nos suministra informaci&oacute;n sobre la interacci&oacute;n del estado fetal y la actividad uterina.</li>\r\n</ul>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_22_25.docx', 'UNIV. LILIAN GRISSEL GUTIERREZ ROJAS', 2018, 0, 'DR. JOSÉ RICALDI PINTO', 'NO DISPONIBLE');
INSERT INTO `trabajo_investigacion` (`id_investigacion`, `id_facultad`, `id_carrera`, `titulo_investigacion`, `autor`, `tipo_investigador`, `objetivo_general`, `resumen`, `conclusiones`, `fecha`, `archivo`, `nombre_autor`, `gestion`, `visitas`, `tutor`, `tipo_investigacion`) VALUES (15, 13, 31, 'EFECTOS DE LA PRODUCCIÓN DEL SECTOR MINERO SOBRE LA CONTAMINACIÓN AMBIENTAL DEL MUNICIPIO DE UNCÍA', '1', '2', '<p>Determinar el efecto que tiene la producci&oacute;n en el sector minero sobre la contaminaci&oacute;n ambiental en el municipio de Unc&iacute;a.</p>\r\n', '<p>El presente trabajo de investigaci&oacute;n se bas&oacute; en el an&aacute;lisis del efecto de la producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a durante periodo de a&ntilde;os 2000 &ndash; 2017 tomando en cuenta a la poblaci&oacute;n en general.</p>\r\n\r\n<p>Al tomar en cuenta las causas y s&iacute;ntomas en la investigaci&oacute;n se lleg&oacute; a plantear el siguiente problema de investigaci&oacute;n &iquest;Cu&aacute;l es el efecto que tiene la producci&oacute;n del sector minero en la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a?.</p>\r\n\r\n<p>Soluci&oacute;n: se tom&oacute; como principal objetivo el determinar el efecto que tiene la producci&oacute;n en el sector minero sobre la contaminaci&oacute;n ambiental en el municipio de Unc&iacute;a.</p>\r\n\r\n<p>Para lo cual se hizo una estructura en el presente trabajo de investigaci&oacute;n que lleva una introducci&oacute;n, tres cap&iacute;tulos conclusiones y recomendaciones.</p>\r\n\r\n<p>En el cap&iacute;tulo I se refleja el an&aacute;lisis de los fundamentos te&oacute;ricos relacionados con la producci&oacute;n minera y la contaminaci&oacute;n ambiental, en el cap&iacute;tulo II diagn&oacute;stico de las caracter&iacute;sticas de la situaci&oacute;n actual de la producci&oacute;n mineral y la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a, en el cap&iacute;tulo III se pudo establecer la estimaci&oacute;n del efecto de la producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a mediante un modelo econom&eacute;trico as&iacute; llegando a comprobar la hip&oacute;tesis planteada. Finalmente se obtuvo las conclusiones m&aacute;s significativas sobre el trabajo de investigaci&oacute;n procediendo a realizar las respectivas recomendaciones.</p>\r\n\r\n<p>Todo el proceso de investigaci&oacute;n se llev&oacute; a cabo con la ayuda de bibliograf&iacute;a existente aportes te&oacute;ricos, la colaboraci&oacute;n de las autoridades y poblaci&oacute;n del municipio de Unc&iacute;a.</p>\r\n', '<p>El objetivo del presente trabajo era poder analizar el efecto de la Producci&oacute;n minera sobre la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a, con los hechos relevantes expuestos en los cap&iacute;tulos I, II y III, en los que se examin&oacute; tanto la parte te&oacute;rica y los indicadores cuantitativos, as&iacute; estableciendo de esta manera las siguientes conclusiones de acuerdo a los objetivos espec&iacute;ficos:</p>\r\n\r\n<ul>\r\n	<li>De acuerdo a las teor&iacute;as revisadas y analizadas, partiendo desde la teor&iacute;a neocl&aacute;sica con Pigou y Coase, la misma est&aacute; enfocada a la valoraci&oacute;n monetaria de los beneficios y costos ambientales. la teor&iacute;a , hasta llegar al an&aacute;lisis de Pearce y Turner,. Todas estas teor&iacute;as muestran el fuerte nexo que tiene la producci&oacute;n minera en la contaminaci&oacute;n ambiental pero la teor&iacute;a que m&aacute;s se acerca explicar el presente trabajo es la teor&iacute;a de Arthur Cecil Pigou indica varias alternativas para luchar contra la contaminaci&oacute;n ambiental entre las mas importantes es el impuesto Pigouviano la cual establece que todo individuo que haga uso del medio ambiente deber&aacute; retribuir un aporte econ&oacute;mico en benefio al medio ambiente pero en la investigaci&oacute;n se demuestra que, si existe una contaminaci&oacute;n ambiental y no existen pol&iacute;ticas ambientales asi como plantea la teor&iacute;a.</li>\r\n	<li>En el periodo de estudio se evidencio fluctuaciones en la producci&oacute;n minera ya sea por los precios de los minerales y variaci&oacute;n en los socios a trav&eacute;s de los a&ntilde;os, se pudo observar que tuvo efecto en el incremento de la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a ya sea directa e indirectamente.</li>\r\n	<li>En el presente trabajo fue muy importante la utilizaci&oacute;n de la econometr&iacute;a por medio de los modelos econom&eacute;tricos que reflejan que existe puntos significativos, coincidentes y consistentes en el efecto de la Producci&oacute;n minera y el incremento en la contaminaci&oacute;n ambiental del municipio de Unc&iacute;a.</li>\r\n</ul>\r\n', '2019-07-19', 'dicyt_2019_07_19_22_19_43.pdf', 'UNIV. VICTOR HUGO DELGADO CAERO', 2018, 1, 'NO DISPONIBLE', 'NO DISPONIBLE');


#
# TABLE STRUCTURE FOR: usuario
#

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id_usuario` int(100) NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(100) CHARACTER SET latin1 NOT NULL,
  `apellido_pat` varchar(100) CHARACTER SET latin1 NOT NULL,
  `apellido_mat` varchar(100) CHARACTER SET latin1 NOT NULL,
  `usuario` varchar(100) CHARACTER SET latin1 NOT NULL,
  `contrasena` varchar(100) CHARACTER SET latin1 NOT NULL,
  `ci` varchar(10) CHARACTER SET latin1 NOT NULL,
  `direccion` varchar(30) CHARACTER SET latin1 NOT NULL,
  `telefono` int(10) NOT NULL,
  `email` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `rol_id` int(30) NOT NULL,
  `id_facultad` int(10) NOT NULL,
  `id_carrera` int(10) NOT NULL,
  `estado` int(30) NOT NULL,
  `imagen` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_investigador` int(4) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `rol_id` (`rol_id`),
  KEY `id_facultad` (`id_facultad`),
  KEY `id_carrera` (`id_carrera`),
  KEY `tipo_investigador` (`tipo_investigador`),
  KEY `rol_id_2` (`rol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuario` (`id_usuario`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `usuario`, `contrasena`, `ci`, `direccion`, `telefono`, `email`, `rol_id`, `id_facultad`, `id_carrera`, `estado`, `imagen`, `tipo_investigador`) VALUES (1, 'super', 'admin pat', 'admin mat', 'administrador', 'MTIz', '12345678', 'admin_dir', 1234321, 'admin@hotmail.com', 1, 0, 0, 1, 'LOGO_DICYT1.png', 0);
INSERT INTO `usuario` (`id_usuario`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `usuario`, `contrasena`, `ci`, `direccion`, `telefono`, `email`, `rol_id`, `id_facultad`, `id_carrera`, `estado`, `imagen`, `tipo_investigador`) VALUES (5, 'Juan Carlos', 'Flores', 'Flores', 'carlos', 'MTIz', '123456712', 'Av. Quijarro # 23', 79123265, 'direc@hotmail.com', 2, 1, 1, 1, '4-Animation115_thumb.gif', 1);
INSERT INTO `usuario` (`id_usuario`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `usuario`, `contrasena`, `ci`, `direccion`, `telefono`, `email`, `rol_id`, `id_facultad`, `id_carrera`, `estado`, `imagen`, `tipo_investigador`) VALUES (7, 'prueba usua', 'user', 'prue', 'hugo2', 'MTIz', 'gg12e223', 'Av. Duarte #12923', 791232653, 'usuario@hotmail.com', 3, 1, 5, 1, 'carro-fancesa1.png', 2);
INSERT INTO `usuario` (`id_usuario`, `nombre_completo`, `apellido_pat`, `apellido_mat`, `usuario`, `contrasena`, `ci`, `direccion`, `telefono`, `email`, `rol_id`, `id_facultad`, `id_carrera`, `estado`, `imagen`, `tipo_investigador`) VALUES (8, 'coordinador', 'cor pa', 'cor ma', 'cordinador', 'MTIz', '989898', 'coor_dir', 1234321, 'coor@gmail.com', 4, 0, 0, 1, '7ED.gif', 0);


